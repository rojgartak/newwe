'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'

const ClientLogos = () => {
  const clients = [
    { name: 'DigitalSecure', logo: '/api/placeholder/120/60?text=DigitalSecure&bg=1f2937&color=ffffff' },
    { name: 'ProxyNetworks', logo: '/api/placeholder/120/60?text=ProxyNetworks&bg=1f2937&color=ffffff' },
    { name: 'CyberShield', logo: '/api/placeholder/120/60?text=CyberShield&bg=1f2937&color=ffffff' },
    { name: 'AnonymousVPN', logo: '/api/placeholder/120/60?text=AnonymousVPN&bg=1f2937&color=ffffff' },
    { name: 'SecureBrowse', logo: '/api/placeholder/120/60?text=SecureBrowse&bg=1f2937&color=ffffff' },
    { name: 'PrivacyTech', logo: '/api/placeholder/120/60?text=PrivacyTech&bg=1f2937&color=ffffff' },
    { name: 'StealthMode', logo: '/api/placeholder/120/60?text=StealthMode&bg=1f2937&color=ffffff' },
    { name: 'WebGuardian', logo: '/api/placeholder/120/60?text=WebGuardian&bg=1f2937&color=ffffff' },
    { name: 'SafeConnect', logo: '/api/placeholder/120/60?text=SafeConnect&bg=1f2937&color=ffffff' },
    { name: 'AntiDetect Pro', logo: '/api/placeholder/120/60?text=AntiDetect&bg=1f2937&color=ffffff' },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Trusted by Security Professionals
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join thousands of marketers, researchers, and privacy advocates who trust BeastBrowser for secure browsing
          </p>
        </motion.div>

        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-gray-50 to-gray-100 py-4">
          {/* Gradient Overlays */}
          <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-gray-50 via-gray-50 to-transparent z-10" />
          <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-gray-50 via-gray-50 to-transparent z-10" />
          
          {/* Scrolling Logos */}
          <motion.div
            animate={{
              x: [0, -1200],
            }}
            transition={{
              duration: 40,
              repeat: Infinity,
              ease: "linear",
            }}
            className="flex items-center space-x-8 py-6"
          >
            {clients.map((client, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05, duration: 0.4 }}
                className="flex-shrink-0"
              >
                <div className="w-28 h-14 bg-white rounded-lg flex items-center justify-center hover:bg-gray-50 hover:shadow-md transition-all duration-300 border border-gray-200/50 hover:border-primary-orange/20 hover:scale-105">
                  <span className="text-gray-600 font-medium text-sm hover:text-primary-orange transition-colors duration-300">{client.name}</span>
                </div>
              </motion.div>
            ))}
            
            {/* Duplicate for seamless loop */}
            {clients.map((client, index) => (
              <motion.div
                key={`duplicate-${index}`}
                className="flex-shrink-0"
              >
                <div className="w-28 h-14 bg-white rounded-lg flex items-center justify-center hover:bg-gray-50 hover:shadow-md transition-all duration-300 border border-gray-200/50 hover:border-primary-orange/20 hover:scale-105">
                  <span className="text-gray-600 font-medium text-sm hover:text-primary-orange transition-colors duration-300">{client.name}</span>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-center mt-16"
        >
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
            <div className="flex flex-wrap items-center justify-center gap-6 md:gap-8 text-gray-600 text-sm font-medium">
              <div className="flex items-center space-x-3 px-4 py-2 bg-green-50 rounded-lg">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span>256-bit Encryption</span>
              </div>
              <div className="flex items-center space-x-3 px-4 py-2 bg-blue-50 rounded-lg">
                <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                <span>Zero Logging Policy</span>
              </div>
              <div className="flex items-center space-x-3 px-4 py-2 bg-purple-50 rounded-lg">
                <div className="w-3 h-3 bg-purple-500 rounded-full animate-pulse"></div>
                <span>Enterprise Security</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default ClientLogos
