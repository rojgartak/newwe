'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, ChevronDown } from 'lucide-react'
import Link from 'next/link'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Close mobile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isOpen && !(event.target as Element).closest('.mobile-menu')) {
        setIsOpen(false)
      }
    }
    
    if (isOpen) {
      document.addEventListener('click', handleClickOutside)
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
    
    return () => {
      document.removeEventListener('click', handleClickOutside)
      document.body.style.overflow = 'unset'
    }
  }, [isOpen])

  const navItems = [
    {
      name: 'Features',
      href: '/features',
      submenu: [
        { name: 'Anti-Detection', href: '/features/anti-detection' },
        { name: 'Fingerprint Protection', href: '/features/fingerprint-protection' },
        { name: 'Multi-Profile Management', href: '/features/multi-profile' },
        { name: 'Browser Automation', href: '/features/automation' },
        { name: 'Proxy Integration', href: '/features/proxy-integration' },
        { name: 'Session Management', href: '/features/session-management' },
      ]
    },
    {
      name: 'Use Cases',
      href: '/use-cases',
      submenu: [
        { name: 'E-commerce Testing', href: '/use-cases/e-commerce' },
        { name: 'Social Media Management', href: '/use-cases/social-media' },
        { name: 'Market Research', href: '/use-cases/market-research' },
        { name: 'Ad Verification', href: '/use-cases/ad-verification' },
        { name: 'Account Management', href: '/use-cases/account-management' },
        { name: 'Privacy Protection', href: '/use-cases/privacy' },
      ]
    },
    {
      name: 'Pricing',
      href: '/pricing'
    },
    {
      name: 'Resources',
      href: '/resources',
      submenu: [
        { name: 'Documentation', href: '/resources/docs' },
        { name: 'Tutorials', href: '/resources/tutorials' },
        { name: 'API Reference', href: '/resources/api' }
      ]
    },
    {
      name: 'Support',
      href: '/support',
      submenu: [
        { name: 'Help Center', href: '/support/help' },
        { name: 'Contact Us', href: '/support/contact' }
      ]
    }
  ]

  const { user } = useSupabaseAuth()

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white/95 backdrop-blur-md shadow-lg border-b border-white/20' 
            : 'bg-transparent'
        }`}
      >
        <div className="nav-container">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2 group">
              <img src="/Beast_B.png" alt="BeastBrowser" className="w-10 h-10 rounded-xl shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-105" />
              <div className="flex flex-col">
                <span className="text-lg font-bold font-poppins gradient-text leading-tight">
                  BeastBrowser
                </span>
                <span className="text-xs text-gray-500 font-medium -mt-1">
                  Anti-Detect Browser
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-8">
              {navItems.map((item) => (
                <div key={item.name} className="relative group">
                  {item.submenu ? (
                    <button className="flex items-center space-x-1 text-gray-700 hover:text-primary-orange transition-colors duration-200 font-medium text-sm px-2 py-1 rounded-md hover:bg-gray-50">
                      <span>{item.name}</span>
                      <ChevronDown className="w-4 h-4 transition-transform duration-200 group-hover:rotate-180" />
                    </button>
                  ) : (
                    <Link 
                      href={item.href}
                      className="text-gray-700 hover:text-primary-orange transition-colors duration-200 font-medium text-sm px-2 py-1 rounded-md hover:bg-gray-50"
                    >
                      {item.name}
                    </Link>
                  )}
                  
                  {/* Submenu */}
                  {item.submenu && (
                    <div className="absolute top-full left-0 mt-1 w-64 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 transform translate-y-1 group-hover:translate-y-0 z-50">
                      <div className="bg-white rounded-lg border border-gray-200 max-h-80 overflow-y-auto dropdown-scroll" style={{boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}>
                        {item.submenu.map((subitem) => (
                          <Link
                            key={subitem.name}
                            href={subitem.href}
                            className="flex items-center justify-between w-full px-4 py-2.5 text-gray-700 hover:text-primary-orange hover:bg-orange-50 transition-all duration-200 text-sm font-medium group/item first:rounded-t-lg last:rounded-b-lg"
                          >
                            <span className="flex-1">{subitem.name}</span>
                            <svg className="w-3 h-3 opacity-0 group-hover/item:opacity-100 transform translate-x-1 group-hover/item:translate-x-0 transition-all duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="hidden lg:flex items-center space-x-3">
              {user ? (
                <>
                  <Link 
                    href="/dashboard" 
                    className="px-5 py-2 border-2 border-primary-orange text-primary-orange font-medium rounded-lg hover:bg-primary-orange hover:text-white transition-all duration-200 text-sm"
                  >
                    Dashboard
                  </Link>
                  <Link 
                    href="/download" 
                    className="px-5 py-2 bg-gradient-to-r from-primary-orange to-primary-red text-white font-medium rounded-lg hover:shadow-lg hover:scale-105 transition-all duration-200 text-sm"
                  >
                    Download
                  </Link>
                </>
              ) : (
                <>
                  <Link 
                    href="/login" 
                    className="px-5 py-2 border-2 border-primary-orange text-primary-orange font-medium rounded-lg hover:bg-primary-orange hover:text-white transition-all duration-200 text-sm"
                  >
                    Login
                  </Link>
                  <Link 
                    href="/download" 
                    className="px-5 py-2 bg-gradient-to-r from-primary-orange to-primary-red text-white font-medium rounded-lg hover:shadow-lg hover:scale-105 transition-all duration-200 text-sm"
                  >
                    Download Free
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="lg:hidden p-2 text-gray-700 hover:text-primary-orange transition-colors duration-200 touch-target"
              aria-label="Toggle mobile menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setIsOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="mobile-menu"
          >
            <div className="mobile-menu-content">
              <div className="flex items-center justify-between mb-6 sm:mb-8">
                <Link href="/" className="flex items-center space-x-2 group" onClick={() => setIsOpen(false)}>
                  <img src="/Beast_B.png" alt="BeastBrowser" className="w-10 h-10 rounded-xl shadow-lg" />
                  <div className="flex flex-col">
                    <span className="text-lg font-bold font-poppins gradient-text leading-tight">
                      BeastBrowser
                    </span>
                    <span className="text-xs text-gray-500 font-medium -mt-1">
                      Anti-Detect Browser
                    </span>
                  </div>
                </Link>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 text-gray-700 hover:text-primary-orange transition-colors duration-200 touch-target"
                  aria-label="Close mobile menu"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-2 sm:space-y-4">
                {navItems.map((item) => (
                  <div key={item.name}>
                    {item.submenu ? (
                      <details className="group">
                        <summary className="flex items-center justify-between p-3 sm:p-4 text-gray-700 hover:text-primary-orange transition-colors duration-200 cursor-pointer font-medium text-base sm:text-lg touch-target">
                          {item.name}
                          <ChevronDown className="w-4 h-4 transition-transform duration-200 group-open:rotate-180" />
                        </summary>
                        <div className="ml-2 mt-2 space-y-1 bg-gray-50 rounded-lg p-2">
                          {item.submenu.map((subitem) => (
                            <Link
                              key={subitem.name}
                              href={subitem.href}
                              onClick={() => setIsOpen(false)}
                              className="block px-3 py-2 text-gray-600 hover:text-primary-orange hover:bg-white rounded-md transition-all duration-200 text-sm touch-target"
                            >
                              {subitem.name}
                            </Link>
                          ))}
                        </div>
                      </details>
                    ) : (
                      <Link
                        href={item.href}
                        onClick={() => setIsOpen(false)}
                        className="block p-3 sm:p-4 text-gray-700 hover:text-primary-orange transition-colors duration-200 font-medium text-base sm:text-lg touch-target"
                      >
                        {item.name}
                      </Link>
                    )}
                  </div>
                ))}
              </div>

              <div className="mt-6 sm:mt-8 space-y-3 sm:space-y-4">
                {user ? (
                  <>
                    <Link 
                      href="/dashboard" 
                      onClick={() => setIsOpen(false)}
                      className="block w-full text-center py-3 sm:py-4 px-6 border-2 border-primary-orange text-primary-orange font-semibold rounded-xl hover:bg-primary-orange hover:text-white transition-all duration-200 text-base sm:text-lg touch-target"
                    >
                      Dashboard
                    </Link>
                    <Link 
                      href="/download" 
                      onClick={() => setIsOpen(false)}
                      className="block w-full text-center py-3 sm:py-4 px-6 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-200 text-base sm:text-lg touch-target"
                    >
                      Download
                    </Link>
                  </>
                ) : (
                  <>
                    <Link 
                      href="/login" 
                      onClick={() => setIsOpen(false)}
                      className="block w-full text-center py-3 sm:py-4 px-6 border-2 border-primary-orange text-primary-orange font-semibold rounded-xl hover:bg-primary-orange hover:text-white transition-all duration-200 text-base sm:text-lg touch-target"
                    >
                      Login
                    </Link>
                    <Link 
                      href="/download" 
                      onClick={() => setIsOpen(false)}
                      className="block w-full text-center py-3 sm:py-4 px-6 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-200 text-base sm:text-lg touch-target"
                    >
                      Download Free
                    </Link>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

export default Navigation
