'use client'

import { motion } from 'framer-motion'
import { Shield, Zap, Users, DollarSign, ArrowRight } from 'lucide-react'
import Link from 'next/link'

const HowItWorks = () => {
  const steps = [
    {
      icon: Shield,
      title: 'Advanced Anti-Detect',
      description: 'State-of-the-art fingerprint protection that keeps your digital identity completely anonymous and undetectable.',
      color: 'from-blue-500 to-cyan-500',
      delay: 0.1
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Experience blazing-fast load times and instant profile creation. The lightest anti-detect browser available.',
      color: 'from-green-500 to-emerald-500',
      delay: 0.2
    },
    {
      icon: Users,
      title: 'Unlimited Profiles',
      description: 'Manage unlimited browser profiles without restrictions. Perfect for affiliates, marketers, and professionals.',
      color: 'from-purple-500 to-pink-500',
      delay: 0.3
    },
    {
      icon: DollarSign,
      title: 'Affordable Pricing',
      description: 'Get unlimited access for just $19/month - the most competitive pricing in the market.',
      color: 'from-orange-500 to-red-500',
      delay: 0.4
    }
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-gray-100 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
      </div>

      <div className="container-custom relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Why Choose BeastBrowser?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            The first anti-detect browser designed for speed, security, and simplicity. 
            Experience the difference with our revolutionary technology.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: step.delay, duration: 0.6 }}
              className="relative group h-full"
            >
              {/* Step Number */}
              <div className="absolute -top-2 -left-2 w-8 h-8 bg-gradient-to-br from-primary-orange to-primary-red rounded-full flex items-center justify-center text-sm font-bold text-white group-hover:scale-110 transition-all duration-300 shadow-lg z-20">
                {index + 1}
              </div>

              {/* Card */}
              <div className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 group-hover:-translate-y-2 border border-gray-100/50 h-full flex flex-col hover:border-primary-orange/20">
                {/* Icon */}
                <div className={`w-12 h-12 bg-gradient-to-br ${step.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-all duration-300 shadow-md`}>
                  <step.icon className="w-6 h-6 text-white" />
                </div>

                {/* Content */}
                <div className="flex-grow">
                  <h3 className="text-lg font-bold text-gray-900 mb-3 group-hover:text-primary-orange transition-colors duration-300">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed text-xs">
                    {step.description}
                  </p>
                </div>
              </div>

              {/* Connector Arrow */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-2 transform -translate-y-1/2 z-10">
                  <motion.div
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: step.delay + 0.3, duration: 0.6 }}
                    className="w-8 h-8 bg-white rounded-full border-2 border-primary-orange/20 flex items-center justify-center shadow-md group-hover:border-primary-orange group-hover:scale-105 transition-all duration-300"
                  >
                    <ArrowRight className="w-4 h-4 text-primary-orange" />
                  </motion.div>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="text-center mt-16"
        >
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Ready to Experience BeastBrowser?
            </h3>
            <p className="text-gray-600 mb-6">
              Start your free trial today and discover why BeastBrowser is the ultimate choice for secure, anonymous browsing.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/signup" className="btn-primary">
                Start Free Trial
              </Link>
              <Link href="/pricing" className="btn-secondary">
                View Pricing
              </Link>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Curved Section Divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
          className="w-full h-auto"
        >
          <path
            d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
            opacity=".25"
            className="fill-white"
          />
          <path
            d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.71,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
            opacity=".5"
            className="fill-white"
          />
          <path
            d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            className="fill-white"
          />
        </svg>
      </div>
    </section>
  )
}

export default HowItWorks
