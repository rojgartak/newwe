'use client'

import { useState, useEffect } from 'react'
import { Plus, Users, AlertCircle } from 'lucide-react'
import { checkSubscriptionStatus } from '@/lib/supabase-auth'
import { supabase } from '@/lib/supabase'

interface ProfileCreationButtonsProps {
  onCreateProfile: (type: 'single' | 'bulk') => void
}

export default function ProfileCreationButtons({ onCreateProfile }: ProfileCreationButtonsProps) {
  const [subscriptionStatus, setSubscriptionStatus] = useState<{
    isActive: boolean
    plan: string | null
    daysRemaining: number
  }>({ isActive: false, plan: null, daysRemaining: 0 })
  
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [todayProfilesCount, setTodayProfilesCount] = useState(0)

  useEffect(() => {
    checkUserAndSubscription()
  }, [])

  const checkUserAndSubscription = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      
      if (user) {
        setUser(user)
        const status = await checkSubscriptionStatus(user.id)
        setSubscriptionStatus(status)
        
        // Get today's profile count from localStorage
        const today = new Date().toISOString().split('T')[0]
        const profilesKey = `profiles_${user.id}_${today}`
        const todayProfiles = JSON.parse(localStorage.getItem(profilesKey) || '[]')
        setTodayProfilesCount(todayProfiles.length)
      }
    } catch (error) {
      console.error('Error checking subscription:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleProfileCreation = (type: 'single' | 'bulk') => {
    if (!subscriptionStatus.isActive) {
      alert('Please update your plan to create profiles. Your subscription has expired or is inactive.')
      return
    }

    // Check daily limits
    const dailyLimit = subscriptionStatus.plan === 'yearly' ? 50 : 20
    
    if (todayProfilesCount >= dailyLimit) {
      alert(`Daily profile limit reached (${dailyLimit}). Please upgrade your plan for higher limits.`)
      return
    }

    // Call the profile creation function
    onCreateProfile(type)
    
    // Update today's count
    setTodayProfilesCount(prev => prev + 1)
  }

  if (loading) {
    return (
      <div className="flex space-x-4">
        <div className="animate-pulse bg-gray-200 rounded-lg h-12 w-40"></div>
        <div className="animate-pulse bg-gray-200 rounded-lg h-12 w-40"></div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 text-yellow-600" />
          <span className="text-yellow-800">Please login to create profiles</span>
        </div>
      </div>
    )
  }

  const dailyLimit = subscriptionStatus.plan === 'yearly' ? 50 : 20
  const remainingProfiles = Math.max(0, dailyLimit - todayProfilesCount)

  return (
    <div className="space-y-4">
      {/* Subscription Status */}
      <div className={`p-4 rounded-lg border ${
        subscriptionStatus.isActive 
          ? 'bg-green-50 border-green-200' 
          : 'bg-red-50 border-red-200'
      }`}>
        <div className="flex items-center justify-between">
          <div>
            <h3 className={`font-semibold ${
              subscriptionStatus.isActive ? 'text-green-800' : 'text-red-800'
            }`}>
              {subscriptionStatus.isActive ? 'Active Subscription' : 'Subscription Expired'}
            </h3>
            <p className={`text-sm ${
              subscriptionStatus.isActive ? 'text-green-600' : 'text-red-600'
            }`}>
              {subscriptionStatus.isActive 
                ? `${subscriptionStatus.plan} plan • ${subscriptionStatus.daysRemaining} days remaining`
                : 'Please update your plan to create profiles'
              }
            </p>
          </div>
          {subscriptionStatus.isActive && (
            <div className="text-right">
              <div className="text-sm text-gray-600">Today's Usage</div>
              <div className="font-bold text-lg">
                {todayProfilesCount}/{dailyLimit}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Profile Creation Buttons */}
      <div className="flex space-x-4">
        {/* Single Profile Creation */}
        <button
          onClick={() => handleProfileCreation('single')}
          disabled={!subscriptionStatus.isActive || remainingProfiles === 0}
          className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-semibold transition-all duration-300 ${
            subscriptionStatus.isActive && remainingProfiles > 0
              ? 'bg-gradient-to-r from-primary-orange to-primary-red text-white hover:shadow-lg hover:scale-105'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Plus className="w-5 h-5" />
          <span>Create Profile</span>
        </button>

        {/* Bulk Profile Creation */}
        <button
          onClick={() => handleProfileCreation('bulk')}
          disabled={!subscriptionStatus.isActive || remainingProfiles === 0}
          className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-semibold transition-all duration-300 ${
            subscriptionStatus.isActive && remainingProfiles > 0
              ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:shadow-lg hover:scale-105'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Users className="w-5 h-5" />
          <span>Bulk Create</span>
        </button>
      </div>

      {/* Error Message for Expired Subscription */}
      {!subscriptionStatus.isActive && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-red-600" />
            <div>
              <p className="text-red-800 font-semibold">Please update your plan</p>
              <p className="text-red-600 text-sm">Your subscription has expired. Please renew to continue creating profiles.</p>
              <a 
                href="/pricing" 
                className="inline-block mt-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700 transition-colors"
              >
                Renew Subscription
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Daily Limit Reached */}
      {subscriptionStatus.isActive && remainingProfiles === 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-yellow-600" />
            <div>
              <p className="text-yellow-800 font-semibold">Daily limit reached</p>
              <p className="text-yellow-600 text-sm">
                You've created {dailyLimit} profiles today. 
                {subscriptionStatus.plan === 'monthly' && ' Upgrade to yearly plan for higher limits.'}
              </p>
              {subscriptionStatus.plan === 'monthly' && (
                <a 
                  href="/pricing" 
                  className="inline-block mt-2 px-4 py-2 bg-yellow-600 text-white rounded-lg text-sm hover:bg-yellow-700 transition-colors"
                >
                  Upgrade Plan
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
