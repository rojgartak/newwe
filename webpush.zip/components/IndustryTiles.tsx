'use client'

import { motion } from 'framer-motion'
import { Shield, Zap, Tv, Users, Settings, Globe, Lock, DollarSign } from 'lucide-react'
import Link from 'next/link'

const IndustryTiles = () => {
  const industries = [
    {
      icon: Shield,
      title: 'Advanced Anti-Detect',
      description: 'State-of-the-art fingerprint protection that keeps your digital identity completely anonymous',
      color: 'from-blue-500 to-cyan-500',
      href: '/features/anti-detect',
      metrics: ['99.9%', 'Detection Rate']
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Ultra-lightweight design with blazing-fast load times and instant profile creation',
      color: 'from-green-500 to-emerald-500',
      href: '/features/speed',
      metrics: ['10x', 'Faster Loading']
    },
    {
      icon: Tv,
      title: 'TV User Agent',
      description: 'Unique TV user agent support for specialized browsing scenarios and enhanced anonymity',
      color: 'from-purple-500 to-pink-500',
      href: '/features/tv-agent',
      metrics: ['100%', 'Unique Feature']
    },
    {
      icon: Users,
      title: 'Unlimited Profiles',
      description: 'Manage unlimited browser profiles without restrictions. Perfect for professionals',
      color: 'from-orange-500 to-red-500',
      href: '/features/profiles',
      metrics: ['∞', 'Profiles']
    },
    {
      icon: Settings,
      title: 'Easy Management',
      description: 'One-click profile creation and management with advanced proxy and fingerprint settings',
      color: 'from-indigo-500 to-blue-500',
      href: '/features/management',
      metrics: ['1-Click', 'Setup']
    },
    {
      icon: Globe,
      title: 'Global Access',
      description: 'Access from anywhere in the world with our distributed infrastructure',
      color: 'from-teal-500 to-green-500',
      href: '/features/global',
      metrics: ['24/7', 'Availability']
    },
    {
      icon: Lock,
      title: 'Privacy First',
      description: 'Complete privacy protection with no data logging or tracking',
      color: 'from-amber-500 to-orange-500',
      href: '/features/privacy',
      metrics: ['100%', 'Private']
    },
    {
      icon: DollarSign,
      title: 'Affordable Pricing',
      description: 'Get unlimited access for just $30/month - professional anti-detection browsing',
      color: 'from-rose-500 to-pink-500',
      href: '/pricing',
      metrics: ['$30', 'Per Month']
    }
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            BeastBrowser Features
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the powerful features that make BeastBrowser the ultimate choice for secure, 
            anonymous, and lightning-fast browsing.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {industries.map((industry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08, duration: 0.6 }}
              className="group h-full"
            >
              <Link href={industry.href} className="block h-full">
                <div className="relative bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 group-hover:-translate-y-2 border border-gray-100/50 h-full flex flex-col justify-between overflow-hidden hover:border-primary-orange/20">
                  {/* Background Pattern */}
                  <div className="absolute top-0 right-0 w-16 h-16 opacity-5 group-hover:opacity-10 transition-opacity duration-300">
                    <div className={`w-full h-full bg-gradient-to-br ${industry.color} rounded-full transform translate-x-4 -translate-y-4`}></div>
                  </div>

                  <div className="relative z-10">
                    {/* Icon */}
                    <div className={`w-12 h-12 bg-gradient-to-br ${industry.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-all duration-300 shadow-md`}>
                      <industry.icon className="w-6 h-6 text-white" />
                    </div>

                    {/* Content */}
                    <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-primary-orange transition-colors duration-300 line-clamp-2">
                      {industry.title}
                    </h3>
                    <p className="text-gray-600 text-xs leading-relaxed mb-4 flex-grow">
                      {industry.description}
                    </p>
                  </div>

                  {/* Metrics */}
                  <div className="flex items-center justify-between mt-auto pt-3 border-t border-gray-100 group-hover:border-primary-orange/20 transition-colors duration-300">
                    <div>
                      <div className="text-lg font-bold text-primary-orange mb-0">
                        {industry.metrics[0]}
                      </div>
                      <div className="text-xs text-gray-500 font-medium">
                        {industry.metrics[1]}
                      </div>
                    </div>
                    
                    {/* Arrow */}
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center group-hover:bg-primary-orange group-hover:text-white group-hover:scale-105 transition-all duration-300">
                      <svg className="w-3 h-3 transform group-hover:translate-x-0.5 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </div>

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary-orange/5 to-primary-red/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="text-center mt-20"
        >
          <div className="relative bg-gradient-to-br from-primary-orange via-primary-red to-primary-orange rounded-3xl p-8 md:p-12 text-white overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 left-0 w-40 h-40 bg-white rounded-full -translate-x-20 -translate-y-20"></div>
              <div className="absolute bottom-0 right-0 w-32 h-32 bg-white rounded-full translate-x-16 translate-y-16"></div>
            </div>
            
            <div className="relative z-10">
              <h3 className="text-3xl md:text-4xl font-bold mb-6">
                Ready to Experience BeastBrowser?
              </h3>
              <p className="text-white/95 mb-8 max-w-2xl mx-auto text-lg leading-relaxed">
                Join thousands of users who trust BeastBrowser for their secure, anonymous browsing needs. 
                Start your free trial today and discover the difference.
              </p>
              <Link href="/signup" className="inline-flex items-center bg-white text-primary-orange font-semibold px-8 py-4 rounded-xl hover:bg-gray-100 hover:shadow-lg hover:scale-105 transition-all duration-300">
                Start Free Trial
                <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default IndustryTiles
