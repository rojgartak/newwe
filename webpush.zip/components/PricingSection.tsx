'use client'

import { motion } from 'framer-motion'
import { Check, Star, Zap, Users, Shield, Headphones, Crown } from 'lucide-react'
import Link from 'next/link'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'

const PricingSection = () => {
  const { user, loading } = useSupabaseAuth()
  
  const handlePurchaseClick = (planName: string) => {
    // Free plan goes directly to activation page
    if (planName === 'Free 7-Day Plan') {
      if (!user) {
        return `/signup?redirect=/free-plan`
      }
      return `/free-plan`
    }
    
    // Check if user is authenticated for paid plans
    if (!user) {
      return `/signup?redirect=${encodeURIComponent(`/purchase?plan=${encodeURIComponent(planName)}`)}`
    }
    
    return `/purchase?plan=${encodeURIComponent(planName)}`
  }
  
  const plans = [
    {
      name: 'Free 7-Day Plan',
      price: 'FREE',
      priceINR: '₹0',
      period: 'for 7 days',
      badge: 'Free Trial',
      description: 'Perfect for trying out BeastBrowser',
      features: [
        'Unlimited manual profiles',
        'Valid for 7 days',
        'All profiles stored locally',
        'Basic fingerprint protection',
        'Proxy support',
        'Custom user agents',
        'No credit card required'
      ],
      buttonText: 'Start Free Trial',
      buttonStyle: 'bg-gradient-to-r from-green-500 to-emerald-500 text-white hover:shadow-lg hover:scale-105',
      popular: false
    },
    {
      name: 'Starter Plan',
      price: '$3',
      priceINR: '₹266',
      period: 'for 24 hours',
      badge: 'Trial',
      description: 'Perfect for testing BeastBrowser features',
      features: [
        'Unlimited browser profiles',
        'Full fingerprint protection',
        'All premium features',
        'Advanced proxy support',
        'Custom user agents',
        'Valid for 24 hours only',
        'Expires automatically'
      ],
      buttonText: 'Get 1-Day Access',
      buttonStyle: 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white hover:shadow-lg hover:scale-105',
      popular: false
    },
    {
      name: 'Monthly Premium',
      price: '$30',
      priceINR: '₹2,665',
      period: 'per month',
      badge: 'Most Popular',
      description: 'Ideal for professionals and growing businesses',
      features: [
        'Unlimited browser profiles',
        'Advanced fingerprint protection',
        'Priority support',
        'Team collaboration tools',
        'Advanced proxy management',
        'Custom user agents',
        'Session management',
        'Real-time analytics'
      ],
      buttonText: 'Get Monthly Plan',
      buttonStyle: 'bg-gradient-to-r from-primary-orange to-primary-red text-white hover:shadow-lg hover:scale-105',
      popular: true
    },
    {
      name: 'Yearly Premium',
      price: '$249',
      priceINR: '₹22,122',
      period: 'per year',
      badge: 'Save $111!',
      description: 'Best value for serious users and enterprises',
      features: [
        'Everything in Monthly Premium',
        'Priority customer support',
        'Advanced analytics dashboard',
        'Dedicated account manager',
        'Early access to new features',
        'White-label options',
        'Custom training sessions'
      ],
      buttonText: 'Get Yearly Plan',
      buttonStyle: 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:shadow-lg hover:scale-105',
      popular: false
    }
  ]

  const couponInfo = {
    code: 'BLOGGERBUCKS20',
    discount: '20% OFF',
    description: 'Active Coupon'
  }

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
      </div>

      <div className="container-custom relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          {/* Coupon Banner */}
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-2 rounded-full text-sm font-medium mb-3 shadow-lg">
            <span>💸</span>
            <span>{couponInfo.description}: {couponInfo.code} - Get {couponInfo.discount}!</span>
          </div>

          {/* Referral Info */}
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-primary-orange to-primary-red text-white px-4 py-2 rounded-full text-sm font-semibold mb-6 shadow-lg">
            <span>🤝</span>
            <span>Referral commission 30%: If someone signs up with your link and upgrades any plan, you get 30% revenue.</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold font-poppins mb-6">
            <span className="gradient-text">Choose Your Plan</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Choose your subscription plan to get started. All plans include our core anti-detection features.
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className={`relative bg-white rounded-2xl shadow-lg border-2 hover:shadow-2xl transition-all duration-300 ${
                plan.popular 
                  ? 'border-primary-orange transform lg:-translate-y-4' 
                  : 'border-gray-200'
              }`}
            >
              {/* Popular Badge */}
              {plan.badge && (
                <div className={`absolute -top-4 left-1/2 transform -translate-x-1/2 px-4 py-1 rounded-full text-sm font-semibold text-white shadow-lg ${
                  plan.popular ? 'bg-gradient-to-r from-primary-orange to-primary-red' : 'bg-gradient-to-r from-green-500 to-emerald-600'
                }`}>
                  {plan.badge}
                </div>
              )}

              <div className="p-8">
                {/* Plan Header */}
                <div className="text-center mb-8">
                  <div className="mb-4">
                    {plan.name === 'Free 7-Day Plan' && <Star className="w-10 h-10 text-green-500 mx-auto" />}
                    {plan.name === 'Starter Plan' && <Zap className="w-10 h-10 text-blue-500 mx-auto" />}
                    {plan.name === 'Monthly Premium' && <Crown className="w-10 h-10 text-primary-orange mx-auto" />}
                    {plan.name === 'Yearly Premium' && <Shield className="w-10 h-10 text-purple-600 mx-auto" />}
                  </div>
                  
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 text-sm mb-6">{plan.description}</p>
                  
                  <div className="mb-6">
                    <div className="flex flex-col items-center">
                      <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                      <span className="text-2xl font-semibold text-primary-orange">{plan.priceINR}</span>
                      <span className="text-gray-500 text-sm mt-1">{plan.period}</span>
                    </div>
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start space-x-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <Link 
                  href={handlePurchaseClick(plan.name)}
                  className={`block w-full py-4 px-6 rounded-xl font-semibold text-center transition-all duration-300 ${plan.buttonStyle}`}
                >
                  {plan.buttonText}
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="text-center mt-16"
        >
          <p className="text-gray-600 mb-6 text-lg">
            Need a custom solution for your enterprise?
          </p>
          <Link 
            href="/contact"
            className="inline-flex items-center space-x-2 bg-gray-900 text-white px-8 py-4 rounded-xl font-semibold hover:bg-gray-800 transition-all duration-300"
          >
            <Users className="w-5 h-5" />
            <span>Contact Sales</span>
          </Link>
        </motion.div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center"
        >
          <div className="flex flex-col items-center space-y-3">
            <Shield className="w-8 h-8 text-primary-orange" />
            <h4 className="font-semibold text-gray-900">No Refunds</h4>
            <p className="text-gray-600 text-sm">All payments are final</p>
          </div>
          <div className="flex flex-col items-center space-y-3">
            <Headphones className="w-8 h-8 text-primary-orange" />
            <h4 className="font-semibold text-gray-900">24/7 Support</h4>
            <p className="text-gray-600 text-sm">Expert help whenever you need it</p>
          </div>
          <div className="flex flex-col items-center space-y-3">
            <Star className="w-8 h-8 text-primary-orange" />
            <h4 className="font-semibold text-gray-900">No Setup Fees</h4>
            <p className="text-gray-600 text-sm">Get started instantly</p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default PricingSection