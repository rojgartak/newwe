'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react'

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0)

  const testimonials = [
    {
      name: 'Alex Martinez',
      role: 'Digital Marketing Manager',
      company: 'E-commerce Pro',
      avatar: '/api/placeholder/80/80?text=AM&bg=FF6B00&color=ffffff',
      content: 'BeastBrowser revolutionized how I manage multiple social media accounts. The anti-detection is flawless and I can run campaigns without any restrictions.',
      rating: 5
    },
    {
      name: 'Sarah Chen',
      role: 'Security Researcher',
      company: 'CyberGuard Solutions',
      avatar: '/api/placeholder/80/80?text=SC&bg=D72638&color=ffffff',
      content: 'As a security professional, I need complete anonymity. BeastBrowser provides military-grade fingerprint protection that actually works.',
      rating: 5
    },
    {
      name: 'James Wilson',
      role: 'Affiliate Marketer',
      company: 'Independent',
      avatar: '/api/placeholder/80/80?text=JW&bg=6366F1&color=ffffff',
      content: 'Managing 50+ affiliate accounts was impossible until BeastBrowser. Now I can operate securely without worrying about account bans.',
      rating: 5
    },
    {
      name: 'Maria Rodriguez',
      role: 'Market Researcher',
      company: 'Data Insights Inc',
      avatar: '/api/placeholder/80/80?text=MR&bg=10B981&color=ffffff',
      content: 'BeastBrowser allows me to gather competitive intelligence from different geographic locations seamlessly. The proxy integration is perfect.',
      rating: 5
    },
    {
      name: 'David Park',
      role: 'Privacy Advocate',
      company: 'PrivacyFirst Org',
      avatar: '/api/placeholder/80/80?text=DP&bg=F59E0B&color=ffffff',
      content: 'Finally, a browser that truly respects privacy. No logging, no tracking, just pure anonymous browsing. This is what the internet should be.',
      rating: 5
    }
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [testimonials.length])

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/10 rounded-full blur-3xl" />
      </div>

      <div className="container-custom relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            What Our Users Say
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Join thousands of professionals who trust BeastBrowser for secure, 
            anonymous browsing and digital privacy protection.
          </p>
        </motion.div>

        {/* Testimonials Carousel */}
        <div className="relative max-w-4xl mx-auto">
          {/* Navigation Arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10 w-12 h-12 bg-white/10 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 z-10 w-12 h-12 bg-white/10 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-300"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Testimonial Content */}
          <div className="relative h-96">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <div className="text-center">
                  {/* Quote Icon */}
                  <div className="w-16 h-16 bg-primary-orange/20 rounded-full flex items-center justify-center mx-auto mb-8">
                    <Quote className="w-8 h-8 text-primary-orange" />
                  </div>

                  {/* Testimonial Text */}
                  <blockquote className="text-xl md:text-2xl text-white mb-8 leading-relaxed max-w-3xl mx-auto">
                    "{testimonials[currentIndex].content}"
                  </blockquote>

                  {/* Author Info */}
                  <div className="flex items-center justify-center space-x-4 mb-6">
                    <div className="w-16 h-16 rounded-full bg-gray-700 flex items-center justify-center text-white font-bold text-lg">
                      {testimonials[currentIndex].name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="text-left">
                      <div className="text-white font-semibold text-lg">
                        {testimonials[currentIndex].name}
                      </div>
                      <div className="text-gray-300 text-sm">
                        {testimonials[currentIndex].role}
                      </div>
                      <div className="text-primary-orange text-sm font-medium">
                        {testimonials[currentIndex].company}
                      </div>
                    </div>
                  </div>

                  {/* Rating */}
                  <div className="flex items-center justify-center space-x-1">
                    {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Dots Indicator */}
        <div className="flex items-center justify-center space-x-3 mt-12">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? 'bg-primary-orange w-8' 
                  : 'bg-white/30 hover:bg-white/50'
              }`}
            />
          ))}
        </div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-center mt-16"
        >
          <div className="inline-flex items-center space-x-8 text-gray-400 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>50K+ Active Users</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>4.9/5 User Rating</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span>100% Anonymity</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Testimonials
