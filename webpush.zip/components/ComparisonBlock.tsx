'use client'

import { motion } from 'framer-motion'
import { Check, X, Star, Zap, Shield, Clock, Users, TrendingUp } from 'lucide-react'
import Link from 'next/link'

const ComparisonBlock = () => {
  const features = [
    {
      feature: 'Load Speed',
      beastbrowser: 'Lightning Fast',
      competitors: 'Slow & Heavy',
      icon: Zap,
      color: 'from-yellow-500 to-orange-500'
    },
    {
      feature: 'Profile Creation',
      beastbrowser: 'Instant',
      competitors: '2-5 minutes',
      icon: Clock,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      feature: 'Anti-Detect Tech',
      beastbrowser: 'Advanced',
      competitors: 'Basic',
      icon: Shield,
      color: 'from-green-500 to-emerald-500'
    },
    {
      feature: 'TV User Agent',
      beastbrowser: 'Supported',
      competitors: 'Not Available',
      icon: Star,
      color: 'from-purple-500 to-pink-500'
    },
    {
      feature: 'Profile Limits',
      beastbrowser: 'Unlimited',
      competitors: 'Limited',
      icon: Users,
      color: 'from-indigo-500 to-blue-500'
    },
    {
      feature: 'Pricing',
      beastbrowser: '$30/month',
      competitors: '$50-100/month',
      icon: TrendingUp,
      color: 'from-red-500 to-pink-500'
    }
  ]

  const advantages = [
    'Ultra-lightweight design',
    'TV user agent support',
    'Instant profile creation',
    'Advanced fingerprint protection',
    'Unlimited profiles',
    'Most affordable pricing'
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-gray-100 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
      </div>

      <div className="container-custom relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            BeastBrowser vs Competitors
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See how BeastBrowser outperforms other anti-detect browsers in every critical aspect. 
            The first truly lightweight and fast solution.
          </p>
        </motion.div>

        {/* Comparison Table */}
        <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden mb-16">
          {/* Header */}
          <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white p-6 md:p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 items-center">
              <div className="text-center md:hidden">
                <h3 className="text-xl font-bold mb-2">Feature Comparison</h3>
                <p className="text-gray-300 text-sm">See how we stack up</p>
              </div>
              <div className="hidden md:block text-center">
                <h3 className="text-xl lg:text-2xl font-bold mb-2">Feature</h3>
                <p className="text-gray-300 text-sm">What matters most</p>
              </div>
              <div className="text-center order-first md:order-none">
                <div className="w-16 h-16 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <span className="text-white font-bold text-2xl">B</span>
                </div>
                <h3 className="text-xl lg:text-2xl font-bold mb-2">BeastBrowser</h3>
                <p className="text-gray-300 text-sm">Ultra-lightweight leader</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-gray-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <span className="text-white font-bold text-2xl">O</span>
                </div>
                <h3 className="text-xl lg:text-2xl font-bold mb-2">Others</h3>
                <p className="text-gray-300 text-sm">Heavy & slow</p>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="divide-y divide-gray-100">
            {features.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05, duration: 0.4 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-8 p-4 md:p-6 lg:p-8 hover:bg-gray-50 transition-all duration-300"
              >
                <div className="flex items-center space-x-3 md:space-x-4 md:col-span-1">
                  <div className={`w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br ${item.color} rounded-xl flex items-center justify-center shadow-sm`}>
                    <item.icon className="w-5 h-5 md:w-6 md:h-6 text-white" />
                  </div>
                  <span className="text-base md:text-lg font-semibold text-gray-900">{item.feature}</span>
                </div>
                <div className="text-center md:text-center bg-green-50 rounded-lg p-3 md:p-0 md:bg-transparent">
                  <span className="text-xl md:text-2xl font-bold text-primary-orange">{item.beastbrowser}</span>
                  <p className="text-xs text-gray-500 md:hidden">BeastBrowser</p>
                </div>
                <div className="text-center md:text-center bg-gray-50 rounded-lg p-3 md:p-0 md:bg-transparent">
                  <span className="text-base md:text-lg text-gray-500">{item.competitors}</span>
                  <p className="text-xs text-gray-500 md:hidden">Others</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Competitive Advantages */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
        >
          {/* Left Side - Advantages */}
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-8">
              Exclusive Advantages Only BeastBrowser Offers
            </h3>
            <div className="space-y-6">
              {advantages.map((advantage, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.6 + index * 0.1, duration: 0.6 }}
                  className="flex items-center space-x-4"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-primary-orange to-primary-red rounded-full flex items-center justify-center flex-shrink-0">
                    <Check className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-lg text-gray-700">{advantage}</span>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Right Side - Stats */}
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
            <h4 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Performance Metrics
            </h4>
            <div className="grid grid-cols-2 gap-6">
              {[
                { label: 'Faster Loading', value: '10x', color: 'from-green-500 to-emerald-500' },
                { label: 'Lighter Weight', value: '90%', color: 'from-blue-500 to-cyan-500' },
                { label: 'Better Detection', value: '99.9%', color: 'from-purple-500 to-pink-500' },
                { label: 'Lower Cost', value: '60%', color: 'from-orange-500 to-red-500' }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.8 + index * 0.1, duration: 0.6 }}
                  className="text-center"
                >
                  <div className={`text-3xl font-bold bg-gradient-to-br ${stat.color} bg-clip-text text-transparent mb-2`}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 1, duration: 0.8 }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-primary-orange to-primary-red rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              Ready to Experience BeastBrowser?
            </h3>
            <p className="text-white/90 mb-6 max-w-2xl mx-auto">
              Join thousands of users who trust BeastBrowser for their secure, anonymous browsing needs. 
              Start your free trial today and discover the difference.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/signup" className="bg-white text-primary-orange font-semibold px-8 py-4 rounded-xl hover:bg-gray-100 transition-colors duration-300">
                Start Free Trial
              </Link>
              <Link href="/pricing" className="border-2 border-white text-white font-semibold px-8 py-4 rounded-xl hover:bg-white hover:text-primary-orange transition-all duration-300">
                View Pricing
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default ComparisonBlock
