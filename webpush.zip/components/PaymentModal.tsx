'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, CreditCard, Bitcoin, Check, ExternalLink, Copy, QrCode, Clock } from 'lucide-react'
import { PLAN_PRICES, PaymentMethod, formatCurrency, createPhonePePayment, createCryptoPayment } from '@/lib/payments'

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  planName: string
  userEmail: string
  userName: string
  onSuccess?: () => void
}


export default function PaymentModal({
  isOpen,
  onClose,
  planName,
  userEmail,
  userName,
  onSuccess
}: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('phonepe')
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState('')
  const [cryptoPayment, setCryptoPayment] = useState<any>(null)
  const [cryptoCurrency, setCryptoCurrency] = useState('USDTTRC20')
  const [couponCode, setCouponCode] = useState('')
  const [couponData, setCouponData] = useState<any>(null)
  const [discount, setDiscount] = useState<any>(null)
  const [isValidatingCoupon, setIsValidatingCoupon] = useState(false)

  const planPrices = PLAN_PRICES[planName as keyof typeof PLAN_PRICES]
  const originalAmount = paymentMethod === 'phonepe' ? planPrices?.inr : planPrices?.usd
  const amount = discount ? discount.finalAmount : originalAmount

  const handlePhonePePayment = async () => {
    setIsProcessing(true)
    setError('')

    try {
      console.log('=== Creating PhonePe Payment ===')
      
      const response = await fetch('/api/payments/phonepe-checkout/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planName,
          amount: (amount || 0) * 100, // Convert to paise (discounted)
          originalAmount: (originalAmount || 0) * 100, // Original price in paise
          discountAmount: discount ? (discount.amount * 100) : 0,
          couponCode: couponData?.code || null,
          userEmail,
          userName
        })
      })

      // Try to parse response as JSON with fallback
      let result: any
      const responseText = await response.text()
      
      try {
        result = JSON.parse(responseText)
      } catch (e) {
        console.error('Non-JSON response:', responseText)
        throw new Error(`Server error: ${responseText.substring(0, 100)}`)
      }
      
      console.log('Payment Response:', result)

      if (!result.success) {
        // Extract user-friendly message
        const errorMessage = result.error || result.message || 'Failed to create payment'
        const errorCode = result.errorCode
        
        // Show specific error codes to user if available
        if (errorCode) {
          throw new Error(`${errorMessage} [${errorCode}]`)
        }
        throw new Error(errorMessage)
      }

      // Redirect to PhonePe checkout page
      if (result.redirectUrl) {
        window.location.href = result.redirectUrl
      } else {
        throw new Error('Redirect URL not received')
      }

    } catch (error) {
      console.error('PhonePe payment error:', error)
      setError(error instanceof Error ? error.message : 'Failed to process payment')
      setIsProcessing(false)
    }
  }

  const handleCryptoPayment = async () => {
    setIsProcessing(true)
    setError('')

    try {
      const paymentResponse = await createCryptoPayment({
        planName,
        amount: amount || 0,
        originalAmount: originalAmount || 0,
        discountAmount: discount?.amount || 0,
        couponCode: couponData?.code || null,
        currency: cryptoCurrency,
        userEmail,
        userName,
        method: 'crypto'
      })

      if (!paymentResponse.success) {
        throw new Error(paymentResponse.error || 'Failed to create crypto payment')
      }

      setCryptoPayment(paymentResponse.payment)
      
      // Store payment record for verification
      const payments = JSON.parse(localStorage.getItem('cryptoPayments') || '[]')
      payments.unshift(paymentResponse.paymentRecord)
      localStorage.setItem('cryptoPayments', JSON.stringify(payments))

    } catch (error) {
      console.error('Crypto payment error:', error)
      setError(error instanceof Error ? error.message : 'Payment failed')
    } finally {
      setIsProcessing(false)
    }
  }

  const updateUserPlan = (planName: string) => {
    try {
      const usersRaw = localStorage.getItem('users')
      const users = usersRaw ? JSON.parse(usersRaw) : []
      const userIndex = users.findIndex((u: any) => u.email === userEmail)
      
      if (userIndex >= 0) {
        users[userIndex].plan = planName
        users[userIndex].planActivatedAt = new Date().toISOString()
        localStorage.setItem('users', JSON.stringify(users))
      }

      // Store successful payment
      const payments = JSON.parse(localStorage.getItem('payments') || '[]')
      payments.unshift({
        id: Date.now().toString(),
        userEmail,
        planName,
        amount,
        currency: 'INR',
        method: paymentMethod,
        status: 'completed',
        paidAt: new Date().toISOString()
      })
      localStorage.setItem('payments', JSON.stringify(payments))
    } catch (error) {
      console.error('Error updating user plan:', error)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const checkCryptoPaymentStatus = async (paymentId: string) => {
    try {
      setError('')
      const response = await fetch(`/api/payments/nowpayments/status?payment_id=${paymentId}`)
      const result = await response.json()
      
      if (result.success) {
        const status = result.payment.status
        console.log('Payment status:', status)
        
        if (status === 'finished') {
          // Track coupon usage if coupon was applied
          if (couponData) {
            try {
              await fetch('/api/coupons/usage', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  couponCode: couponData.code,
                  userEmail,
                  planName,
                  paymentId: paymentId
                })
              })
            } catch (error) {
              console.error('Failed to track coupon usage:', error)
            }
          }
          
          // Payment completed successfully
          updateUserPlan(planName)
          onSuccess?.()
          onClose()
        } else if (status === 'failed' || status === 'expired' || status === 'refunded') {
          setError(`Payment ${status}. Please try again or contact support.`)
        } else {
          setError(`Payment status: ${status}. Please wait for confirmation.`)
        }
      } else {
        setError('Failed to check payment status')
      }
    } catch (error) {
      console.error('Error checking payment status:', error)
      setError('Failed to check payment status')
    }
  }

  const validateCoupon = async () => {
    if (!couponCode.trim()) {
      setError('Please enter a coupon code')
      return
    }

    setIsValidatingCoupon(true)
    setError('')

    try {
      const response = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: couponCode,
          planName,
          amount: originalAmount || 0
        })
      })

      const result = await response.json()

      if (result.success) {
        setCouponData(result.coupon)
        setDiscount(result.discount)
        setError('')
      } else {
        setError(result.error)
        setCouponData(null)
        setDiscount(null)
      }
    } catch (error) {
      console.error('Coupon validation error:', error)
      setError('Failed to validate coupon')
    } finally {
      setIsValidatingCoupon(false)
    }
  }

  const removeCoupon = () => {
    setCouponCode('')
    setCouponData(null)
    setDiscount(null)
    setError('')
  }

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">Upgrade to {planName}</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-6">
            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 rounded-lg text-sm">
                {error}
              </div>
            )}

            {!cryptoPayment ? (
              <>
                {/* Plan Details */}
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-600">Plan</span>
                    <span className="font-semibold">{planName}</span>
                  </div>
                  {discount ? (
                    <>
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <span>Original Amount</span>
                        <span className="line-through">{formatCurrency(originalAmount || 0, paymentMethod === 'phonepe' ? 'INR' : 'USD')}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm text-green-600">
                        <span>Discount ({couponData.code})</span>
                        <span>-{formatCurrency(discount.amount, paymentMethod === 'phonepe' ? 'INR' : 'USD')}</span>
                      </div>
                      <div className="flex items-center justify-between border-t pt-2 mt-2">
                        <span className="text-gray-600">Final Amount</span>
                        <span className="text-xl font-bold text-primary-orange">
                          {formatCurrency(amount || 0, paymentMethod === 'phonepe' ? 'INR' : 'USD')}
                        </span>
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Amount</span>
                      <span className="text-xl font-bold text-primary-orange">
                        {formatCurrency(amount || 0, paymentMethod === 'phonepe' ? 'INR' : 'USD')}
                      </span>
                    </div>
                  )}
                </div>

                {/* Payment Method Selection */}
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-3">Choose Payment Method</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setPaymentMethod('phonepe')}
                      className={`p-4 border-2 rounded-lg flex flex-col items-center space-y-2 transition-all ${
                        paymentMethod === 'phonepe'
                          ? 'border-primary-orange bg-orange-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <CreditCard className="w-6 h-6" />
                      <span className="text-sm font-medium">PhonePe</span>
                    </button>
                    <button
                      onClick={() => setPaymentMethod('crypto')}
                      className={`p-4 border-2 rounded-lg flex flex-col items-center space-y-2 transition-all ${
                        paymentMethod === 'crypto'
                          ? 'border-primary-orange bg-orange-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <Bitcoin className="w-6 h-6" />
                      <span className="text-sm font-medium">Crypto</span>
                    </button>
                  </div>
                </div>

                {/* Coupon Code Section */}
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-3">Coupon Code (Optional)</h3>
                  {!couponData ? (
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                        placeholder="Enter coupon code"
                        className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-orange focus:border-transparent"
                      />
                      <button
                        onClick={validateCoupon}
                        disabled={isValidatingCoupon || !couponCode.trim()}
                        className="px-4 py-2 bg-primary-orange text-white rounded-lg hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-1"
                      >
                        {isValidatingCoupon ? (
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <span>Apply</span>
                        )}
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg p-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium text-green-800">
                          {couponData.code} - {couponData.description}
                        </span>
                      </div>
                      <button
                        onClick={removeCoupon}
                        className="text-green-600 hover:text-green-800 text-sm font-medium"
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>

                {/* Crypto Currency Selection */}
                {paymentMethod === 'crypto' && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Cryptocurrency</h3>
                    <select
                      value={cryptoCurrency}
                      onChange={(e) => setCryptoCurrency(e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-orange focus:border-transparent"
                    >
                      <option value="USDTTRC20">USDT (TRC20)</option>
                      <option value="USDTERC20">USDT (ERC20)</option>
                      <option value="BTC">Bitcoin (BTC)</option>
                      <option value="ETH">Ethereum (ETH)</option>
                      <option value="LTC">Litecoin (LTC)</option>
                      <option value="BCH">Bitcoin Cash (BCH)</option>
                    </select>
                  </div>
                )}

                {/* Pay Button */}
                <button
                  onClick={paymentMethod === 'phonepe' ? handlePhonePePayment : handleCryptoPayment}
                  disabled={isProcessing}
                  className="w-full bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold py-3 px-6 rounded-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isProcessing ? (
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Processing...</span>
                    </div>
                  ) : (
                    paymentMethod === 'phonepe' 
                      ? `Pay ${formatCurrency(amount || 0, 'INR')}`
                      : `Pay ${formatCurrency(amount || 0, 'USD')}`
                  )}
                </button>
              </>
            ) : (
              /* Crypto Payment Details */
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary-orange to-primary-red rounded-full flex items-center justify-center mx-auto mb-4">
                    <Bitcoin className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Send Cryptocurrency</h3>
                  <p className="text-sm text-gray-600">Please send the exact amount to complete your payment</p>
                </div>

                {/* Payment Details */}
                <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Amount</span>
                    <span className="font-semibold">{cryptoPayment.payAmount} {cryptoPayment.payCurrency}</span>
                  </div>
                  
                  <div className="space-y-2">
                    <span className="text-sm text-gray-600">Address</span>
                    <div className="flex items-center space-x-2">
                      <code className="flex-1 text-xs bg-white p-2 rounded border font-mono break-all">
                        {cryptoPayment.payAddress}
                      </code>
                      <button
                        onClick={() => copyToClipboard(cryptoPayment.payAddress)}
                        className="p-2 hover:bg-gray-200 rounded transition-colors"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Time Limit */}
                  <div className="flex items-center space-x-2 text-sm text-amber-600 bg-amber-50 p-2 rounded">
                    <Clock className="w-4 h-4" />
                    <span>Payment expires in {Math.floor(cryptoPayment.timeLimit / 60)} minutes</span>
                  </div>
                </div>

                {/* QR Code */}
                {cryptoPayment.qrCode && (
                  <div className="text-center">
                    <img 
                      src={cryptoPayment.qrCode} 
                      alt="Payment QR Code" 
                      className="w-48 h-48 mx-auto border border-gray-200 rounded-lg"
                    />
                    <p className="text-xs text-gray-500 mt-2">Scan with your crypto wallet</p>
                  </div>
                )}

                {/* Instructions */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-900 mb-2">Payment Instructions</h4>
                  <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
                    <li>Copy the address above or scan the QR code</li>
                    <li>Send exactly {cryptoPayment.payAmount} {cryptoPayment.payCurrency}</li>
                    <li>Wait for confirmation (usually 1-3 confirmations)</li>
                    <li>Your plan will be activated automatically</li>
                  </ol>
                </div>

                {/* Payment Actions */}
                <div className="space-y-3">
                  <button
                    onClick={() => window.open(cryptoPayment.paymentUrl, '_blank')}
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold py-3 px-6 rounded-lg hover:shadow-lg transition-all duration-300 flex items-center justify-center space-x-2"
                  >
                    <ExternalLink className="w-5 h-5" />
                    <span>Open Payment Page</span>
                  </button>
                  
                  <button
                    onClick={() => checkCryptoPaymentStatus(cryptoPayment.id)}
                    className="w-full border border-gray-300 text-gray-700 font-semibold py-3 px-6 rounded-lg hover:bg-gray-50 transition-all duration-300"
                  >
                    Check Payment Status
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}