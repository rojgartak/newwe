'use client'

import { motion } from 'framer-motion'
import { ArrowRight, Play, BarChart3, Database, TrendingUp, Globe } from 'lucide-react'
import Link from 'next/link'

const Hero = () => {
  const floatingIcons = [
    { icon: BarChart3, delay: 0, position: 'top-20 left-20' },
    { icon: Database, delay: 0.5, position: 'top-32 right-32' },
    { icon: TrendingUp, delay: 1, position: 'bottom-32 left-32' },
    { icon: Globe, delay: 1.5, position: 'bottom-20 right-20' },
  ]

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 pt-16">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        {/* Gradient Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/20 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/20 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }} />
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,107,0,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,107,0,0.1)_1px,transparent_1px)] bg-[size:50px_50px]" />
        
        {/* Floating Data Points */}
        {floatingIcons.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 0.1, y: 0 }}
            transition={{ delay: item.delay, duration: 2 }}
            className={`absolute ${item.position} text-primary-orange/30`}
          >
            <item.icon className="w-8 h-8 animate-float" />
          </motion.div>
        ))}
      </div>

      {/* Main Content */}
      <div className="container-custom relative z-10 text-center mt-2">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-5xl mx-auto"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="inline-flex items-center px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full text-white/90 text-xs font-medium mb-6"
          >
            <span className="w-1.5 h-1.5 bg-primary-orange rounded-full mr-2 animate-pulse" />
            🔒 Ultra-Secure Anti-Detection Technology
          </motion.div>

          {/* Main Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-3xl sm:text-4xl lg:text-6xl font-bold text-white mb-8 leading-tight text-center"
          >
            <span className="block mb-2">BeastBrowser</span>
            <span className="block gradient-text mb-2">The Ultimate Anti-Detect</span>
            <span className="block">Multi-Browser</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="text-lg sm:text-xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed text-center"
          >
            Navigate the web with complete anonymity and protection. BeastBrowser provides advanced anti-detection technology, 
            multiple browser profiles, and enterprise-grade security for professionals who demand privacy.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16"
          >
            <Link href="/signup" className="inline-flex items-center bg-gradient-to-r from-primary-orange to-primary-red text-white font-medium px-8 py-4 rounded-lg hover:shadow-lg transform hover:-translate-y-1 transition-all duration-300 ease-out text-sm group min-w-[160px] justify-center">
              Start Free Trial
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
            </Link>
            <Link href="/features" className="inline-flex items-center bg-white/10 backdrop-blur-md border border-white/20 text-white font-medium px-8 py-4 rounded-lg hover:bg-white/20 transition-all duration-300 ease-out text-sm group min-w-[160px] justify-center">
              <Play className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform duration-200" />
              View Features
            </Link>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto"
          >
            {[
              { number: '100%', label: 'Anonymous' },
              { number: '50K+', label: 'Active Users' },
              { number: '1M+', label: 'Profiles Created' },
              { number: 'Free', label: 'Basic Version' },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-white mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-400 text-sm font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-1 h-3 bg-white/60 rounded-full mt-2"
          />
        </div>
      </motion.div>

      {/* Floating CTA Button */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 2, duration: 0.6 }}
        className="fixed bottom-8 right-8 z-50 lg:hidden"
      >
        <Link href="/signup" className="bg-gradient-to-r from-primary-orange to-primary-red text-white font-medium px-4 py-2 rounded-lg hover:shadow-lg transition-all duration-300 text-sm shadow-2xl">
          Start Free Trial
        </Link>
      </motion.div>
    </section>
  )
}

export default Hero
