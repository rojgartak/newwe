# How to Get Cashfree Test Keys (Sandbox Mode)

## Why You Need This
- ❌ **Production mode** requires HTTPS (won't work with `http://localhost:3000`)
- ✅ **Sandbox mode** accepts HTTP (perfect for local development)
- ✅ **No real money** charges during testing

## Step-by-Step Instructions

### Step 1: Login to Cashfree
1. Go to: **https://merchant.cashfree.com/merchants/login**
2. Login with your credentials

### Step 2: Switch to Test Mode
1. Look at the top-right corner of the dashboard
2. You'll see a toggle or dropdown: **Production** / **Test**
3. Click and switch to: **Test Mode** or **Sandbox Mode**

### Step 3: Get API Keys
1. In the left sidebar, click: **Developers** → **API Keys**
2. You'll see two keys:
   - **App ID** (looks like: `123456abcdef1234567890`)
   - **Secret Key** (looks like: `cfsk_ma_test_xxxxxxxxxxxx`)

3. Copy both keys

### Step 4: Update .env.local
Open `.env.local` and replace the test keys:

```env
CASHFREE_MODE=sandbox

# Replace these with your REAL test keys from Step 3
CASHFREE_TEST_APP_ID=paste_your_test_app_id_here
CASHFREE_TEST_SECRET_KEY=paste_your_test_secret_key_here
```

### Step 5: Restart Dev Server
Close the current server (Ctrl+C) and restart:

```bash
npm run dev
```

### Step 6: Test Payment
- Try creating a payment order
- It should work with HTTP now
- Cashfree will use sandbox.cashfree.com

## Test Payment Details

When testing in sandbox mode, use these test card details:

### Test Cards (Success):
```
Card Number: 4111 1111 1111 1111
CVV: 123
Expiry: Any future date (e.g., 12/25)
OTP: 123456
```

### Test UPI:
```
UPI ID: success@upi
```

### Test Netbanking:
- Select any bank
- Use any credentials
- Select "Success" on the test bank page

## Alternative: If You Can't Get Test Keys

If you can't access the test keys, you have another option using **ngrok** to get HTTPS for localhost:

### Option 2: Use ngrok (Keep Production Mode)

1. **Install ngrok:**
   - Download from: https://ngrok.com/download
   - Extract and run

2. **Start ngrok tunnel:**
   ```bash
   ngrok http 3000
   ```

3. **Copy HTTPS URL:**
   - ngrok will show: `https://abcd1234.ngrok.io`

4. **Update .env.local:**
   ```env
   CASHFREE_MODE=production
   NEXT_PUBLIC_APP_URL=https://abcd1234.ngrok.io
   ```

5. **Restart server and test**

⚠️ **Warning:** This will use REAL production keys and charge REAL money!

## Recommended Setup

For development: **Use Sandbox Mode** (Steps 1-6 above)
For production deployment: **Use Production Mode** with proper HTTPS domain

## Troubleshooting

### Issue: "Can't find API Keys in dashboard"
- Make sure you're in **Test Mode** (not Production)
- Check left sidebar for "Developers" or "Settings"

### Issue: "Keys not working"
- Copy the entire key (no spaces)
- Make sure it starts with `cfsk_ma_test_` for test secret key
- Restart dev server after updating .env.local

### Issue: Still getting HTTPS error
- Check `CASHFREE_MODE=sandbox` in .env.local
- Restart dev server completely
- Check console logs for which mode is being used

## Current Status

✅ I've switched your app to `CASHFREE_MODE=sandbox`
❌ **You need to get real test keys** and update lines 22-23 in `.env.local`

Once you update the keys and restart, Cashfree will accept HTTP URLs for localhost testing!
