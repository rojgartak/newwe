# 🧪 Test Cashfree Integration

## Quick Test Steps

### 1. Verify Environment Variables
```bash
# Open your .env.local file and confirm:
CASHFREE_APP_ID=1095049ffee3fc9b669557993149405901
CASHFREE_SECRET_KEY=cfsk_ma_prod_d3e1ce92fad2f165b3452054ea29ac10_c9b6e12f
CASHFREE_BASE_URL=https://api.cashfree.com/pg
```

✅ **Status:** Already configured with your production keys

---

### 2. Start Development Server
```bash
npm run dev
```

Open: http://localhost:3000

---

### 3. Test Payment Flow

#### Step 1: Login/Register
- Create account or login with existing account
- Email will be saved in Supabase

#### Step 2: Open Payment Modal
- Click "Upgrade to Premium" or "Buy Plan" button
- Payment modal should open

#### Step 3: Select Cashfree Payment
- Choose "UPI/Card" option (this is Cashfree)
- You'll see ₹2,550 for Monthly or ₹21,165 for Yearly

#### Step 4: Complete Payment
- Click "Pay ₹X,XXX" button
- Cashfree checkout should open
- Complete payment with UPI/Card/NetBanking

#### Step 5: Verify Success
- After payment, subscription should activate automatically
- Check Supabase dashboard for:
  - New record in `payments` table
  - New record in `subscriptions` table
  - User's `subscription_status` updated to 'active'

---

## Test Checklist

### Backend Tests
- [ ] Create order API works: `/api/payments/cashfree/create-order`
- [ ] Order status API works: `/api/payments/cashfree/status?order_id=XXX`
- [ ] Webhook receives events: `/api/webhooks/cashfree`
- [ ] Subscription gets activated in Supabase
- [ ] Payment record saved in database

### Frontend Tests
- [ ] Payment modal opens
- [ ] Cashfree SDK loads
- [ ] Checkout page opens
- [ ] Payment success callback works
- [ ] UI updates after payment
- [ ] Error handling works for failed payments

---

## Debugging Commands

### Check if Cashfree SDK loads:
```javascript
// Open browser console on payment modal
console.log(window.cashfree)
// Should show Cashfree object
```

### Check API Response:
```bash
# Test create-order endpoint
curl -X POST http://localhost:3000/api/payments/cashfree/create-order \
  -H "Content-Type: application/json" \
  -d '{
    "planName": "Monthly Premium",
    "amount": 2550,
    "userEmail": "test@example.com",
    "userName": "Test User",
    "userPhone": "9999999999"
  }'
```

### Check Order Status:
```bash
# Replace ORDER_ID with actual order ID
curl http://localhost:3000/api/payments/cashfree/status?order_id=ORDER_ID
```

---

## Expected Payment Flow

```
User clicks "Pay"
  ↓
Frontend calls /api/payments/cashfree/create-order
  ↓
Backend creates order in Cashfree
  ↓
Backend saves payment record in Supabase
  ↓
Frontend receives payment_session_id
  ↓
Cashfree SDK opens checkout
  ↓
User completes payment on Cashfree
  ↓
Cashfree sends webhook to /api/webhooks/cashfree
  ↓
Webhook handler creates subscription
  ↓
Webhook handler updates user status
  ↓
Frontend success callback fires
  ↓
User sees success message
  ↓
Subscription is active!
```

---

## Production Webhook Setup

Before going live, configure Cashfree webhook:

1. Login to [Cashfree Dashboard](https://merchant.cashfree.com/)
2. Navigate to: **Developers → Webhooks**
3. Add webhook URL:
   ```
   https://yourdomain.com/api/webhooks/cashfree
   ```
4. Enable events:
   - ✅ PAYMENT_SUCCESS
   - ✅ PAYMENT_FAILED

---

## Troubleshooting

### Issue: Payment modal doesn't open
**Fix:** Check if user is logged in to Supabase

### Issue: Cashfree SDK not loaded
**Fix:** Check browser console, SDK loads from: `https://sdk.cashfree.com/js/v3/cashfree.js`

### Issue: Order creation fails
**Fix:** 
- Verify API keys in `.env.local`
- Check if user exists in Supabase `users` table
- Check server console for error messages

### Issue: Payment success but subscription not activated
**Fix:**
- Check webhook logs in Supabase `webhook_logs` table
- Verify webhook URL is accessible
- Check if `PAYMENT_SUCCESS` event is being sent by Cashfree

### Issue: "User not found" error
**Fix:**
- User must be registered in Supabase first
- Check if email exists in `users` table

---

## Monitor Payments

### Supabase Dashboard
1. Go to: https://supabase.com/dashboard/project/ckbudoabovcrxywdtbqh
2. Check tables:
   - `payments` - All payment records
   - `subscriptions` - Active subscriptions
   - `webhook_logs` - Webhook events
   - `users` - User subscription status

### Cashfree Dashboard
1. Go to: https://merchant.cashfree.com/
2. View:
   - Orders
   - Payments
   - Settlements
   - Webhooks

---

## Success Indicators

✅ Order created in Cashfree dashboard
✅ Payment appears in Cashfree transactions
✅ Payment record created in Supabase `payments` table
✅ Subscription record created in Supabase `subscriptions` table
✅ User's `subscription_status` = 'active' in `users` table
✅ User can create 20/50 profiles per day based on plan
✅ Webhook logged in `webhook_logs` table

---

**Status:** Ready to test! All files are integrated.
