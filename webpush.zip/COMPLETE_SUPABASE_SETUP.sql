-- ============================================
-- COMPLETE SUPABASE SETUP FOR BEASTBROWSER
-- Copy this ENTIRE file and paste in Supabase SQL Editor
-- ============================================

-- STEP 1: Fix Currency Field (for Crypto Payments)
-- ============================================
ALTER TABLE subscriptions 
ALTER COLUMN currency TYPE VARCHAR(20);

ALTER TABLE payments 
ALTER COLUMN currency TYPE VARCHAR(20);


-- STEP 2: Free Plan Tables Setup
-- ============================================

-- Table to track user's free plan activation
CREATE TABLE IF NOT EXISTS free_plan_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    activated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id)
);

-- Table to track daily profile creation
CREATE TABLE IF NOT EXISTS daily_profile_limits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    profiles_created INTEGER DEFAULT 0,
    max_profiles INTEGER DEFAULT 10,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, date)
);

-- Table to store actual profiles created by free users
CREATE TABLE IF NOT EXISTS free_plan_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    profile_name TEXT NOT NULL,
    profile_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_free_plan_users_user_id ON free_plan_users(user_id);
CREATE INDEX IF NOT EXISTS idx_free_plan_users_expires_at ON free_plan_users(expires_at);
CREATE INDEX IF NOT EXISTS idx_daily_profile_limits_user_date ON daily_profile_limits(user_id, date);
CREATE INDEX IF NOT EXISTS idx_free_plan_profiles_user_id ON free_plan_profiles(user_id);

-- Enable Row Level Security
ALTER TABLE free_plan_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_profile_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE free_plan_profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies for free_plan_users
DROP POLICY IF EXISTS "Users can view their own free plan" ON free_plan_users;
CREATE POLICY "Users can view their own free plan"
    ON free_plan_users FOR SELECT
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert their own free plan" ON free_plan_users;
CREATE POLICY "Users can insert their own free plan"
    ON free_plan_users FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- RLS Policies for daily_profile_limits
DROP POLICY IF EXISTS "Users can view their own daily limits" ON daily_profile_limits;
CREATE POLICY "Users can view their own daily limits"
    ON daily_profile_limits FOR SELECT
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update their own daily limits" ON daily_profile_limits;
CREATE POLICY "Users can update their own daily limits"
    ON daily_profile_limits FOR UPDATE
    USING (auth.uid() = user_id);

-- RLS Policies for free_plan_profiles
DROP POLICY IF EXISTS "Users can view their own profiles" ON free_plan_profiles;
CREATE POLICY "Users can view their own profiles"
    ON free_plan_profiles FOR SELECT
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert their own profiles" ON free_plan_profiles;
CREATE POLICY "Users can insert their own profiles"
    ON free_plan_profiles FOR INSERT
    WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can delete their own profiles" ON free_plan_profiles;
CREATE POLICY "Users can delete their own profiles"
    ON free_plan_profiles FOR DELETE
    USING (auth.uid() = user_id);

-- Grant permissions
GRANT ALL ON free_plan_users TO authenticated;
GRANT ALL ON daily_profile_limits TO authenticated;
GRANT ALL ON free_plan_profiles TO authenticated;

-- ============================================
-- VERIFICATION: Check if everything is created
-- ============================================
SELECT 'Currency field updated' AS status, 
       character_maximum_length 
FROM information_schema.columns 
WHERE table_name = 'payments' AND column_name = 'currency';

SELECT 'Free plan tables created' AS status,
       COUNT(*) as table_count
FROM information_schema.tables 
WHERE table_name IN ('free_plan_users', 'daily_profile_limits', 'free_plan_profiles');
