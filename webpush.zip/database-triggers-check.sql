-- 🔍 Database Triggers Check & Fix for BeastBrowser
-- Run this in Supabase SQL Editor to ensure automatic premium activation

-- =====================================================
-- Step 1: Check Current Triggers
-- =====================================================

-- Check if trigger exists
SELECT 
    trigger_name, 
    event_manipulation, 
    event_object_table, 
    action_statement
FROM information_schema.triggers 
WHERE trigger_schema = 'public' 
AND event_object_table IN ('subscriptions', 'payments');

-- =====================================================
-- Step 2: Create/Update Trigger Function
-- =====================================================

-- Drop existing function if exists
DROP FUNCTION IF EXISTS sync_user_subscription() CASCADE;

-- Create improved trigger function
CREATE OR REPLACE FUNCTION sync_user_subscription()
RETURNS TRIGGER AS $$
BEGIN
    -- Log the trigger execution
    RAISE NOTICE '🎯 BeastBrowser: Subscription trigger fired for email: %', COALESCE(NEW.user_email, 'unknown');
    
    -- Only process active subscriptions
    IF NEW.status = 'active' AND NEW.user_email IS NOT NULL THEN
        
        -- Insert or update user in users table
        INSERT INTO users (
            id,
            email,
            subscription_status,
            subscription_plan,
            subscription_expires_at,
            created_at,
            updated_at
        ) VALUES (
            COALESCE(NEW.user_id, gen_random_uuid()),
            NEW.user_email,
            'active',
            NEW.plan_type,
            NEW.expires_at,
            NOW(),
            NOW()
        )
        ON CONFLICT (email) 
        DO UPDATE SET
            subscription_status = 'active',
            subscription_plan = NEW.plan_type,
            subscription_expires_at = NEW.expires_at,
            updated_at = NOW();
            
        RAISE NOTICE '✅ BeastBrowser: User % subscription activated - Plan: %, Expires: %', 
            NEW.user_email, NEW.plan_type, NEW.expires_at;
            
    ELSIF NEW.status = 'expired' AND NEW.user_email IS NOT NULL THEN
        
        -- Update user to expired status
        UPDATE users 
        SET 
            subscription_status = 'expired',
            updated_at = NOW()
        WHERE email = NEW.user_email;
        
        RAISE NOTICE '⚠️ BeastBrowser: User % subscription expired', NEW.user_email;
        
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- Step 3: Create Trigger on Subscriptions Table
-- =====================================================

-- Drop existing trigger if exists
DROP TRIGGER IF EXISTS trigger_sync_user_subscription ON subscriptions;

-- Create new trigger
CREATE TRIGGER trigger_sync_user_subscription
    AFTER INSERT OR UPDATE ON subscriptions
    FOR EACH ROW
    EXECUTE FUNCTION sync_user_subscription();

-- =====================================================
-- Step 4: Test the Trigger
-- =====================================================

-- Test 1: Insert test subscription (this should auto-create/update user)
INSERT INTO subscriptions (
    user_email,
    plan_type,
    status,
    expires_at,
    amount,
    payment_gateway,
    order_id,
    created_at,
    updated_at
) VALUES (
    'trigger-test@beastbrowser.com',
    'monthly',
    'active',
    NOW() + INTERVAL '30 days',
    2550,
    'cashfree',
    'TEST_TRIGGER_' || EXTRACT(EPOCH FROM NOW()),
    NOW(),
    NOW()
) ON CONFLICT (order_id) DO NOTHING;

-- Test 2: Check if user was created/updated
SELECT 
    email,
    subscription_status,
    subscription_plan,
    subscription_expires_at,
    created_at,
    updated_at
FROM users 
WHERE email = 'trigger-test@beastbrowser.com';

-- =====================================================
-- Step 5: Verify Webhook Integration
-- =====================================================

-- Check recent webhook logs
SELECT 
    gateway,
    event_type,
    status,
    created_at,
    response_data
FROM webhook_logs 
ORDER BY created_at DESC 
LIMIT 5;

-- Check recent subscriptions
SELECT 
    user_email,
    plan_type,
    status,
    payment_gateway,
    order_id,
    created_at
FROM subscriptions 
ORDER BY created_at DESC 
LIMIT 5;

-- =====================================================
-- Step 6: Manual Premium Activation Function
-- =====================================================

-- Function to manually activate premium (for admin use)
CREATE OR REPLACE FUNCTION activate_premium(
    p_email TEXT,
    p_plan TEXT DEFAULT 'monthly'
)
RETURNS JSON AS $$
DECLARE
    v_expires_at TIMESTAMP;
    v_amount INTEGER;
    result JSON;
BEGIN
    -- Calculate expiry date
    IF p_plan = 'yearly' THEN
        v_expires_at := NOW() + INTERVAL '1 year';
        v_amount := 21165;
    ELSE
        v_expires_at := NOW() + INTERVAL '1 month';
        v_amount := 2550;
    END IF;
    
    -- Insert subscription (trigger will auto-update user)
    INSERT INTO subscriptions (
        user_email,
        plan_type,
        status,
        expires_at,
        amount,
        payment_gateway,
        order_id,
        created_at,
        updated_at
    ) VALUES (
        p_email,
        p_plan,
        'active',
        v_expires_at,
        v_amount,
        'admin',
        'ADMIN_' || EXTRACT(EPOCH FROM NOW()),
        NOW(),
        NOW()
    );
    
    -- Return success result
    result := json_build_object(
        'success', true,
        'email', p_email,
        'plan', p_plan,
        'expires_at', v_expires_at,
        'message', 'Premium activated successfully'
    );
    
    RETURN result;
    
EXCEPTION WHEN OTHERS THEN
    -- Return error result
    result := json_build_object(
        'success', false,
        'error', SQLERRM,
        'message', 'Failed to activate premium'
    );
    
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- Step 7: Test Manual Activation
-- =====================================================

-- Test manual activation
SELECT activate_premium('manual-test@beastbrowser.com', 'monthly');

-- Verify user was created
SELECT 
    email,
    subscription_status,
    subscription_plan,
    subscription_expires_at
FROM users 
WHERE email = 'manual-test@beastbrowser.com';

-- =====================================================
-- Step 8: Cleanup Test Data (Optional)
-- =====================================================

-- Uncomment to clean up test data
-- DELETE FROM subscriptions WHERE user_email IN ('trigger-test@beastbrowser.com', 'manual-test@beastbrowser.com');
-- DELETE FROM users WHERE email IN ('trigger-test@beastbrowser.com', 'manual-test@beastbrowser.com');

-- =====================================================
-- Step 9: Final Verification
-- =====================================================

-- Check all triggers are working
SELECT 
    'Triggers Check' as test_type,
    COUNT(*) as trigger_count
FROM information_schema.triggers 
WHERE trigger_schema = 'public' 
AND event_object_table = 'subscriptions';

-- Check recent activity
SELECT 
    'Recent Activity' as test_type,
    COUNT(*) as active_subscriptions
FROM subscriptions 
WHERE status = 'active' 
AND expires_at > NOW();

-- Success message
SELECT '🎉 BeastBrowser Database Setup Complete! 🎉' as status;
