-- Fix currency field to support crypto currency codes
-- Run this in Supabase SQL Editor

-- Update subscriptions table
ALTER TABLE subscriptions 
ALTER COLUMN currency TYPE VARCHAR(20);

-- Update payments table
ALTER TABLE payments 
ALTER COLUMN currency TYPE VARCHAR(20);

-- Verify changes
SELECT column_name, data_type, character_maximum_length 
FROM information_schema.columns 
WHERE table_name IN ('subscriptions', 'payments') 
AND column_name = 'currency';
