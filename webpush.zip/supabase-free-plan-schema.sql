-- Free Plan Profile Tracking Schema
-- This tracks daily profile creation for free plan users

-- Table to track user's free plan activation
CREATE TABLE IF NOT EXISTS free_plan_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    activated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id)
);

-- Table to track daily profile creation
CREATE TABLE IF NOT EXISTS daily_profile_limits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    profiles_created INTEGER DEFAULT 0,
    max_profiles INTEGER DEFAULT 10,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, date)
);

-- Table to store actual profiles created by free users
CREATE TABLE IF NOT EXISTS free_plan_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    profile_name TEXT NOT NULL,
    profile_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_free_plan_users_user_id ON free_plan_users(user_id);
CREATE INDEX IF NOT EXISTS idx_free_plan_users_expires_at ON free_plan_users(expires_at);
CREATE INDEX IF NOT EXISTS idx_daily_profile_limits_user_date ON daily_profile_limits(user_id, date);
CREATE INDEX IF NOT EXISTS idx_free_plan_profiles_user_id ON free_plan_profiles(user_id);

-- Function to check if user can create profile today
CREATE OR REPLACE FUNCTION can_create_profile(p_user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    v_profiles_today INTEGER;
    v_max_profiles INTEGER;
    v_plan_active BOOLEAN;
    v_plan_expired BOOLEAN;
BEGIN
    -- Check if user has active free plan
    SELECT 
        is_active,
        expires_at < NOW()
    INTO v_plan_active, v_plan_expired
    FROM free_plan_users
    WHERE user_id = p_user_id;
    
    -- If no free plan or expired, return false
    IF v_plan_active IS NULL OR NOT v_plan_active OR v_plan_expired THEN
        RETURN FALSE;
    END IF;
    
    -- Get today's profile count
    SELECT 
        COALESCE(profiles_created, 0),
        max_profiles
    INTO v_profiles_today, v_max_profiles
    FROM daily_profile_limits
    WHERE user_id = p_user_id 
    AND date = CURRENT_DATE;
    
    -- If no record for today, user can create (count is 0)
    IF v_profiles_today IS NULL THEN
        RETURN TRUE;
    END IF;
    
    -- Check if under limit
    RETURN v_profiles_today < v_max_profiles;
END;
$$ LANGUAGE plpgsql;

-- Function to increment profile count
CREATE OR REPLACE FUNCTION increment_profile_count(p_user_id UUID)
RETURNS VOID AS $$
BEGIN
    INSERT INTO daily_profile_limits (user_id, date, profiles_created, max_profiles)
    VALUES (p_user_id, CURRENT_DATE, 1, 10)
    ON CONFLICT (user_id, date)
    DO UPDATE SET 
        profiles_created = daily_profile_limits.profiles_created + 1,
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql;

-- Function to activate free plan for user
CREATE OR REPLACE FUNCTION activate_free_plan(p_user_id UUID)
RETURNS JSONB AS $$
DECLARE
    v_expires_at TIMESTAMP WITH TIME ZONE;
    v_result JSONB;
BEGIN
    -- Set expiry to 7 days from now
    v_expires_at := NOW() + INTERVAL '7 days';
    
    -- Insert or update free plan
    INSERT INTO free_plan_users (user_id, activated_at, expires_at, is_active)
    VALUES (p_user_id, NOW(), v_expires_at, true)
    ON CONFLICT (user_id)
    DO UPDATE SET
        activated_at = NOW(),
        expires_at = v_expires_at,
        is_active = true,
        updated_at = NOW();
    
    -- Return success with expiry date
    v_result := jsonb_build_object(
        'success', true,
        'activated_at', NOW(),
        'expires_at', v_expires_at,
        'days_remaining', 7
    );
    
    RETURN v_result;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically deactivate expired plans
CREATE OR REPLACE FUNCTION deactivate_expired_plans()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE free_plan_users
    SET is_active = false,
        updated_at = NOW()
    WHERE expires_at < NOW() 
    AND is_active = true;
    
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger that runs daily
CREATE OR REPLACE FUNCTION create_deactivate_trigger()
RETURNS void AS $$
BEGIN
    -- Drop trigger if exists
    DROP TRIGGER IF EXISTS trigger_deactivate_expired_plans ON free_plan_users;
    
    -- Create trigger
    CREATE TRIGGER trigger_deactivate_expired_plans
    AFTER INSERT OR UPDATE ON free_plan_users
    FOR EACH STATEMENT
    EXECUTE FUNCTION deactivate_expired_plans();
END;
$$ LANGUAGE plpgsql;

-- Execute the trigger creation
SELECT create_deactivate_trigger();

-- Enable Row Level Security
ALTER TABLE free_plan_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_profile_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE free_plan_profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies for free_plan_users
CREATE POLICY "Users can view their own free plan"
    ON free_plan_users FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own free plan"
    ON free_plan_users FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- RLS Policies for daily_profile_limits
CREATE POLICY "Users can view their own daily limits"
    ON daily_profile_limits FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own daily limits"
    ON daily_profile_limits FOR UPDATE
    USING (auth.uid() = user_id);

-- RLS Policies for free_plan_profiles
CREATE POLICY "Users can view their own profiles"
    ON free_plan_profiles FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profiles"
    ON free_plan_profiles FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own profiles"
    ON free_plan_profiles FOR DELETE
    USING (auth.uid() = user_id);

-- Grant permissions
GRANT ALL ON free_plan_users TO authenticated;
GRANT ALL ON daily_profile_limits TO authenticated;
GRANT ALL ON free_plan_profiles TO authenticated;

-- Comments
COMMENT ON TABLE free_plan_users IS 'Tracks users who have activated the 7-day free plan';
COMMENT ON TABLE daily_profile_limits IS 'Tracks daily profile creation limits (10 per day for free plan)';
COMMENT ON TABLE free_plan_profiles IS 'Stores profiles created by free plan users';
COMMENT ON FUNCTION can_create_profile(UUID) IS 'Checks if user can create a profile today (under 10 limit)';
COMMENT ON FUNCTION increment_profile_count(UUID) IS 'Increments the daily profile count for a user';
COMMENT ON FUNCTION activate_free_plan(UUID) IS 'Activates 7-day free plan for a user';
