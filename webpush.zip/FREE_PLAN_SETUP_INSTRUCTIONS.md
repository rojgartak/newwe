# Free 7-Day Plan Setup Instructions

## 🎉 Features Added

✅ **Free 7-Day Plan** with following features:
- 10 profiles can be created per day
- Valid for 7 days from activation
- Daily limit resets at midnight
- All profiles stored in Supabase database
- Profile count tracking per user per day
- Automatic plan expiration after 7 days

## 📋 Setup Steps

### Step 1: Install Dependencies

Run this command in your project directory:

```bash
npm install
```

### Step 2: Setup Supabase Database

1. **Go to your Supabase Dashboard**
   - Open https://supabase.com/dashboard
   - Select your project

2. **Open SQL Editor**
   - Click on "SQL Editor" in the left sidebar
   - Click "New query"

3. **Run the Schema**
   - Copy all content from `supabase-free-plan-schema.sql` file
   - Paste it in the SQL editor
   - Click "Run" or press `Ctrl+Enter`

4. **Verify Tables Created**
   - Go to "Table Editor"
   - You should see these new tables:
     - `free_plan_users` - Tracks users with free plan
     - `daily_profile_limits` - Tracks daily profile creation limits
     - `free_plan_profiles` - Stores profiles created by free users

### Step 3: Test the Free Plan

1. **Start your development server:**
   ```bash
   npm run dev
   ```

2. **Test Flow:**
   - Go to pricing page
   - Click "Start Free Trial" on Free 7-Day Plan
   - User will be redirected to activate free plan
   - After activation, user can create 10 profiles per day

## 🔧 API Endpoints Created

### For Users:

1. **Activate Free Plan**
   - `POST /api/free-plan/activate`
   - Activates 7-day free plan for logged-in user

2. **Create Profile**
   - `POST /api/free-plan/create-profile`
   - Creates a profile (checks daily limit)
   - Body: `{ profileName: string, profileData: object }`

3. **Check Status**
   - `GET /api/free-plan/status`
   - Returns free plan status and remaining profiles for today

### For Admin:

4. **Free Plan Statistics**
   - `GET /api/admin/free-plan-stats`
   - Returns statistics about free plan usage

## 📊 Database Schema

### Tables Created:

1. **free_plan_users**
   - Tracks which users have activated free plan
   - Stores activation and expiry dates
   - Auto-deactivates expired plans

2. **daily_profile_limits**
   - Tracks daily profile creation count
   - Unique constraint on (user_id, date)
   - Max 10 profiles per day

3. **free_plan_profiles**
   - Stores actual profiles created by free users
   - Links to user_id
   - Stores profile data as JSONB

### Functions Created:

- `can_create_profile(user_id)` - Checks if user can create profile today
- `increment_profile_count(user_id)` - Increments daily count
- `activate_free_plan(user_id)` - Activates 7-day plan
- `deactivate_expired_plans()` - Auto-deactivates expired plans

## 🎯 How It Works

### Daily Limit Logic:

1. When user tries to create profile:
   - Check if they have active free plan
   - Check if plan is not expired (< 7 days)
   - Check today's profile count
   - If count < 10, allow creation
   - If count >= 10, block with error message

2. Profile count resets:
   - Automatically at midnight (new date)
   - Each day starts with 0 profiles created

3. Plan expiration:
   - After 7 days from activation
   - User needs to upgrade to paid plan

## 🔍 Admin Panel Integration

The admin panel now shows:
- **Free Plan Users Count** in Plans section
- **Total Free Profiles Created**
- **Active vs Expired Free Plans**
- **Profiles Created Today**

## 🚀 Testing Checklist

- [ ] Run SQL schema in Supabase
- [ ] Run `npm install`
- [ ] Start dev server
- [ ] Test free plan activation
- [ ] Create 10 profiles (should succeed)
- [ ] Try creating 11th profile (should fail with daily limit message)
- [ ] Check admin panel for stats
- [ ] Wait for next day or manually change date in DB to test reset

## ⚠️ Important Notes

1. **Daily Limit Reset**: Happens at midnight (00:00) based on server timezone
2. **Profile Storage**: All profiles stored in Supabase, safe and persistent
3. **Auto Expiry**: Plans automatically expire after 7 days
4. **No Payment Required**: Completely free trial, no credit card needed

## 📱 User Flow

```
User visits pricing page
    ↓
Clicks "Start Free Trial"
    ↓
Activates free 7-day plan
    ↓
Can create 10 profiles per day
    ↓
Daily limit resets at midnight
    ↓
After 7 days, plan expires
    ↓
User needs to upgrade to paid plan
```

## 🎨 What's Been Updated

### Frontend:
- ✅ Added Free 7-Day Plan card in PricingSection
- ✅ Updated grid to 4 columns (was 3)
- ✅ Added green Star icon for free plan

### Admin Panel:
- ✅ Added Free Plan count in Plans page
- ✅ Shows free users in statistics
- ✅ Updated revenue calculation (free = ₹0)
- ✅ Table now shows all 4 plans

### Backend:
- ✅ Created 3 new API routes for free plan
- ✅ Created 1 admin API for free plan stats
- ✅ Updated existing plan-stats API

### Database:
- ✅ Created 3 new tables
- ✅ Created 4 PostgreSQL functions
- ✅ Added Row Level Security policies
- ✅ Created indexes for performance

## 💡 Next Steps

After setup is complete:
1. Test the free plan flow thoroughly
2. Monitor profile creation in Supabase dashboard
3. Check admin panel statistics
4. Customize profile creation logic as needed

## 🆘 Troubleshooting

**Q: SQL script fails to run?**
- Make sure you're using PostgreSQL 12+
- Check if uuid-ossp extension is enabled
- Run script in parts if needed

**Q: Can't create profile?**
- Check if user has activated free plan
- Verify plan hasn't expired
- Check daily limit (10 profiles/day)
- Look at browser console for errors

**Q: Admin panel not showing free users?**
- Refresh the statistics
- Check if SQL tables were created
- Verify API endpoint is working

---

🎉 **Setup complete! Enjoy your Free 7-Day Plan feature!**
