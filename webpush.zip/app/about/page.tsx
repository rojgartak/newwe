'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Shield, Users, Zap, Globe } from 'lucide-react'

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">About BeastBrowser</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              BEAST BROWSER is India's leading anti-detection browser solution, empowering professionals and businesses with unparalleled privacy, security, and multi-profile management capabilities.
            </p>
          </motion.div>
        </div>
      </section>
      <section className="py-20">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
                Our <span className="gradient-text">Mission</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                In today's digital world, online privacy and security have become more critical than ever. Traditional browsers expose users to tracking, fingerprinting, and detection by sophisticated systems.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                BEAST BROWSER was created to level the playing field, giving users the power to browse anonymously, manage multiple identities, and stay undetected while conducting legitimate business activities.
              </p>
              <div className="mt-8 p-6 bg-gradient-to-r from-primary-orange/10 to-primary-red/10 rounded-lg border border-primary-orange/20">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Company Information</h3>
                <div className="text-sm text-gray-700 space-y-1">
                  <p><strong>Company:</strong> BEAST BROWSER</p>
                  <p><strong>Trade Name:</strong> ROHIT SRIVASTAV</p>
                  <p><strong>Registered Office:</strong> bhawarnath temple, AZAMGARH, UTTAR PRADESH Pin 276001</p>
                  <p><strong>Jurisdiction:</strong> Courts in Azamgarh and Uttar Pradesh, India</p>
                  <p><strong>Compliance:</strong> Information Technology Act, 2000 & Indian Privacy Laws</p>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="grid grid-cols-2 gap-6"
            >
              <div className="bg-white rounded-2xl shadow-lg border p-6 text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Privacy First</h3>
                <p className="text-sm text-gray-600">Your privacy is our top priority</p>
              </div>
              
              <div className="bg-white rounded-2xl shadow-lg border p-6 text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Cutting Edge</h3>
                <p className="text-sm text-gray-600">Advanced anti-detection technology</p>
              </div>
              
              <div className="bg-white rounded-2xl shadow-lg border p-6 text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">User Focused</h3>
                <p className="text-sm text-gray-600">Built for professionals like you</p>
              </div>
              
              <div className="bg-white rounded-2xl shadow-lg border p-6 text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Global Reach</h3>
                <p className="text-sm text-gray-600">Trusted worldwide</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Our <span className="gradient-text">Values</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide everything we do at BeastBrowser.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center"
            >
              <h3 className="text-xl font-bold text-gray-900 mb-4">Innovation</h3>
              <p className="text-gray-600">We constantly push the boundaries of what's possible in browser technology and anti-detection capabilities.</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center"
            >
              <h3 className="text-xl font-bold text-gray-900 mb-4">Security</h3>
              <p className="text-gray-600">Your data and privacy are protected with enterprise-grade security measures and encryption.</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center"
            >
              <h3 className="text-xl font-bold text-gray-900 mb-4">Excellence</h3>
              <p className="text-gray-600">We strive for excellence in every aspect of our product, from performance to user experience.</p>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}