'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Download, Monitor, Apple, CheckCircle, ArrowRight, Terminal } from 'lucide-react'
import Link from 'next/link'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'
import { useRouter } from 'next/navigation'

export default function DownloadPage() {
  const { user, loading } = useSupabaseAuth()
  const router = useRouter()
  const [selectedOS, setSelectedOS] = useState<string | null>(null)

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login')
    }
  }, [user, loading, router])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-primary-orange border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const osOptions = [
    {
      id: 'windows',
      name: 'Windows',
      icon: Monitor,
      version: 'v2.0.5',
      size: '341 MB',
      description: 'Windows 10, 11 (64-bit)',
      downloadUrl: '/BeastBrowser-Setup-2.0.5.exe.zip',
      popular: true
    },
    {
      id: 'macos',
      name: 'macOS',
      icon: Apple,
      version: 'v2.0.3',
      size: '38.7 MB',
      description: 'macOS 10.15 and later',
      downloadUrl: '#',
      recommended: true
    },
    {
      id: 'linux',
      name: 'Linux',
      icon: Terminal,
      version: 'v2.0.3',
      size: '42.1 MB',
      description: 'Ubuntu 18.04+, Debian 10+, CentOS 8+',
      downloadUrl: '#'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center mb-6">
            <div className="bg-primary-orange/10 p-3 rounded-full">
              <Download className="w-8 h-8 text-primary-orange" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Download BeastBrowser
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Choose your operating system to download the latest version
          </p>
        </motion.div>

        {/* Download Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {osOptions.map((os, index) => {
            const IconComponent = os.icon
            return (
              <motion.div
                key={os.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className={`relative bg-white rounded-2xl shadow-lg p-6 cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${
                  selectedOS === os.id ? 'ring-2 ring-primary-orange' : ''
                } ${os.popular ? 'border-2 border-green-200' : ''} ${os.recommended ? 'border-2 border-primary-orange' : ''}`}
                onClick={() => setSelectedOS(os.id)}
              >
                {os.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-green-500 text-white text-xs font-semibold px-3 py-1 rounded-full">
                      Most Popular
                    </span>
                  </div>
                )}
                {os.recommended && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-primary-orange text-white text-xs font-semibold px-3 py-1 rounded-full">
                      Recommended
                    </span>
                  </div>
                )}

                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-gray-700" />
                  </div>

                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{os.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{os.description}</p>

                  <div className="space-y-2 text-sm text-gray-500 mb-4">
                    <div className="flex justify-between">
                      <span>Version:</span>
                      <span className="font-medium">{os.version}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Size:</span>
                      <span className="font-medium">{os.size}</span>
                    </div>
                  </div>

                  {selectedOS === os.id && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="flex items-center justify-center text-green-600 mb-4"
                    >
                      <CheckCircle className="w-5 h-5 mr-2" />
                      <span className="text-sm font-medium">Selected</span>
                    </motion.div>
                  )}

                  <button 
                    className="w-full bg-primary-orange text-white py-3 px-6 rounded-lg font-semibold hover:bg-primary-red transition-colors duration-200 flex items-center justify-center"
                    onClick={() => {
                      if (os.downloadUrl !== '#') {
                        window.open(os.downloadUrl, '_blank');
                      }
                    }}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download for {os.name}
                  </button>
                </div>
              </motion.div>
            )
          })}
        </div>

        {/* System Requirements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="bg-white rounded-2xl shadow-lg p-8 mb-8"
        >
          <h2 className="text-2xl font-semibold text-gray-900 mb-6 text-center">
            System Requirements
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <Monitor className="w-8 h-8 text-primary-orange mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Windows</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Windows 10, 11 (64-bit)</li>
                <li>• 2GB RAM minimum</li>
                <li>• 100MB free disk space</li>
              </ul>
            </div>

            <div className="text-center">
              <Apple className="w-8 h-8 text-primary-orange mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">macOS</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• macOS 10.15 and later</li>
                <li>• 2GB RAM minimum</li>
                <li>• 100MB free disk space</li>
              </ul>
            </div>

            <div className="text-center">
              <Terminal className="w-8 h-8 text-primary-orange mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Linux</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Ubuntu 18.04+, Debian 10+</li>
                <li>• 2GB RAM minimum</li>
                <li>• 100MB free disk space</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="text-center"
        >
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link
              href="/dashboard"
              className="inline-flex items-center px-8 py-3 bg-white border-2 border-gray-200 text-gray-900 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Go to Dashboard
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>

            <Link
              href="/support"
              className="text-primary-orange hover:text-primary-red font-medium"
            >
              Need Installation Help?
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  )
}