import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const apiKey = process.env.NOWPAYMENTS_API_KEY;
    
    console.log('Testing NOWPayments API Key:', {
      apiKeyExists: !!apiKey,
      apiKeyLength: apiKey?.length,
      apiKeyPreview: apiKey?.substring(0, 15) + '***'
    });

    if (!apiKey) {
      return NextResponse.json({
        success: false,
        error: 'API Key not found in environment variables'
      }, { status: 500 });
    }

    // Test API call to get status
    const response = await fetch('https://api.nowpayments.io/v1/status', {
      method: 'GET',
      headers: {
        'x-api-key': apiKey.trim(),
        'Content-Type': 'application/json'
      }
    });

    const responseText = await response.text();
    
    console.log('NOWPayments Status Response:', {
      status: response.status,
      statusText: response.statusText,
      body: responseText
    });

    let data;
    try {
      data = JSON.parse(responseText);
    } catch {
      data = { rawResponse: responseText };
    }

    if (!response.ok) {
      return NextResponse.json({
        success: false,
        error: 'API Key validation failed',
        details: {
          status: response.status,
          statusText: response.statusText,
          response: data
        }
      }, { status: response.status });
    }

    return NextResponse.json({
      success: true,
      message: 'API Key is valid',
      apiStatus: data
    });

  } catch (error: any) {
    console.error('NOWPayments test error:', error);
    return NextResponse.json({
      success: false,
      error: error.message || 'Test failed'
    }, { status: 500 });
  }
}
