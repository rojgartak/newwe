import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function GET() {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    console.log('=== FETCHING PAYMENTS DATA ===')
    
    // Get all payments with user email
    const { data: payments, error } = await supabaseAdmin
      .from('payments')
      .select(`
        *,
        users!inner(email)
      `)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error fetching payments:', error)
      return NextResponse.json({
        success: false,
        error: 'Failed to fetch payments',
        details: error.message
      }, { status: 500 })
    }

    // Format payments data to include user email
    const formattedPayments = payments?.map(payment => ({
      id: payment.id,
      user_id: payment.user_id,
      amount: payment.amount,
      currency: payment.currency,
      status: payment.status,
      payment_gateway: payment.payment_gateway,
      gateway_payment_id: payment.gateway_payment_id,
      created_at: payment.created_at,
      user_email: payment.users?.email || 'N/A'
    })) || []

    console.log(`Found ${formattedPayments.length} payments`)

    return NextResponse.json({
      success: true,
      payments: formattedPayments,
      count: formattedPayments.length
    }, {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    })

  } catch (error) {
    console.error('Error in payments API:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}
