import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function GET() {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    console.log('=== FETCHING ALL USERS (ADMIN PANEL) ===')
    
    // First, get all users from Supabase Auth
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (authError) {
      console.error('Error fetching auth users:', authError)
      return NextResponse.json({
        success: false,
        error: 'Failed to fetch auth users: ' + authError.message,
        users: [],
        count: 0
      })
    }
    
    console.log(`✅ Found ${authData.users.length} users in Supabase Auth`)
    
    // Get users from database
    const { data: dbUsers, error: dbError } = await supabaseAdmin
      .from('users')
      .select('*')
      .order('created_at', { ascending: false })
    
    if (dbError) {
      console.error('Error fetching database users:', dbError)
      // Don't fail completely - we can sync from auth
    } else {
      console.log(`✅ Found ${dbUsers?.length || 0} users in database`)
    }
    
    // Always sync missing users from auth to database
    if (authData && authData.users.length > 0) {
      console.log('🔄 Syncing auth users to database...')
      
      const dbUserEmails = new Set((dbUsers || []).map(u => u.email))
      let syncedCount = 0
      
      for (const authUser of authData.users) {
        // Skip if user already exists in database
        if (dbUserEmails.has(authUser.email || '')) {
          continue
        }
        
        try {
          const { error: insertError } = await supabaseAdmin
            .from('users')
            .insert({
              id: authUser.id,
              email: authUser.email || '',
              subscription_status: 'inactive',
              subscription_plan: null,
              subscription_expires_at: null,
              profiles_created: 0,
              last_login: authUser.last_sign_in_at || authUser.created_at,
              created_at: authUser.created_at,
              updated_at: new Date().toISOString()
            })
          
          if (insertError && !insertError.message.includes('duplicate key')) {
            console.error(`❌ Error inserting user ${authUser.email}:`, insertError)
          } else {
            console.log(`✅ Synced user: ${authUser.email}`)
            syncedCount++
          }
        } catch (error) {
          console.error(`❌ Error processing user ${authUser.email}:`, error)
        }
      }
      
      console.log(`🎉 Synced ${syncedCount} new users to database`)
      
      // Fetch users again after sync
      const { data: syncedUsers, error: syncError } = await supabaseAdmin
        .from('users')
        .select('*')
        .order('created_at', { ascending: false })
      
      if (!syncError) {
        console.log(`After sync: ${syncedUsers?.length || 0} users in database`)
        return NextResponse.json({
          success: true,
          users: syncedUsers || [],
          count: syncedUsers?.length || 0,
          synced: true
        })
      }
    }
    
    // Return database users with no-cache headers
    const response = NextResponse.json({
      success: true,
      users: dbUsers || [],
      count: dbUsers?.length || 0,
      authUsers: authData?.users.length || 0,
      synced: false,
      timestamp: new Date().toISOString()
    })
    
    // Add no-cache headers
    response.headers.set('Cache-Control', 'no-cache, no-store, must-revalidate')
    response.headers.set('Pragma', 'no-cache')
    response.headers.set('Expires', '0')
    
    return response
    
  } catch (error) {
    console.error('Error in users-simple API:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}
