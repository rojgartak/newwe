import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

/**
 * Test API: Check Users in Admin Panel
 * GET /api/admin/test-users
 */
export async function GET() {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    console.log('🧪 TESTING ADMIN USERS API')
    
    // Test 1: Check Auth Users
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.listUsers()
    
    console.log('Auth Users Result:', {
      success: !authError,
      count: authData?.users?.length || 0,
      error: authError?.message
    })
    
    // Test 2: Check Database Users
    const { data: dbUsers, error: dbError } = await supabaseAdmin
      .from('users')
      .select('*')
      .order('created_at', { ascending: false })
    
    console.log('Database Users Result:', {
      success: !dbError,
      count: dbUsers?.length || 0,
      error: dbError?.message
    })
    
    // Test 3: Sample Data
    const sampleAuthUser = authData?.users?.[0]
    const sampleDbUser = dbUsers?.[0]
    
    return NextResponse.json({
      success: true,
      timestamp: new Date().toISOString(),
      tests: {
        auth: {
          success: !authError,
          count: authData?.users?.length || 0,
          error: authError?.message,
          sample: sampleAuthUser ? {
            id: sampleAuthUser.id,
            email: sampleAuthUser.email,
            created_at: sampleAuthUser.created_at
          } : null
        },
        database: {
          success: !dbError,
          count: dbUsers?.length || 0,
          error: dbError?.message,
          sample: sampleDbUser ? {
            id: sampleDbUser.id,
            email: sampleDbUser.email,
            subscription_status: sampleDbUser.subscription_status,
            created_at: sampleDbUser.created_at
          } : null
        }
      },
      recommendations: [
        authError ? '❌ Fix Supabase auth connection' : '✅ Auth connection working',
        dbError ? '❌ Fix database connection' : '✅ Database connection working',
        (authData?.users?.length || 0) === 0 ? '⚠️ No users in auth - create test user' : `✅ ${authData?.users?.length} users in auth`,
        (dbUsers?.length || 0) === 0 ? '⚠️ No users in database - sync needed' : `✅ ${dbUsers?.length} users in database`
      ]
    })
    
  } catch (error: any) {
    console.error('Test API error:', error)
    return NextResponse.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}
