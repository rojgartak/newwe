import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

/**
 * Admin API: Sync Data Between Tables
 * POST /api/admin/sync-data
 */
export async function POST(request: NextRequest) {
  try {
    const supabase = createSupabaseAdmin()
    
    console.log('🔄 Starting data sync...')
    
    // Get all users with active subscriptions but no subscription records
    const { data: activeUsers, error: usersError } = await supabase
      .from('users')
      .select('*')
      .eq('subscription_status', 'active')
    
    if (usersError) {
      throw new Error('Failed to fetch active users: ' + usersError.message)
    }
    
    console.log(`Found ${activeUsers?.length || 0} active users`)
    
    let syncedCount = 0
    const results = []
    
    for (const user of activeUsers || []) {
      try {
        // Check if subscription record already exists
        const { data: existingSubscription } = await supabase
          .from('subscriptions')
          .select('id')
          .eq('user_email', user.email)
          .single()
        
        if (existingSubscription) {
          console.log(`✅ Subscription already exists for ${user.email}`)
          continue
        }
        
        // Calculate amount based on plan
        const amount = user.subscription_plan === 'yearly' ? 21165 : 2550
        
        // Create subscription record
        const { data: newSubscription, error: subscriptionError } = await supabase
          .from('subscriptions')
          .insert({
            user_id: user.id,
            user_email: user.email,
            plan_type: user.subscription_plan || 'monthly',
            status: 'active',
            expires_at: user.subscription_expires_at,
            amount: amount,
            currency: 'INR',
            payment_gateway: 'admin',
            order_id: `SYNC_${user.id}_${Date.now()}`,
            created_at: user.created_at,
            updated_at: new Date().toISOString()
          })
          .select()
          .single()
        
        if (subscriptionError) {
          console.error(`❌ Failed to create subscription for ${user.email}:`, subscriptionError)
          results.push({
            email: user.email,
            success: false,
            error: subscriptionError.message
          })
        } else {
          console.log(`✅ Created subscription for ${user.email}`)
          syncedCount++
          results.push({
            email: user.email,
            success: true,
            subscriptionId: newSubscription.id
          })
        }
        
      } catch (error: any) {
        console.error(`❌ Error processing user ${user.email}:`, error)
        results.push({
          email: user.email,
          success: false,
          error: error.message
        })
      }
    }
    
    // Also sync auth users to public users
    const { data: authUsers, error: authError } = await supabase.auth.admin.listUsers()
    
    if (!authError && authUsers) {
      console.log(`🔄 Syncing ${authUsers.users.length} auth users to public users...`)
      
      for (const authUser of authUsers.users) {
        try {
          // Check if user exists in public.users
          const { data: existingUser } = await supabase
            .from('users')
            .select('id')
            .eq('email', authUser.email || '')
            .single()
          
          if (!existingUser && authUser.email) {
            // Create user in public.users
            const { error: insertError } = await supabase
              .from('users')
              .insert({
                id: authUser.id,
                email: authUser.email,
                subscription_status: 'inactive',
                subscription_plan: null,
                subscription_expires_at: null,
                profiles_created: 0,
                last_login: authUser.last_sign_in_at || authUser.created_at,
                created_at: authUser.created_at,
                updated_at: new Date().toISOString()
              })
            
            if (!insertError) {
              console.log(`✅ Synced auth user to public: ${authUser.email}`)
            }
          }
        } catch (error) {
          console.error(`❌ Error syncing auth user ${authUser.email}:`, error)
        }
      }
    }
    
    return NextResponse.json({
      success: true,
      message: 'Data sync completed',
      results: {
        totalActiveUsers: activeUsers?.length || 0,
        syncedSubscriptions: syncedCount,
        details: results
      }
    })
    
  } catch (error: any) {
    console.error('❌ Data sync error:', error)
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    )
  }
}
