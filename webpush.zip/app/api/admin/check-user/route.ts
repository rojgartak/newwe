import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return NextResponse.json({
        success: false,
        error: 'User ID is required'
      }, { status: 400 })
    }

    const supabaseAdmin = createSupabaseAdmin()
    
    // Get specific user data
    const { data: user, error } = await supabaseAdmin
      .from('users')
      .select('*')
      .eq('id', userId)
      .single()

    if (error) {
      console.error('Error fetching user:', error)
      return NextResponse.json({
        success: false,
        error: 'Failed to fetch user',
        details: error.message
      }, { status: 500 })
    }

    console.log('User data:', user)

    return NextResponse.json({
      success: true,
      user: user,
      message: 'User data fetched successfully'
    })

  } catch (error) {
    console.error('Error in check-user API:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}
