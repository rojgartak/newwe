import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

/**
 * Admin API: Create Test Data
 * POST /api/admin/create-test-data
 */
export async function POST(request: NextRequest) {
  try {
    const supabase = createSupabaseAdmin()
    
    console.log('🧪 Creating test data...')
    
    const testUsers = [
      {
        email: 'premium-user@beastbrowser.com',
        plan: 'monthly',
        status: 'active'
      },
      {
        email: 'yearly-user@beastbrowser.com', 
        plan: 'yearly',
        status: 'active'
      },
      {
        email: 'expired-user@beastbrowser.com',
        plan: 'monthly', 
        status: 'expired'
      }
    ]
    
    const results = []
    
    for (const testUser of testUsers) {
      try {
        // Create user in auth
        const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
          email: testUser.email,
          password: 'test123456',
          email_confirm: true,
          user_metadata: {
            display_name: testUser.email.split('@')[0]
          }
        })
        
        if (authError) {
          console.log(`⚠️ Auth user might already exist: ${testUser.email}`)
        }
        
        const userId = authUser?.user?.id || `test-${Date.now()}-${Math.random()}`
        
        // Calculate dates
        const now = new Date()
        let expiresAt = new Date(now)
        
        if (testUser.status === 'expired') {
          expiresAt = new Date('2024-01-01') // Past date
        } else if (testUser.plan === 'yearly') {
          expiresAt.setFullYear(expiresAt.getFullYear() + 1)
        } else {
          expiresAt.setMonth(expiresAt.getMonth() + 1)
        }
        
        const amount = testUser.plan === 'yearly' ? 21165 : 2550
        
        // Create/update user in public.users
        const { error: userError } = await supabase
          .from('users')
          .upsert({
            id: userId,
            email: testUser.email,
            subscription_status: testUser.status,
            subscription_plan: testUser.plan,
            subscription_expires_at: expiresAt.toISOString(),
            profiles_created: Math.floor(Math.random() * 10),
            created_at: now.toISOString(),
            updated_at: now.toISOString()
          })
        
        if (userError) {
          throw new Error(`Failed to create user: ${userError.message}`)
        }
        
        // Create subscription record
        const { data: subscription, error: subscriptionError } = await supabase
          .from('subscriptions')
          .insert({
            user_id: userId,
            user_email: testUser.email,
            plan_type: testUser.plan,
            status: testUser.status,
            expires_at: expiresAt.toISOString(),
            amount: amount,
            currency: 'INR',
            payment_gateway: 'admin',
            order_id: `TEST_${userId}_${testUser.plan}_${Date.now()}`,
            created_at: now.toISOString(),
            updated_at: now.toISOString()
          })
          .select()
          .single()
        
        if (subscriptionError) {
          throw new Error(`Failed to create subscription: ${subscriptionError.message}`)
        }
        
        // Create some profile creation records
        const profileCount = Math.floor(Math.random() * 5) + 1
        for (let i = 0; i < profileCount; i++) {
          await supabase
            .from('profile_creations')
            .insert({
              user_id: userId,
              profile_name: `Test Profile ${i + 1}`,
              browser_fingerprint: {
                userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                screen: { width: 1920, height: 1080 },
                timezone: 'Asia/Kolkata'
              },
              proxy_settings: {
                type: 'http',
                host: '127.0.0.1',
                port: 8080
              },
              created_at: new Date(now.getTime() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString()
            })
        }
        
        console.log(`✅ Created test data for ${testUser.email}`)
        results.push({
          email: testUser.email,
          success: true,
          userId: userId,
          subscriptionId: subscription.id,
          profilesCreated: profileCount
        })
        
      } catch (error: any) {
        console.error(`❌ Error creating test data for ${testUser.email}:`, error)
        results.push({
          email: testUser.email,
          success: false,
          error: error.message
        })
      }
    }
    
    return NextResponse.json({
      success: true,
      message: 'Test data created successfully',
      results: results
    })
    
  } catch (error: any) {
    console.error('❌ Test data creation error:', error)
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    )
  }
}
