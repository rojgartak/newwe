import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

/**
 * Admin API: Create User with Auto-Confirmed Email
 * 
 * POST /api/admin/create-user
 * Body: { email: string, password: string, displayName?: string }
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, displayName } = body

    if (!email || !password) {
      return NextResponse.json(
        { success: false, error: 'Email and password are required' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: 'Invalid email format' },
        { status: 400 }
      )
    }

    // Validate password length
    if (password.length < 6) {
      return NextResponse.json(
        { success: false, error: 'Password must be at least 6 characters' },
        { status: 400 }
      )
    }

    const supabase = createSupabaseAdmin()

    // Check if user already exists
    const { data: existingUsers } = await supabase.auth.admin.listUsers()
    const userExists = existingUsers?.users?.some(u => u.email === email.toLowerCase())

    if (userExists) {
      return NextResponse.json(
        { success: false, error: 'User with this email already exists' },
        { status: 409 }
      )
    }

    // Create user in auth with auto-confirmation
    const { data, error } = await supabase.auth.admin.createUser({
      email: email.toLowerCase(),
      password: password,
      email_confirm: true, // Auto-confirm email
      user_metadata: {
        display_name: displayName || email.split('@')[0]
      }
    })

    if (error) {
      console.error('Error creating user:', error)
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 400 }
      )
    }

    if (!data.user) {
      return NextResponse.json(
        { success: false, error: 'Failed to create user' },
        { status: 500 }
      )
    }

    // Create user in public.users table
    const { error: dbError } = await supabase
      .from('users')
      .insert({
        id: data.user.id,
        email: email.toLowerCase(),
        subscription_status: 'inactive',
        subscription_plan: null,
        subscription_expires_at: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })

    if (dbError) {
      console.error('Error creating user in database:', dbError)
      // Don't fail - auth user created successfully
    }

    return NextResponse.json({
      success: true,
      message: 'User created successfully',
      user: {
        id: data.user.id,
        email: data.user.email,
        displayName: displayName || email.split('@')[0],
        emailConfirmed: true
      }
    })

  } catch (error: any) {
    console.error('Error in create-user API:', error)
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to create user' },
      { status: 500 }
    )
  }
}
