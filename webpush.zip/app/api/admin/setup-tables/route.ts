import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    console.log('Setting up database tables...')
    
    // Create users table if it doesn't exist
    const createUsersTable = `
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        subscription_status TEXT DEFAULT 'inactive',
        subscription_plan TEXT,
        subscription_expires_at TIMESTAMPTZ,
        profiles_created INTEGER DEFAULT 0,
        last_login TIMESTAMPTZ,
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
    `
    
    // Create payments table if it doesn't exist
    const createPaymentsTable = `
      CREATE TABLE IF NOT EXISTS payments (
        id SERIAL PRIMARY KEY,
        user_id TEXT REFERENCES users(id),
        amount DECIMAL(10,2) NOT NULL,
        currency TEXT DEFAULT 'INR',
        status TEXT DEFAULT 'pending',
        payment_gateway TEXT NOT NULL,
        gateway_payment_id TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
    `
    
    // Create coupons table if it doesn't exist
    const createCouponsTable = `
      CREATE TABLE IF NOT EXISTS coupons (
        id SERIAL PRIMARY KEY,
        code TEXT UNIQUE NOT NULL,
        discount_percentage INTEGER NOT NULL,
        max_uses INTEGER DEFAULT 100,
        current_uses INTEGER DEFAULT 0,
        expires_at TIMESTAMPTZ NOT NULL,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
    `
    
    // Execute table creation queries
    const { error: usersError } = await supabaseAdmin.rpc('exec_sql', { 
      sql: createUsersTable 
    })
    
    if (usersError) {
      console.error('Error creating users table:', usersError)
    } else {
      console.log('Users table created/verified')
    }
    
    const { error: paymentsError } = await supabaseAdmin.rpc('exec_sql', { 
      sql: createPaymentsTable 
    })
    
    if (paymentsError) {
      console.error('Error creating payments table:', paymentsError)
    } else {
      console.log('Payments table created/verified')
    }
    
    const { error: couponsError } = await supabaseAdmin.rpc('exec_sql', { 
      sql: createCouponsTable 
    })
    
    if (couponsError) {
      console.error('Error creating coupons table:', couponsError)
    } else {
      console.log('Coupons table created/verified')
    }
    
    // Insert a test user to verify the table works
    const { data: testUser, error: insertError } = await supabaseAdmin
      .from('users')
      .insert({
        id: 'test_user_' + Date.now(),
        email: 'testuser@example.com',
        subscription_status: 'inactive',
        profiles_created: 0,
        created_at: new Date().toISOString()
      })
      .select()
    
    if (insertError) {
      console.error('Error inserting test user:', insertError)
    } else {
      console.log('Test user inserted successfully')
    }
    
    // Check if we can read users
    const { data: users, error: readError } = await supabaseAdmin
      .from('users')
      .select('*')
      .limit(5)
    
    if (readError) {
      console.error('Error reading users:', readError)
      return NextResponse.json({
        success: false,
        error: 'Failed to read users after setup',
        details: readError
      }, { status: 500 })
    }
    
    return NextResponse.json({
      success: true,
      message: 'Database tables setup completed',
      userCount: users?.length || 0,
      users: users
    })
    
  } catch (error) {
    console.error('Error setting up tables:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to setup database tables',
      details: (error as Error).message
    }, { status: 500 })
  }
}
