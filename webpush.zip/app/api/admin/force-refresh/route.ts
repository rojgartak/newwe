import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function GET() {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    console.log('=== FORCE REFRESH - DIRECT DATABASE QUERY ===')
    
    // Direct query with timestamp to avoid any caching
    const { data: users, error } = await supabaseAdmin
      .from('users')
      .select('*')
      .order('created_at', { ascending: false })
    
    if (error) {
      console.error('Error in force refresh:', error)
      return NextResponse.json({
        success: false,
        error: 'Failed to fetch users',
        details: error.message
      }, { status: 500 })
    }
    
    console.log(`Force refresh: Found ${users?.length || 0} users`)
    
    // Log specific user data for debugging
    const targetUser = users?.find(u => u.email === 'srivastavnikhil225@gmail.com')
    if (targetUser) {
      console.log('Target user data:', {
        email: targetUser.email,
        subscription_status: targetUser.subscription_status,
        subscription_plan: targetUser.subscription_plan,
        subscription_expires_at: targetUser.subscription_expires_at,
        updated_at: targetUser.updated_at || 'No update timestamp'
      })
    }
    
    const response = NextResponse.json({
      success: true,
      users: users || [],
      count: users?.length || 0,
      timestamp: new Date().toISOString(),
      targetUser: targetUser || null
    })
    
    // Strong no-cache headers
    response.headers.set('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
    response.headers.set('Pragma', 'no-cache')
    response.headers.set('Expires', '0')
    response.headers.set('Last-Modified', new Date().toUTCString())
    
    return response
    
  } catch (error) {
    console.error('Error in force refresh API:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}
