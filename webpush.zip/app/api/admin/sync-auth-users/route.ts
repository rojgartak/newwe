import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    console.log('=== SYNCING AUTH USERS TO DATABASE ===')
    
    // Get all users from Supabase Auth
    const { data: authUsers, error: authError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (authError) {
      console.error('Error fetching auth users:', authError)
      return NextResponse.json({
        success: false,
        error: 'Failed to fetch auth users',
        details: authError.message
      }, { status: 500 })
    }
    
    console.log(`Found ${authUsers.users.length} users in Supabase Auth`)
    
    let syncedCount = 0
    let errors: any[] = []
    
    // Sync each auth user to our users table
    for (const authUser of authUsers.users) {
      try {
        // Check if user already exists in our database
        const { data: existingUser } = await supabaseAdmin
          .from('users')
          .select('id')
          .eq('id', authUser.id)
          .single()
        
        if (!existingUser) {
          // User doesn't exist, create them
          const { error: insertError } = await supabaseAdmin
            .from('users')
            .insert({
              id: authUser.id,
              email: authUser.email || '',
              subscription_status: 'inactive',
              subscription_plan: null,
              subscription_expires_at: null,
              profiles_created: 0,
              last_login: authUser.last_sign_in_at || authUser.created_at,
              created_at: authUser.created_at
            })
          
          if (insertError) {
            console.error(`Error inserting user ${authUser.email}:`, insertError)
            errors.push({ user: authUser.email, error: insertError.message })
          } else {
            console.log(`Synced user: ${authUser.email}`)
            syncedCount++
          }
        } else {
          console.log(`User already exists: ${authUser.email}`)
        }
      } catch (error) {
        console.error(`Error processing user ${authUser.email}:`, error)
        errors.push({ user: authUser.email, error: (error as Error).message })
      }
    }
    
    // Get final count of users in database
    const { data: dbUsers, error: countError } = await supabaseAdmin
      .from('users')
      .select('id, email, created_at')
    
    return NextResponse.json({
      success: true,
      message: 'User sync completed',
      authUsersFound: authUsers.users.length,
      syncedCount: syncedCount,
      totalDbUsers: dbUsers?.length || 0,
      errors: errors,
      users: dbUsers || []
    })
    
  } catch (error) {
    console.error('Error syncing users:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}

// GET method to show current sync status
export async function GET() {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    // Get auth users count
    const { data: authUsers, error: authError } = await supabaseAdmin.auth.admin.listUsers()
    
    // Get database users count
    const { data: dbUsers, error: dbError } = await supabaseAdmin
      .from('users')
      .select('*')
    
    return NextResponse.json({
      success: true,
      authUsers: authUsers?.users.length || 0,
      dbUsers: dbUsers?.length || 0,
      authUsersList: authUsers?.users.map(u => ({ id: u.id, email: u.email, created: u.created_at })) || [],
      dbUsersList: dbUsers || [],
      needsSync: (authUsers?.users.length || 0) > (dbUsers?.length || 0)
    })
    
  } catch (error) {
    console.error('Error getting sync status:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}
