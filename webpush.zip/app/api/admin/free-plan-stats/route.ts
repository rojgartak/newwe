import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdmin } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseAdmin();

    // Get total free plan users
    const { count: totalFreePlanUsers, error: usersError } = await supabase
      .from('free_plan_users')
      .select('*', { count: 'exact', head: true });

    if (usersError) {
      console.error('Error fetching free plan users:', usersError);
    }

    // Get active free plan users (not expired)
    const { count: activeFreePlanUsers, error: activeError } = await supabase
      .from('free_plan_users')
      .select('*', { count: 'exact', head: true })
      .eq('is_active', true)
      .gt('expires_at', new Date().toISOString());

    if (activeError) {
      console.error('Error fetching active free plan users:', activeError);
    }

    // Get total profiles created by free users
    const { count: totalFreeProfiles, error: profilesError } = await supabase
      .from('free_plan_profiles')
      .select('*', { count: 'exact', head: true });

    if (profilesError) {
      console.error('Error fetching free profiles:', profilesError);
    }

    // Get today's profile count
    const today = new Date().toISOString().split('T')[0];
    const { data: todayLimits, error: todayError } = await supabase
      .from('daily_profile_limits')
      .select('profiles_created')
      .eq('date', today);

    let profilesToday = 0;
    if (todayLimits) {
      profilesToday = todayLimits.reduce((sum, item) => sum + (item.profiles_created || 0), 0);
    }

    // Get expired plans count
    const { count: expiredPlans, error: expiredError } = await supabase
      .from('free_plan_users')
      .select('*', { count: 'exact', head: true })
      .lt('expires_at', new Date().toISOString());

    if (expiredError) {
      console.error('Error fetching expired plans:', expiredError);
    }

    return NextResponse.json({
      success: true,
      stats: {
        totalFreePlanUsers: totalFreePlanUsers || 0,
        activeFreePlanUsers: activeFreePlanUsers || 0,
        expiredFreePlanUsers: expiredPlans || 0,
        totalFreeProfiles: totalFreeProfiles || 0,
        profilesCreatedToday: profilesToday
      }
    });

  } catch (error: any) {
    console.error('Free plan stats error:', error);
    return NextResponse.json({ 
      success: false, 
      error: error.message || 'Failed to fetch free plan statistics' 
    }, { status: 500 });
  }
}
