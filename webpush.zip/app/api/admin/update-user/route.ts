import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function PUT(request: NextRequest) {
  try {
    const { userId, status, plan } = await request.json()
    
    if (!userId || !status) {
      return NextResponse.json({
        success: false,
        error: 'Missing required fields'
      }, { status: 400 })
    }

    console.log('Updating user subscription:', { userId, status, plan })

    const supabaseAdmin = createSupabaseAdmin()
    
    const updateData: any = { 
      subscription_status: status,
      last_login: new Date().toISOString()
    }
    
    if (plan) {
      updateData.subscription_plan = plan
      
      // Set expiry date based on plan
      const expiryDate = new Date()
      if (plan === 'yearly') {
        expiryDate.setFullYear(expiryDate.getFullYear() + 1)
      } else if (plan === 'monthly') {
        expiryDate.setMonth(expiryDate.getMonth() + 1)
      }
      updateData.subscription_expires_at = expiryDate.toISOString()
    }

    const { data, error } = await supabaseAdmin
      .from('users')
      .update(updateData)
      .eq('id', userId)
      .select()

    if (error) {
      console.error('Error updating user subscription:', error)
      return NextResponse.json({
        success: false,
        error: 'Failed to update user subscription',
        details: error.message
      }, { status: 500 })
    }

    console.log('User subscription updated successfully:', data)
    console.log('Update data sent:', updateData)

    return NextResponse.json({
      success: true,
      message: 'User subscription updated successfully',
      user: data?.[0] || null
    })

  } catch (error) {
    console.error('Error in update-user API:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}
