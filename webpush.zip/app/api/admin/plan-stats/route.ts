import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdmin } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseAdmin();

    // Get count of users by subscription status
    const { data: users, error } = await supabase
      .from('users')
      .select('subscription_status, subscription_plan');

    if (error) {
      console.error('Error fetching users:', error);
      return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    }

    // Calculate plan statistics based on actual website pricing
    let freeCount = 0;
    let starterCount = 0;
    let monthlyCount = 0;
    let yearlyCount = 0;

    users?.forEach(user => {
      if (user.subscription_status === 'active') {
        if (user.subscription_plan === 'monthly') {
          monthlyCount++;
        } else if (user.subscription_plan === 'yearly') {
          yearlyCount++;
        }
      }
      // Check if user has a 24-hour plan (you may need to add a field for this)
      // For now, we'll assume starter plans are tracked separately
    });

    // Get free plan users count
    const { count: freePlanCount, error: freeError } = await supabase
      .from('free_plan_users')
      .select('*', { count: 'exact', head: true })
      .eq('is_active', true)
      .gt('expires_at', new Date().toISOString());

    if (!freeError) {
      freeCount = freePlanCount || 0;
    }

    // Calculate revenue based on actual prices:
    // Free: ₹0 (7 days)
    // Starter: ₹266 (24 hours)
    // Monthly Premium: ₹2,665 per month
    // Yearly Premium: ₹22,122 per year
    const totalRevenue = (starterCount * 266) + (monthlyCount * 2665) + (yearlyCount * 22122);

    return NextResponse.json({
      success: true,
      freeCount,
      starterCount,
      monthlyCount,
      yearlyCount,
      totalRevenue,
      totalUsers: users?.length || 0
    });
  } catch (error: any) {
    console.error('Plan stats error:', error);
    return NextResponse.json({ 
      success: false, 
      error: error.message || 'Failed to fetch plan statistics' 
    }, { status: 500 });
  }
}
