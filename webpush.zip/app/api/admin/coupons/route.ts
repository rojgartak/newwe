import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

// GET - Fetch all coupons
export async function GET() {
  try {
    console.log('🎫 Fetching coupons...')
    
    const supabaseAdmin = createSupabaseAdmin()
    
    const { data: coupons, error } = await supabaseAdmin
      .from('coupons')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) {
      console.error('❌ Supabase error:', error.message)
      return NextResponse.json({ 
        success: false,
        error: 'Failed to fetch coupons',
        details: error.message
      }, { 
        status: 500,
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      })
    }

    console.log(`✅ Fetched ${coupons?.length || 0} coupons`)
    
    // Return coupons directly (original format) or with success wrapper
    return NextResponse.json({
      success: true,
      coupons: coupons || [],
      count: coupons?.length || 0
    }, {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    })
  } catch (error) {
    console.error('❌ Coupons API error:', error)
    return NextResponse.json({ 
      success: false,
      error: 'Internal server error',
      details: (error as Error).message 
    }, { 
      status: 500,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    })
  }
}

// POST - Create new coupon
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { code, discount_percentage, max_uses, expires_at, is_active } = body

    if (!code || !discount_percentage) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const supabaseAdmin = createSupabaseAdmin()

    // Check if coupon code already exists
    const { data: existingCoupon } = await supabaseAdmin
      .from('coupons')
      .select('id')
      .eq('code', code.toUpperCase())
      .single()

    if (existingCoupon) {
      return NextResponse.json({ error: 'Coupon code already exists' }, { status: 400 })
    }

    // Create new coupon
    const couponData = {
      code: code.toUpperCase(),
      discount_percentage,
      max_uses: max_uses || 100,
      current_uses: 0,
      expires_at,
      is_active: is_active !== undefined ? is_active : true
    }

    const { data: newCoupon, error } = await supabaseAdmin
      .from('coupons')
      .insert(couponData)
      .select()
      .single()

    if (error) {
      console.error('Error creating coupon:', error)
      return NextResponse.json({ error: 'Failed to create coupon' }, { status: 500 })
    }

    return NextResponse.json(newCoupon)
  } catch (error) {
    console.error('Error in coupons POST:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// PUT - Update coupon
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, code, discount_percentage, max_uses, expires_at, is_active } = body

    if (!id) {
      return NextResponse.json({ error: 'Coupon ID is required' }, { status: 400 })
    }

    const supabaseAdmin = createSupabaseAdmin()

    const couponData = {
      code: code?.toUpperCase(),
      discount_percentage,
      max_uses,
      expires_at,
      is_active
    }

    // Remove undefined values
    Object.keys(couponData).forEach(key => {
      if (couponData[key as keyof typeof couponData] === undefined) {
        delete couponData[key as keyof typeof couponData]
      }
    })

    const { data: updatedCoupon, error } = await supabaseAdmin
      .from('coupons')
      .update(couponData)
      .eq('id', id)
      .select()
      .single()

    if (error) {
      console.error('Error updating coupon:', error)
      return NextResponse.json({ error: 'Failed to update coupon' }, { status: 500 })
    }

    return NextResponse.json(updatedCoupon)
  } catch (error) {
    console.error('Error in coupons PUT:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// DELETE - Delete coupon
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Coupon ID is required' }, { status: 400 })
    }

    const supabaseAdmin = createSupabaseAdmin()

    const { error } = await supabaseAdmin
      .from('coupons')
      .delete()
      .eq('id', id)

    if (error) {
      console.error('Error deleting coupon:', error)
      return NextResponse.json({ error: 'Failed to delete coupon' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error in coupons DELETE:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
