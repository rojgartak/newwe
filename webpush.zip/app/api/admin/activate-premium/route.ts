import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

/**
 * Admin API: Activate Premium Subscription for User
 * 
 * POST /api/admin/activate-premium
 * Body: { email: string, plan: 'monthly' | 'yearly' }
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, plan } = body

    if (!email || !plan) {
      return NextResponse.json(
        { success: false, error: 'Email and plan are required' },
        { status: 400 }
      )
    }

    if (!['monthly', 'yearly'].includes(plan)) {
      return NextResponse.json(
        { success: false, error: 'Plan must be monthly or yearly' },
        { status: 400 }
      )
    }

    const supabase = createSupabaseAdmin()

    // Calculate expiry date
    const now = new Date()
    const expiresAt = new Date(now)
    if (plan === 'monthly') {
      expiresAt.setMonth(expiresAt.getMonth() + 1)
    } else {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1)
    }

    // Get or create user
    const { data: existingUser, error: userError } = await supabase
      .from('users')
      .select('id')
      .eq('email', email.toLowerCase())
      .single()

    let userId: string

    if (existingUser) {
      userId = existingUser.id
      
      // Update existing user
      const { error: updateError } = await supabase
        .from('users')
        .update({
          subscription_status: 'active',
          subscription_plan: plan,
          subscription_expires_at: expiresAt.toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', userId)

      if (updateError) {
        console.error('Error updating user:', updateError)
        return NextResponse.json(
          { success: false, error: 'Failed to update user' },
          { status: 500 }
        )
      }
    } else {
      // Create new user
      const { data: newUser, error: createError } = await supabase
        .from('users')
        .insert({
          email: email.toLowerCase(),
          subscription_status: 'active',
          subscription_plan: plan,
          subscription_expires_at: expiresAt.toISOString(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select('id')
        .single()

      if (createError || !newUser) {
        console.error('Error creating user:', createError)
        return NextResponse.json(
          { success: false, error: 'Failed to create user' },
          { status: 500 }
        )
      }

      userId = newUser.id
    }

    // Create subscription record
    const amount = plan === 'monthly' ? 2550 : 21165
    
    const { error: subscriptionError } = await supabase
      .from('subscriptions')
      .insert({
        user_id: userId,
        user_email: email.toLowerCase(),
        plan_type: plan,
        status: 'active',
        expires_at: expiresAt.toISOString(),
        amount: amount,
        payment_gateway: 'admin',
        order_id: `ADMIN_${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })

    if (subscriptionError) {
      console.error('Error creating subscription:', subscriptionError)
      // Don't return error - user already updated
    }

    // Send premium activation email via Supabase Edge Function
    try {
      const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
      const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      
      const emailResponse = await fetch(`${supabaseUrl}/functions/v1/send-premium-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${serviceKey}`
        },
        body: JSON.stringify({
          email: email,
          plan: plan,
          expiresAt: expiresAt.toISOString()
        })
      })
      
      if (emailResponse.ok) {
        console.log(`📧 Premium activation email sent to ${email} via Edge Function`)
      } else {
        console.error('Failed to send premium activation email via Edge Function')
      }
    } catch (emailError) {
      console.error('Error sending premium activation email via Edge Function:', emailError)
    }

    return NextResponse.json({
      success: true,
      message: `${plan} premium activated for ${email}`,
      expiresAt: expiresAt.toISOString(),
      userId: userId,
      emailSent: true
    })

  } catch (error: any) {
    console.error('Error activating premium:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to activate premium' },
      { status: 500 }
    )
  }
}
