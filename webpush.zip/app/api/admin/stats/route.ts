import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function GET(request: NextRequest) {
  try {
    console.log('📊 Fetching admin stats...')
    const supabaseAdmin = createSupabaseAdmin()

    // Get auth users first
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.listUsers()
    if (authError) {
      console.error('❌ Auth users error:', authError)
    } else {
      console.log(`✅ Found ${authData.users.length} auth users`)
    }

    // Get user stats from public.users
    const { data: users, error: usersError } = await supabaseAdmin
      .from('users')
      .select('*')

    if (usersError) {
      console.error('❌ Public users error:', usersError)
    } else {
      console.log(`✅ Found ${users?.length || 0} public users`)
    }

    // Get subscriptions
    const { data: subscriptions, error: subscriptionsError } = await supabaseAdmin
      .from('subscriptions')
      .select('*')

    if (subscriptionsError) {
      console.error('❌ Subscriptions error:', subscriptionsError)
    } else {
      console.log(`✅ Found ${subscriptions?.length || 0} subscriptions`)
    }

    // Get payment stats
    const { data: payments, error: paymentsError } = await supabaseAdmin
      .from('payments')
      .select('*')

    if (paymentsError) {
      console.error('❌ Payments error:', paymentsError)
    } else {
      console.log(`✅ Found ${payments?.length || 0} payments`)
    }

    // Get coupons count
    const { data: coupons, error: couponsError } = await supabaseAdmin
      .from('coupons')
      .select('*')

    if (couponsError) {
      console.error('❌ Coupons error:', couponsError)
    } else {
      console.log(`✅ Found ${coupons?.length || 0} coupons`)
    }

    // Calculate comprehensive stats
    const totalAuthUsers = authData?.users?.length || 0
    const totalUsers = users?.length || 0
    const activeUsers = users?.filter(u => u.subscription_status === 'active').length || 0
    const expiredUsers = users?.filter(u => u.subscription_status === 'expired').length || 0
    const inactiveUsers = users?.filter(u => u.subscription_status === 'inactive').length || 0
    
    const activeSubscriptions = subscriptions?.filter(s => s.status === 'active').length || 0
    const expiredSubscriptions = subscriptions?.filter(s => s.status === 'expired').length || 0
    
    const completedPayments = payments?.filter(p => p.status === 'completed') || []
    const totalRevenue = completedPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0)
    const totalPayments = payments?.length || 0
    const totalCoupons = coupons?.length || 0

    const stats = {
      totalUsers: Math.max(totalAuthUsers, totalUsers), // Use higher count
      totalAuthUsers,
      totalPublicUsers: totalUsers,
      activeUsers,
      expiredUsers,
      inactiveUsers,
      activeSubscriptions,
      expiredSubscriptions,
      totalRevenue,
      totalPayments,
      totalCoupons,
      syncNeeded: totalAuthUsers > totalUsers, // Flag if sync needed
      timestamp: new Date().toISOString()
    }

    console.log('📈 Admin stats calculated:', stats)

    return NextResponse.json(stats, {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    })
  } catch (error) {
    console.error('❌ Error fetching admin stats:', error)
    return NextResponse.json({
      totalUsers: 0,
      activeUsers: 0,
      totalRevenue: 0,
      totalPayments: 0,
      totalCoupons: 0,
      error: (error as Error).message
    }, { 
      status: 500,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    })
  }
}
