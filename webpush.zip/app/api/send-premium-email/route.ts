import { NextRequest, NextResponse } from 'next/server'

/**
 * Send Premium Activation Email
 * POST /api/send-premium-email
 * Body: { email: string, plan: string, expiresAt: string }
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, plan, expiresAt } = body

    if (!email || !plan) {
      return NextResponse.json(
        { success: false, error: 'Email and plan are required' },
        { status: 400 }
      )
    }

    // Format expiry date
    const expiryDate = new Date(expiresAt).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })

    // Email content
    const emailContent = {
      to: email,
      subject: '🎉 Your BeastBrowser Premium Plan is Now Active!',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>BeastBrowser Premium Activated</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #ff6b00, #ff4444); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .feature { display: flex; align-items: center; margin: 15px 0; }
            .feature-icon { width: 20px; height: 20px; background: #4CAF50; border-radius: 50%; margin-right: 15px; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; }
            .cta-button { background: linear-gradient(135deg, #ff6b00, #ff4444); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Welcome to BeastBrowser Premium!</h1>
              <p>Your ${plan} plan is now active</p>
            </div>
            
            <div class="content">
              <h2>Congratulations! 🚀</h2>
              <p>Your BeastBrowser Premium subscription has been successfully activated. You now have access to all premium features!</p>
              
              <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ff6b00;">
                <h3>📋 Subscription Details</h3>
                <p><strong>Plan:</strong> ${plan.charAt(0).toUpperCase() + plan.slice(1)} Premium</p>
                <p><strong>Status:</strong> Active ✅</p>
                <p><strong>Expires:</strong> ${expiryDate}</p>
              </div>
              
              <h3>🎯 Premium Features Unlocked:</h3>
              
              <div class="feature">
                <div class="feature-icon">✓</div>
                <div><strong>Unlimited Browser Profiles</strong> - Create as many profiles as you need</div>
              </div>
              
              <div class="feature">
                <div class="feature-icon">✓</div>
                <div><strong>Advanced Anti-Detection</strong> - Bypass sophisticated detection systems</div>
              </div>
              
              <div class="feature">
                <div class="feature-icon">✓</div>
                <div><strong>Priority Support</strong> - Get help faster with premium support</div>
              </div>
              
              <div class="feature">
                <div class="feature-icon">✓</div>
                <div><strong>Team Collaboration</strong> - Share profiles with your team</div>
              </div>
              
              <div class="feature">
                <div class="feature-icon">✓</div>
                <div><strong>Advanced Proxy Management</strong> - Integrated proxy rotation</div>
              </div>
              
              <div class="feature">
                <div class="feature-icon">✓</div>
                <div><strong>Export/Import Profiles</strong> - Backup and restore your profiles</div>
              </div>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="https://beastbrowser.com/download" class="cta-button">Download BeastBrowser</a>
              </div>
              
              <div style="background: #e8f5e8; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3>🚀 Getting Started</h3>
                <ol>
                  <li>Download the latest version of BeastBrowser</li>
                  <li>Login with your account: <strong>${email}</strong></li>
                  <li>Start creating unlimited browser profiles</li>
                  <li>Enjoy premium features!</li>
                </ol>
              </div>
              
              <div style="background: #fff3cd; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3>💡 Need Help?</h3>
                <p>Our support team is here to help you get the most out of BeastBrowser:</p>
                <ul>
                  <li>📧 Email: <a href="mailto:support@beastbrowser.com">support@beastbrowser.com</a></li>
                  <li>💬 WhatsApp: <a href="https://wa.me/917991985013">+91 79919 85013</a></li>
                  <li>📚 Documentation: <a href="https://beastbrowser.com/docs">beastbrowser.com/docs</a></li>
                </ul>
              </div>
            </div>
            
            <div class="footer">
              <p>Thank you for choosing BeastBrowser!</p>
              <p>This email was sent to ${email}</p>
              <p>© 2024 BeastBrowser. All rights reserved.</p>
              <p><a href="https://beastbrowser.com">beastbrowser.com</a></p>
            </div>
          </div>
        </body>
        </html>
      `
    }

    // Log email (in production, integrate with email service like SendGrid, Mailgun, etc.)
    console.log('🎉 Premium Activation Email:', {
      to: email,
      plan: plan,
      expiresAt: expiryDate,
      timestamp: new Date().toISOString()
    })

    // TODO: Integrate with actual email service
    // For now, just log and return success
    
    return NextResponse.json({
      success: true,
      message: 'Premium activation email sent successfully',
      details: {
        email: email,
        plan: plan,
        expiresAt: expiryDate
      }
    })

  } catch (error: any) {
    console.error('Error sending premium email:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to send email' },
      { status: 500 }
    )
  }
}
