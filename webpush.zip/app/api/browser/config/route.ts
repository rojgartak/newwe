import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const email = searchParams.get('email')
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!email && !token) {
      return NextResponse.json(
        { success: false, error: 'Email or token required for configuration' },
        { status: 400 }
      )
    }

    // Get user and verify plan
    const users = JSON.parse(localStorage.getItem('users') || '[]')
    let user = null
    
    if (email) {
      user = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase())
    } else if (token) {
      const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
      const session = sessions.find((s: any) => s.token === token)
      if (session) {
        user = users.find((u: any) => u.email === session.email)
      }
    }

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      )
    }

    // Check plan status
    const currentPlan = user.plan || 'free'
    const planActivatedAt = user.planActivatedAt
    const isActive = currentPlan !== 'free'
    
    // Calculate plan expiry
    let planExpiresAt = null
    if (planActivatedAt && isActive) {
      const activatedDate = new Date(planActivatedAt)
      if (currentPlan.includes('Monthly')) {
        planExpiresAt = new Date(activatedDate.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString()
      } else if (currentPlan.includes('Yearly')) {
        planExpiresAt = new Date(activatedDate.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString()
      }
    }

    const isExpired = planExpiresAt ? new Date() > new Date(planExpiresAt) : false
    const isPremium = isActive && !isExpired

    // Generate browser configuration based on plan
    const config = generateBrowserConfig(isPremium ? currentPlan : 'free', user)

    return NextResponse.json({
      success: true,
      user: {
        id: user.id || user.email,
        email: user.email,
        name: user.name,
        plan: isExpired ? 'free' : currentPlan,
        isPremium,
        isActive: isActive && !isExpired,
        planExpiresAt
      },
      config,
      lastUpdated: new Date().toISOString()
    })

  } catch (error) {
    console.error('Browser config error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to get browser configuration' },
      { status: 500 }
    )
  }
}

function generateBrowserConfig(plan: string, user: any) {
  const baseConfig = {
    // Basic browser settings
    browser: {
      name: 'BeastBrowser',
      version: '1.0.0',
      userAgent: 'BeastBrowser/1.0.0',
      homePage: 'https://beastbrowser.com',
      searchEngine: 'https://www.google.com/search?q='
    },

    // Security settings
    security: {
      httpsOnly: true,
      blockMalware: true,
      blockPhishing: true,
      safeSearch: true
    },

    // Privacy settings
    privacy: {
      doNotTrack: true,
      clearDataOnExit: false,
      incognitoMode: true
    },

    // Performance settings
    performance: {
      enableCache: true,
      enableJavaScript: true,
      enableImages: true,
      enableCookies: true
    },

    // UI settings
    ui: {
      theme: 'auto',
      showBookmarksBar: true,
      showTabBar: true,
      showStatusBar: true,
      fontSize: 'medium'
    }
  }

  if (plan === 'free') {
    return {
      ...baseConfig,
      
      // Free plan limitations
      features: {
        adBlocker: false,
        vpnAccess: false,
        customThemes: false,
        downloadManager: false,
        syncAcrossDevices: false,
        prioritySupport: false,
        advancedSecurity: false,
        privateVault: false
      },

      // Limits
      limits: {
        maxBookmarks: 100,
        maxHistory: 1000,
        maxDownloads: 10,
        maxTabs: 20,
        maxPasswords: 50
      },

      // Ads and promotions
      ads: {
        showAds: true,
        showUpgradePrompts: true,
        adFrequency: 'medium',
        promoteUpgrade: true
      },

      // Disabled premium settings
      blocked: [
        'vpn',
        'advanced-ad-blocker', 
        'custom-themes',
        'sync-settings',
        'priority-support',
        'advanced-downloads'
      ]
    }
  }

  // Premium plan configuration
  return {
    ...baseConfig,
    
    // Premium features enabled
    features: {
      adBlocker: true,
      vpnAccess: true,
      customThemes: true,
      downloadManager: true,
      syncAcrossDevices: true,
      prioritySupport: true,
      advancedSecurity: true,
      privateVault: true
    },

    // No limits for premium
    limits: {
      maxBookmarks: -1, // unlimited
      maxHistory: -1,   // unlimited
      maxDownloads: -1, // unlimited
      maxTabs: -1,      // unlimited
      maxPasswords: -1  // unlimited
    },

    // No ads for premium users
    ads: {
      showAds: false,
      showUpgradePrompts: false,
      adFrequency: 'none',
      promoteUpgrade: false
    },

    // Premium-only settings
    premium: {
      vpnServers: [
        { country: 'US', city: 'New York', server: 'us-ny-01.beastbrowser.com' },
        { country: 'UK', city: 'London', server: 'uk-lon-01.beastbrowser.com' },
        { country: 'DE', city: 'Frankfurt', server: 'de-fra-01.beastbrowser.com' },
        { country: 'JP', city: 'Tokyo', server: 'jp-tok-01.beastbrowser.com' }
      ],

      adBlockerLists: [
        'EasyList',
        'EasyPrivacy', 
        'Malware Protection',
        'Social Media Blocking',
        'Custom Beast Filters'
      ],

      customThemes: [
        { name: 'Dark Pro', file: 'dark-pro.css' },
        { name: 'Light Minimal', file: 'light-minimal.css' },
        { name: 'Blue Ocean', file: 'blue-ocean.css' },
        { name: 'Purple Space', file: 'purple-space.css' }
      ],

      syncSettings: {
        bookmarks: true,
        history: true,
        passwords: true,
        settings: true,
        extensions: true
      }
    },

    // User-specific settings
    user: {
      email: user.email,
      name: user.name,
      avatar: user.avatar || '',
      preferences: {
        language: 'en',
        timezone: 'auto',
        notifications: true
      }
    }
  }
}