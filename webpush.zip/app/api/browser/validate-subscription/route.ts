import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'
import { validateBrowserApiRequest } from '@/lib/browser-auth'

/**
 * Subscription Validation API for Beast Browser Software
 * 
 * Purpose: Software calls this API to check if user has active subscription
 * Returns: { hasSubscription: boolean, plan: string, expiresAt: string }
 */

// Handle CORS preflight
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-Browser-API-Key, X-API-Key',
      'Access-Control-Max-Age': '86400',
    },
  })
}

export async function POST(request: NextRequest) {
  // Validate API key first
  const validationError = validateBrowserApiRequest(request)
  if (validationError) {
    // Add CORS headers to error response too
    const response = validationError.clone()
    response.headers.set('Access-Control-Allow-Origin', '*')
    response.headers.set('Access-Control-Allow-Methods', 'POST, OPTIONS')
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, X-Browser-API-Key, X-API-Key')
    return response
  }

  try {
    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Email is required',
          hasSubscription: false
        },
        { 
          status: 400,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, X-Browser-API-Key, X-API-Key',
          }
        }
      )
    }

    const supabase = createSupabaseAdmin()

    // Get user by email
    const { data: user, error: userError } = await supabase
      .from('users')
      .select('id, email, subscription_status, subscription_plan, subscription_expires_at')
      .eq('email', email.toLowerCase())
      .single()

    if (userError || !user) {
      return NextResponse.json({
        success: true,
        hasSubscription: false,
        plan: 'free',
        message: 'User not found or no subscription'
      }, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, X-Browser-API-Key, X-API-Key',
        }
      })
    }

    // Check if subscription is active and not expired
    const now = new Date()
    const expiresAt = user.subscription_expires_at ? new Date(user.subscription_expires_at) : null
    const isActive = user.subscription_status === 'active' && expiresAt && expiresAt > now

    if (!isActive) {
      return NextResponse.json({
        success: true,
        hasSubscription: false,
        plan: 'free',
        subscriptionStatus: user.subscription_status,
        message: user.subscription_status === 'expired' ? 'Subscription expired' : 'No active subscription'
      }, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, X-Browser-API-Key, X-API-Key',
        }
      })
    }

    // Active subscription found
    return NextResponse.json({
      success: true,
      hasSubscription: true,
      plan: user.subscription_plan || 'free',
      subscriptionStatus: user.subscription_status,
      expiresAt: user.subscription_expires_at,
      daysRemaining: Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    }, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, X-Browser-API-Key, X-API-Key',
      }
    })

  } catch (error) {
    console.error('Subscription validation error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Validation failed',
        hasSubscription: false
      },
      { 
        status: 500,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, X-Browser-API-Key, X-API-Key',
        }
      }
    )
  }
}
