import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const email = searchParams.get('email')
    const token = request.headers.get('authorization')?.replace('Bearer ', '')

    if (!email && !token) {
      return NextResponse.json(
        { success: false, error: 'Email or token required' },
        { status: 400 }
      )
    }

    // Get users from localStorage (in production, use database)
    const users = JSON.parse(localStorage.getItem('users') || '[]')
    
    let user = null
    if (email) {
      user = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase())
    } else if (token) {
      // Simple token validation (in production, use proper JWT)
      const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
      const session = sessions.find((s: any) => s.token === token)
      if (session) {
        user = users.find((u: any) => u.email === session.email)
      }
    }

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      )
    }

    // Check plan status
    const currentPlan = user.plan || 'free'
    const planActivatedAt = user.planActivatedAt
    const isActive = currentPlan !== 'free'
    
    // Calculate plan expiry (if applicable)
    let planExpiresAt = null
    if (planActivatedAt && isActive) {
      const activatedDate = new Date(planActivatedAt)
      if (currentPlan.includes('Monthly')) {
        planExpiresAt = new Date(activatedDate.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString()
      } else if (currentPlan.includes('Yearly')) {
        planExpiresAt = new Date(activatedDate.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString()
      }
    }

    // Check if plan is expired
    const isExpired = planExpiresAt ? new Date() > new Date(planExpiresAt) : false

    // Get plan features
    const features = getPlanFeatures(isExpired ? 'free' : currentPlan)

    return NextResponse.json({
      success: true,
      user: {
        id: user.id || user.email,
        email: user.email,
        name: user.name,
        plan: isExpired ? 'free' : currentPlan,
        isActive: isActive && !isExpired,
        isPremium: isActive && !isExpired,
        planActivatedAt,
        planExpiresAt,
        isExpired
      },
      features,
      permissions: {
        canAccessPremiumFeatures: isActive && !isExpired,
        canDownloadFiles: true,
        canUseAdvancedSettings: isActive && !isExpired,
        canUseCustomThemes: isActive && !isExpired,
        canUseAdBlocker: isActive && !isExpired,
        canUseVPN: isActive && !isExpired,
        maxBookmarks: isActive && !isExpired ? -1 : 100,
        maxHistory: isActive && !isExpired ? -1 : 1000
      }
    })

  } catch (error) {
    console.error('Plan verification error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to verify plan' },
      { status: 500 }
    )
  }
}

// POST method for bulk plan checks
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { emails = [], tokens = [] } = body

    if (emails.length === 0 && tokens.length === 0) {
      return NextResponse.json(
        { success: false, error: 'At least one email or token required' },
        { status: 400 }
      )
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]')
    const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
    const results = []

    // Check emails
    for (const email of emails) {
      const user = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase())
      if (user) {
        const currentPlan = user.plan || 'free'
        const planActivatedAt = user.planActivatedAt
        const isActive = currentPlan !== 'free'
        
        let planExpiresAt = null
        if (planActivatedAt && isActive) {
          const activatedDate = new Date(planActivatedAt)
          if (currentPlan.includes('Monthly')) {
            planExpiresAt = new Date(activatedDate.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString()
          } else if (currentPlan.includes('Yearly')) {
            planExpiresAt = new Date(activatedDate.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString()
          }
        }

        const isExpired = planExpiresAt ? new Date() > new Date(planExpiresAt) : false

        results.push({
          email,
          plan: isExpired ? 'free' : currentPlan,
          isActive: isActive && !isExpired,
          isPremium: isActive && !isExpired,
          planActivatedAt,
          planExpiresAt,
          isExpired
        })
      } else {
        results.push({
          email,
          error: 'User not found'
        })
      }
    }

    // Check tokens
    for (const token of tokens) {
      const session = sessions.find((s: any) => s.token === token)
      if (session) {
        const user = users.find((u: any) => u.email === session.email)
        if (user) {
          const currentPlan = user.plan || 'free'
          const planActivatedAt = user.planActivatedAt
          const isActive = currentPlan !== 'free'
          
          let planExpiresAt = null
          if (planActivatedAt && isActive) {
            const activatedDate = new Date(planActivatedAt)
            if (currentPlan.includes('Monthly')) {
              planExpiresAt = new Date(activatedDate.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString()
            } else if (currentPlan.includes('Yearly')) {
              planExpiresAt = new Date(activatedDate.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString()
            }
          }

          const isExpired = planExpiresAt ? new Date() > new Date(planExpiresAt) : false

          results.push({
            token,
            email: user.email,
            plan: isExpired ? 'free' : currentPlan,
            isActive: isActive && !isExpired,
            isPremium: isActive && !isExpired,
            planActivatedAt,
            planExpiresAt,
            isExpired
          })
        } else {
          results.push({
            token,
            error: 'User not found'
          })
        }
      } else {
        results.push({
          token,
          error: 'Invalid token'
        })
      }
    }

    return NextResponse.json({
      success: true,
      results
    })

  } catch (error) {
    console.error('Bulk plan verification error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to verify plans' },
      { status: 500 }
    )
  }
}

function getPlanFeatures(plan: string) {
  const baseFeat8ures = {
    browsing: true,
    bookmarks: true,
    history: true,
    basicSecurity: true
  }

  if (plan === 'free') {
    return {
      ...baseFeat8ures,
      adBlocker: false,
      vpn: false,
      customThemes: false,
      advancedSecurity: false,
      privateMode: false,
      downloadManager: false,
      syncAcrossDevices: false,
      prioritySupport: false,
      maxBookmarks: 100,
      maxHistory: 1000
    }
  }

  // Premium features
  return {
    ...baseFeat8ures,
    adBlocker: true,
    vpn: true,
    customThemes: true,
    advancedSecurity: true,
    privateMode: true,
    downloadManager: true,
    syncAcrossDevices: true,
    prioritySupport: true,
    maxBookmarks: -1, // unlimited
    maxHistory: -1 // unlimited
  }
}