import { NextRequest, NextResponse } from 'next/server'
import { validateBrowserApiRequest, BROWSER_API_CONFIG, BrowserApiResponse } from '@/lib/browser-auth'

export async function POST(request: NextRequest) {
  // Validate API key first
  const validationError = validateBrowserApiRequest(request)
  if (validationError) {
    return validationError
  }

  try {
    const body = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json(
        { success: false, error: 'Email and password are required' },
        { status: 400 }
      )
    }

    // Get users from localStorage (in production, use database)
    const usersRaw = typeof localStorage !== 'undefined' ? localStorage.getItem('users') : '[]'
    const users = JSON.parse(usersRaw || '[]')

    // Find user
    const user = users.find((u: any) => 
      u.email.toLowerCase() === email.toLowerCase() && u.password === password
    )

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Invalid credentials' },
        { status: 401 }
      )
    }

    // Create session token for browser (simplified JWT)
    const tokenPayload = {
      userId: user.id || user.email,
      email: user.email,
      name: user.name,
      plan: user.plan || 'free',
      planActivatedAt: user.planActivatedAt,
      browserAuth: true,
      exp: Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60) // 30 days
    }
    
    const token = btoa(JSON.stringify({
      header: { alg: 'none', typ: 'JWT' },
      payload: tokenPayload,
      signature: 'browser_token'
    }))

    // Create session record
    const session = {
      id: Date.now().toString(),
      userId: user.id || user.email,
      email: user.email,
      name: user.name,
      plan: user.plan || 'free',
      planActivatedAt: user.planActivatedAt,
      token: token,
      createdAt: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      userAgent: request.headers.get('user-agent') || 'Unknown',
      ipAddress: request.headers.get('x-forwarded-for') || 'Unknown',
      deviceType: 'browser'
    }

    // Store session (in production, use database)
    const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
    sessions.unshift(session)
    
    // Keep only last 100 sessions
    if (sessions.length > 100) {
      sessions.splice(100)
    }
    
    localStorage.setItem('browserSessions', JSON.stringify(sessions))

    // Return authentication data
    return NextResponse.json({
      success: true,
      user: {
        id: user.id || user.email,
        email: user.email,
        name: user.name,
        plan: user.plan || 'free',
        planActivatedAt: user.planActivatedAt,
        company: user.company || '',
        avatar: user.avatar || '',
        joinedAt: user.joined || new Date().toISOString()
      },
      token: token,
      session: {
        id: session.id,
        createdAt: session.createdAt,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days
      }
    })

  } catch (error) {
    console.error('Browser auth error:', error)
    return NextResponse.json(
      { success: false, error: 'Authentication failed' },
      { status: 500 }
    )
  }
}

// Verify browser token
export async function GET(request: NextRequest) {
  // Validate API key first
  const validationError = validateBrowserApiRequest(request)
  if (validationError) {
    return validationError
  }

  try {
    const authHeader = request.headers.get('authorization')
    const token = authHeader?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No token provided' },
        { status: 401 }
      )
    }

    // Verify browser token (simplified)
    let decoded: any
    try {
      const tokenData = JSON.parse(atob(token))
      decoded = tokenData.payload
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid token format' },
        { status: 401 }
      )
    }

    if (!decoded.browserAuth) {
      return NextResponse.json(
        { success: false, error: 'Invalid browser token' },
        { status: 401 }
      )
    }

    // Get latest user data
    const usersRaw = typeof localStorage !== 'undefined' ? localStorage.getItem('users') : '[]'
    const users = JSON.parse(usersRaw || '[]')
    const user = users.find((u: any) => u.email === decoded.email)

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      )
    }

    // Update session activity
    const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
    const sessionIndex = sessions.findIndex((s: any) => s.token === token)
    if (sessionIndex >= 0) {
      sessions[sessionIndex].lastActivity = new Date().toISOString()
      localStorage.setItem('browserSessions', JSON.stringify(sessions))
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.id || user.email,
        email: user.email,
        name: user.name,
        plan: user.plan || 'free',
        planActivatedAt: user.planActivatedAt,
        company: user.company || '',
        avatar: user.avatar || '',
        joinedAt: user.joined || new Date().toISOString()
      },
      valid: true
    })

  } catch (error) {
    console.error('Token verification error:', error)
    return NextResponse.json(
      { success: false, error: 'Invalid token' },
      { status: 401 }
    )
  }
}