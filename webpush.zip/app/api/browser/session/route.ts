import { NextRequest, NextResponse } from 'next/server'

// GET - Get session information
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const token = request.headers.get('authorization')?.replace('Bearer ', '') || searchParams.get('token')
    const email = searchParams.get('email')

    if (!token && !email) {
      return NextResponse.json(
        { success: false, error: 'Token or email required' },
        { status: 400 }
      )
    }

    const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
    
    if (token) {
      // Get specific session by token
      const session = sessions.find((s: any) => s.token === token)
      
      if (!session) {
        return NextResponse.json(
          { success: false, error: 'Session not found' },
          { status: 404 }
        )
      }

      // Update last activity
      session.lastActivity = new Date().toISOString()
      localStorage.setItem('browserSessions', JSON.stringify(sessions))

      return NextResponse.json({
        success: true,
        session: {
          id: session.id,
          email: session.email,
          name: session.name,
          plan: session.plan,
          createdAt: session.createdAt,
          lastActivity: session.lastActivity,
          deviceType: session.deviceType,
          userAgent: session.userAgent,
          isActive: true
        }
      })
      
    } else if (email) {
      // Get all sessions for user
      const userSessions = sessions.filter((s: any) => 
        s.email.toLowerCase() === email.toLowerCase()
      )

      return NextResponse.json({
        success: true,
        email: email,
        totalSessions: userSessions.length,
        sessions: userSessions.map((s: any) => ({
          id: s.id,
          createdAt: s.createdAt,
          lastActivity: s.lastActivity,
          deviceType: s.deviceType,
          userAgent: s.userAgent,
          ipAddress: s.ipAddress,
          isActive: true
        }))
      })
    }

  } catch (error) {
    console.error('Session info error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to get session information' },
      { status: 500 }
    )
  }
}

// POST - Create or refresh session
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, email, token, sessionData } = body

    if (!action) {
      return NextResponse.json(
        { success: false, error: 'Action is required' },
        { status: 400 }
      )
    }

    const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
    const users = JSON.parse(localStorage.getItem('users') || '[]')

    if (action === 'refresh' && token) {
      // Refresh existing session
      const sessionIndex = sessions.findIndex((s: any) => s.token === token)
      
      if (sessionIndex === -1) {
        return NextResponse.json(
          { success: false, error: 'Session not found' },
          { status: 404 }
        )
      }

      // Update session activity
      sessions[sessionIndex].lastActivity = new Date().toISOString()
      sessions[sessionIndex].refreshCount = (sessions[sessionIndex].refreshCount || 0) + 1
      
      // Update session data if provided
      if (sessionData) {
        sessions[sessionIndex].data = { 
          ...sessions[sessionIndex].data, 
          ...sessionData 
        }
      }

      localStorage.setItem('browserSessions', JSON.stringify(sessions))

      return NextResponse.json({
        success: true,
        message: 'Session refreshed',
        session: {
          id: sessions[sessionIndex].id,
          lastActivity: sessions[sessionIndex].lastActivity,
          refreshCount: sessions[sessionIndex].refreshCount
        }
      })

    } else if (action === 'heartbeat' && token) {
      // Simple heartbeat to keep session alive
      const sessionIndex = sessions.findIndex((s: any) => s.token === token)
      
      if (sessionIndex === -1) {
        return NextResponse.json(
          { success: false, error: 'Session not found' },
          { status: 404 }
        )
      }

      sessions[sessionIndex].lastActivity = new Date().toISOString()
      sessions[sessionIndex].heartbeatCount = (sessions[sessionIndex].heartbeatCount || 0) + 1
      localStorage.setItem('browserSessions', JSON.stringify(sessions))

      return NextResponse.json({
        success: true,
        message: 'Heartbeat recorded',
        lastActivity: sessions[sessionIndex].lastActivity
      })

    } else if (action === 'sync' && (email || token)) {
      // Sync session data with user data
      let user = null
      
      if (email) {
        user = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase())
      } else if (token) {
        const session = sessions.find((s: any) => s.token === token)
        if (session) {
          user = users.find((u: any) => u.email === session.email)
        }
      }

      if (!user) {
        return NextResponse.json(
          { success: false, error: 'User not found' },
          { status: 404 }
        )
      }

      // Update all sessions for this user with latest user data
      const updatedSessions = sessions.map((s: any) => {
        if (s.email === user.email) {
          return {
            ...s,
            name: user.name,
            plan: user.plan || 'free',
            planActivatedAt: user.planActivatedAt,
            lastSync: new Date().toISOString()
          }
        }
        return s
      })

      localStorage.setItem('browserSessions', JSON.stringify(updatedSessions))

      return NextResponse.json({
        success: true,
        message: 'Sessions synced with user data',
        user: {
          email: user.email,
          name: user.name,
          plan: user.plan || 'free'
        },
        syncedSessions: updatedSessions.filter((s: any) => s.email === user.email).length
      })
    }

    return NextResponse.json(
      { success: false, error: 'Invalid action' },
      { status: 400 }
    )

  } catch (error) {
    console.error('Session management error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to manage session' },
      { status: 500 }
    )
  }
}

// DELETE - Delete session(s)
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json()
    const { token, email, all = false } = body

    if (!token && !email) {
      return NextResponse.json(
        { success: false, error: 'Token or email required' },
        { status: 400 }
      )
    }

    let sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')

    if (token) {
      // Delete specific session by token
      const initialLength = sessions.length
      sessions = sessions.filter((s: any) => s.token !== token)
      
      if (sessions.length === initialLength) {
        return NextResponse.json(
          { success: false, error: 'Session not found' },
          { status: 404 }
        )
      }

      localStorage.setItem('browserSessions', JSON.stringify(sessions))

      return NextResponse.json({
        success: true,
        message: 'Session deleted successfully'
      })

    } else if (email) {
      // Delete session(s) by email
      const initialLength = sessions.length
      
      if (all) {
        // Delete all sessions for this user
        sessions = sessions.filter((s: any) => 
          s.email.toLowerCase() !== email.toLowerCase()
        )
      } else {
        // Delete oldest session for this user
        const userSessions = sessions.filter((s: any) => 
          s.email.toLowerCase() === email.toLowerCase()
        )
        
        if (userSessions.length > 0) {
          // Find oldest session
          const oldestSession = userSessions.reduce((oldest: any, current: any) => 
            new Date(current.createdAt) < new Date(oldest.createdAt) ? current : oldest
          )
          
          sessions = sessions.filter((s: any) => s.id !== oldestSession.id)
        }
      }

      if (sessions.length === initialLength) {
        return NextResponse.json(
          { success: false, error: 'No sessions found for user' },
          { status: 404 }
        )
      }

      localStorage.setItem('browserSessions', JSON.stringify(sessions))

      return NextResponse.json({
        success: true,
        message: all ? 'All user sessions deleted' : 'Oldest session deleted',
        deletedSessions: initialLength - sessions.length
      })
    }

  } catch (error) {
    console.error('Session deletion error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete session' },
      { status: 500 }
    )
  }
}