import { NextRequest, NextResponse } from 'next/server'
import { BROWSER_ACTIONS } from '@/lib/browser-actions'

// POST - Track browser usage
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      email, 
      token, 
      action, 
      data = {}, 
      timestamp,
      sessionId 
    } = body

    if (!email && !token) {
      return NextResponse.json(
        { success: false, error: 'Email or token required' },
        { status: 400 }
      )
    }

    if (!action) {
      return NextResponse.json(
        { success: false, error: 'Action is required' },
        { status: 400 }
      )
    }

    // Verify user
    const users = JSON.parse(localStorage.getItem('users') || '[]')
    let user = null
    
    if (email) {
      user = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase())
    } else if (token) {
      const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
      const session = sessions.find((s: any) => s.token === token)
      if (session) {
        user = users.find((u: any) => u.email === session.email)
      }
    }

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      )
    }

    // Create usage record
    const usageRecord = {
      id: Date.now().toString(),
      userId: user.id || user.email,
      email: user.email,
      name: user.name,
      action: action,
      data: data,
      timestamp: timestamp || new Date().toISOString(),
      sessionId: sessionId || 'unknown',
      userAgent: request.headers.get('user-agent') || 'BeastBrowser',
      ipAddress: request.headers.get('x-forwarded-for') || 'unknown',
      plan: user.plan || 'free'
    }

    // Get existing usage history
    const usageHistory = JSON.parse(localStorage.getItem('browserUsage') || '[]')
    usageHistory.unshift(usageRecord)

    // Keep only last 10000 records to prevent bloat
    if (usageHistory.length > 10000) {
      usageHistory.splice(10000)
    }

    // Save updated history
    localStorage.setItem('browserUsage', JSON.stringify(usageHistory))

    // Update user's last activity
    const userIndex = users.findIndex((u: any) => u.email === user.email)
    if (userIndex >= 0) {
      users[userIndex].lastActivity = new Date().toISOString()
      users[userIndex].lastAction = action
      localStorage.setItem('users', JSON.stringify(users))
    }

    return NextResponse.json({
      success: true,
      message: 'Usage tracked successfully',
      record: {
        id: usageRecord.id,
        action: usageRecord.action,
        timestamp: usageRecord.timestamp
      }
    })

  } catch (error) {
    console.error('Browser usage tracking error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to track usage' },
      { status: 500 }
    )
  }
}

// GET - Get usage statistics
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const email = searchParams.get('email')
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    const action = searchParams.get('action')
    const days = parseInt(searchParams.get('days') || '30')

    if (!email && !token) {
      return NextResponse.json(
        { success: false, error: 'Email or token required' },
        { status: 400 }
      )
    }

    // Verify user
    const users = JSON.parse(localStorage.getItem('users') || '[]')
    let user = null
    
    if (email) {
      user = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase())
    } else if (token) {
      const sessions = JSON.parse(localStorage.getItem('browserSessions') || '[]')
      const session = sessions.find((s: any) => s.token === token)
      if (session) {
        user = users.find((u: any) => u.email === session.email)
      }
    }

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      )
    }

    // Get usage history
    const usageHistory = JSON.parse(localStorage.getItem('browserUsage') || '[]')
    
    // Filter by user and time range
    const cutoffDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
    let userUsage = usageHistory.filter((usage: any) => 
      usage.email === user.email && 
      new Date(usage.timestamp) >= cutoffDate
    )

    // Filter by action if specified
    if (action) {
      userUsage = userUsage.filter((usage: any) => usage.action === action)
    }

    // Generate statistics
    const stats = generateUsageStats(userUsage, days)

    return NextResponse.json({
      success: true,
      user: {
        email: user.email,
        name: user.name,
        plan: user.plan || 'free'
      },
      period: {
        days: days,
        from: cutoffDate.toISOString(),
        to: new Date().toISOString()
      },
      stats,
      recentActivity: userUsage.slice(0, 20).map((u: any) => ({
        action: u.action,
        timestamp: u.timestamp,
        data: u.data
      }))
    })

  } catch (error) {
    console.error('Usage stats error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to get usage statistics' },
      { status: 500 }
    )
  }
}

function generateUsageStats(usageHistory: any[], days: number) {
  const stats = {
    totalActions: usageHistory.length,
    uniqueDays: 0,
    averagePerDay: 0,
    topActions: {} as any,
    dailyActivity: {} as any,
    hourlyActivity: {} as any,
    featureUsage: {
      browsing: 0,
      bookmarks: 0,
      downloads: 0,
      settings: 0,
      search: 0,
      tabs: 0
    }
  }

  if (usageHistory.length === 0) {
    return stats
  }

  // Count actions by type
  const actionCounts: any = {}
  const dailyCounts: any = {}
  const hourlyCounts: any = {}
  const uniqueDaysSet = new Set()

  usageHistory.forEach((usage) => {
    const action = usage.action
    const date = new Date(usage.timestamp)
    const dateStr = date.toISOString().split('T')[0]
    const hour = date.getHours()

    // Count actions
    actionCounts[action] = (actionCounts[action] || 0) + 1

    // Count daily activity
    dailyCounts[dateStr] = (dailyCounts[dateStr] || 0) + 1
    uniqueDaysSet.add(dateStr)

    // Count hourly activity
    hourlyCounts[hour] = (hourlyCounts[hour] || 0) + 1

    // Feature usage mapping
    if (action.includes('browse') || action.includes('navigate')) {
      stats.featureUsage.browsing++
    } else if (action.includes('bookmark')) {
      stats.featureUsage.bookmarks++
    } else if (action.includes('download')) {
      stats.featureUsage.downloads++
    } else if (action.includes('settings')) {
      stats.featureUsage.settings++
    } else if (action.includes('search')) {
      stats.featureUsage.search++
    } else if (action.includes('tab')) {
      stats.featureUsage.tabs++
    }
  })

  // Calculate top actions
  const sortedActions = Object.entries(actionCounts)
    .sort(([,a], [,b]) => (b as number) - (a as number))
    .slice(0, 10)
    .reduce((obj, [key, value]) => {
      obj[key] = value
      return obj
    }, {} as any)

  stats.topActions = sortedActions
  stats.uniqueDays = uniqueDaysSet.size
  stats.averagePerDay = stats.uniqueDays > 0 ? Math.round(stats.totalActions / stats.uniqueDays) : 0
  stats.dailyActivity = dailyCounts
  stats.hourlyActivity = hourlyCounts

  return stats
}