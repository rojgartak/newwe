import { NextRequest, NextResponse } from 'next/server'
import { BROWSER_API_CONFIG, generateBrowserApiKey } from '@/lib/browser-auth'

// GET - Get current API key information
export async function GET(request: NextRequest) {
  try {
    // Only admin can access this endpoint
    const adminAuth = request.headers.get('authorization')
    const isAuthenticated = checkAdminAuth(adminAuth)

    if (!isAuthenticated) {
      return NextResponse.json(
        { success: false, error: 'Admin authentication required' },
        { status: 401 }
      )
    }

    // Return API key information
    return NextResponse.json({
      success: true,
      apiKey: BROWSER_API_CONFIG.apiKey,
      keyInfo: {
        prefix: 'beast-browser-',
        length: BROWSER_API_CONFIG.apiKey.length,
        rateLimit: BROWSER_API_CONFIG.rateLimit,
        tokenExpiry: BROWSER_API_CONFIG.tokenExpiry,
        lastGenerated: process.env.API_KEY_GENERATED || 'Not available'
      },
      usage: {
        description: 'Use this API key in browser integration',
        headerName: 'x-api-key or x-browser-api-key',
        example: `X-API-Key: ${BROWSER_API_CONFIG.apiKey}`
      }
    })

  } catch (error) {
    console.error('API key info error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to get API key info' },
      { status: 500 }
    )
  }
}

// POST - Generate new API key (admin only)
export async function POST(request: NextRequest) {
  try {
    const adminAuth = request.headers.get('authorization')
    const isAuthenticated = checkAdminAuth(adminAuth)

    if (!isAuthenticated) {
      return NextResponse.json(
        { success: false, error: 'Admin authentication required' },
        { status: 401 }
      )
    }

    // Generate new API key
    const newApiKey = generateBrowserApiKey()
    
    // In production, you would save this to database
    // For now, we'll just return it
    console.log('New Browser API key generated:', newApiKey)

    return NextResponse.json({
      success: true,
      message: 'New API key generated',
      apiKey: newApiKey,
      previousKey: BROWSER_API_CONFIG.apiKey,
      instructions: [
        'Update your .env.local file with the new API key:',
        `BROWSER_API_KEY=${newApiKey}`,
        'Restart your Next.js server',
        'Update browser integration to use new API key',
        'Test browser authentication'
      ],
      warning: 'Save this key securely. It will not be shown again.'
    })

  } catch (error) {
    console.error('API key generation error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to generate API key' },
      { status: 500 }
    )
  }
}

// Simple admin authentication check
function checkAdminAuth(authHeader: string | null): boolean {
  if (!authHeader) return false

  // Check for admin session or basic auth
  if (authHeader.startsWith('Bearer ')) {
    // JWT token check (simplified)
    const token = authHeader.replace('Bearer ', '')
    try {
      const payload = JSON.parse(atob(token.split('.')[1]))
      return payload.role === 'admin'
    } catch {
      return false
    }
  }

  if (authHeader.startsWith('Basic ')) {
    // Basic auth check
    const credentials = atob(authHeader.replace('Basic ', ''))
    const [username, password] = credentials.split(':')
    return username === 'admin' && password === 'Ahmihere786$'
  }

  return false
}