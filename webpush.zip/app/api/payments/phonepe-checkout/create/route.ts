import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'
import { initiatePhonePePayment } from '@/lib/phonepe-payment'
import { createPhonePePayment } from '@/lib/phonepe-checkout'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { planName, amount, originalAmount, discountAmount, couponCode, userEmail, userName } = body

    if (!planName || !userEmail || !userName) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    console.log('=== PhonePe Standard Checkout Payment ===')
    console.log('Plan:', planName)
    console.log('User:', userEmail)
    console.log('Final Amount (paise):', amount)
    console.log('Final Amount (₹):', amount / 100)
    console.log('Original Amount (paise):', originalAmount)
    console.log('Discount Amount (paise):', discountAmount)
    console.log('Coupon Code:', couponCode)

    const supabaseAdmin = createSupabaseAdmin()

    // Get or create user
    let userId: string
    
    const { data: existingUser } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('email', userEmail)
      .single()

    if (existingUser) {
      userId = existingUser.id
    } else {
      const { data: newUser, error: createError } = await supabaseAdmin
        .from('users')
        .insert({ email: userEmail })
        .select('id')
        .single()

      if (createError || !newUser) {
        console.error('Error creating user:', createError)
        return NextResponse.json(
          { success: false, error: 'Failed to create user account' },
          { status: 500 }
        )
      }
      userId = newUser.id
    }

    // Create PhonePe payment
    const planType = planName as 'Monthly Premium' | 'Yearly Premium'

    // Decide flow
    const forceOAuth = process.env.PHONEPE_FORCE_OAUTH === 'true'
    const useSaltKeyFlow = !forceOAuth && !!(process.env.PHONEPE_SALT_KEY && process.env.PHONEPE_SALT_INDEX)

    console.log('[PhonePe] Flow:', useSaltKeyFlow ? 'PAY_PAGE (salt-key)' : 'STANDARD CHECKOUT (OAuth)')
    if (!useSaltKeyFlow) {
      console.log('[PhonePe] AUTH URL:', process.env.PHONEPE_AUTH_URL)
      console.log('[PhonePe] API URL :', process.env.PHONEPE_API_URL)
    } else {
      console.log('[PhonePe] BASE URL:', process.env.PHONEPE_BASE_URL)
    }

    let paymentResult: any
    if (useSaltKeyFlow) {
      try {
        paymentResult = await initiatePhonePePayment(
          userId,
          planType,
          userEmail,
          undefined,
          amount
        )
      } catch (e: any) {
        const message = e?.message || ''
        console.error('[PhonePe] PAY_PAGE error:', message)
        if (message.toLowerCase().includes('key not found for the merchant')) {
          console.log('[PhonePe] Falling back to STANDARD CHECKOUT (OAuth) due to missing salt key')
          paymentResult = await createPhonePePayment(
            planType,
            userEmail,
            userId,
            amount,
            couponCode
          )
        } else {
          throw e
        }
      }
    } else {
      paymentResult = await createPhonePePayment(
        planType,
        userEmail,
        userId,
        amount,
        couponCode
      )
    }

    console.log('Payment creation result:', paymentResult)

    // Store payment record
    const { data: payment, error: paymentError } = await supabaseAdmin
      .from('payments')
      .insert({
        user_id: userId,
        amount: amount,
        currency: 'INR',
        status: 'pending',
        payment_gateway: 'phonepe_checkout',
        gateway_payment_id: paymentResult.merchantTransactionId || paymentResult.merchantOrderId,
        metadata: {
          orderId: paymentResult.orderId || null,
          paymentUrl: (paymentResult as any).paymentUrl || null,
          originalAmount: originalAmount,
          discountAmount: discountAmount,
          couponCode: couponCode
        }
      })
      .select()
      .single()

    if (paymentError) {
      console.error('Error creating payment record:', paymentError)
    }

    return NextResponse.json({
      success: true,
      redirectUrl: (paymentResult as any).redirectUrl,
      paymentUrl: (paymentResult as any).paymentUrl,
      orderId: paymentResult.orderId,
      merchantOrderId: paymentResult.merchantOrderId || paymentResult.merchantTransactionId,
      paymentRecord: payment
    })

  } catch (error) {
    console.error('PhonePe payment creation error:', error)
    
    const errorMessage = error instanceof Error ? error.message : 'Failed to create payment'
    
    // Extract error code from message if present (e.g., "Payment creation failed (R006): Invalid merchant...")
    let errorCode = 'UNKNOWN_ERROR'
    const codeMatch = errorMessage.match(/\(([A-Z0-9_]+)\):/)
    if (codeMatch) {
      errorCode = codeMatch[1]
    }
    
    // Determine appropriate HTTP status code
    let statusCode = 500
    if (errorCode === 'R006') {
      statusCode = 503 // Service Unavailable - configuration issue
    } else if (['R001', 'R002', 'R003', 'R005'].includes(errorCode)) {
      statusCode = 400 // Bad Request - user/payment issue
    }
    
    return NextResponse.json(
      { 
        success: false, 
        error: errorMessage,
        errorCode: errorCode,
        message: errorMessage // Additional field for compatibility
      },
      { status: statusCode }
    )
  }
}
