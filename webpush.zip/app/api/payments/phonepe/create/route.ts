import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'
import { initiatePhonePePayment } from '@/lib/phonepe-payment'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { planName, amount, userEmail, userName, userPhone } = body

    if (!planName || !userEmail || !userName) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const supabaseAdmin = createSupabaseAdmin()

    // Get or create user in Supabase
    let userId: string
    
    // Try to find existing user
    const { data: existingUser } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('email', userEmail)
      .single()

    if (existingUser) {
      userId = existingUser.id
    } else {
      // Create new user if not exists
      const { data: newUser, error: createError } = await supabaseAdmin
        .from('users')
        .insert({ email: userEmail })
        .select('id')
        .single()

      if (createError || !newUser) {
        console.error('Error creating user:', createError)
        return NextResponse.json(
          { success: false, error: 'Failed to create user account' },
          { status: 500 }
        )
      }
      userId = newUser.id
    }

    // Initiate PhonePe payment
    const planType = planName as 'Monthly Premium' | 'Yearly Premium'
    const paymentResult = await initiatePhonePePayment(
      userId,
      planType,
      userEmail,
      userPhone || '9999999999'
    )

    if (!paymentResult || paymentResult.success !== true) {
      throw new Error('Payment initiation failed')
    }

    // Store payment record in database
    const { data: payment, error: paymentError } = await supabaseAdmin
      .from('payments')
      .insert({
        user_id: userId,
        amount: amount,
        currency: 'INR',
        status: 'pending',
        payment_gateway: 'phonepe',
        gateway_payment_id: paymentResult.merchantTransactionId
      })
      .select()
      .single()

    if (paymentError) {
      console.error('Error creating payment record:', paymentError)
      return NextResponse.json(
        { success: false, error: 'Failed to create payment record' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      paymentUrl: paymentResult.paymentUrl,
      merchantTransactionId: paymentResult.merchantTransactionId,
      paymentRecord: payment
    })

  } catch (error) {
    console.error('PhonePe payment creation error:', error)
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : 'Payment creation failed' },
      { status: 500 }
    )
  }
}
