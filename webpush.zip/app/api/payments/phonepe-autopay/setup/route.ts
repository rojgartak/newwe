import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'
import { setupPhonePeSubscription } from '@/lib/phonepe-autopay'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { planName, amount, userEmail, userName } = body

    if (!planName || !userEmail || !userName) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    console.log('=== PhonePe Autopay Subscription Setup ===')
    console.log('Plan:', planName)
    console.log('User:', userEmail)

    const supabaseAdmin = createSupabaseAdmin()

    // Get or create user
    let userId: string
    
    const { data: existingUser } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('email', userEmail)
      .single()

    if (existingUser) {
      userId = existingUser.id
    } else {
      const { data: newUser, error: createError } = await supabaseAdmin
        .from('users')
        .insert({ email: userEmail })
        .select('id')
        .single()

      if (createError || !newUser) {
        console.error('Error creating user:', createError)
        return NextResponse.json(
          { success: false, error: 'Failed to create user account' },
          { status: 500 }
        )
      }
      userId = newUser.id
    }

    // Setup PhonePe subscription
    const planType = planName as 'Monthly Premium' | 'Yearly Premium'
    const subscriptionResult = await setupPhonePeSubscription(
      planType,
      userEmail,
      userId
    )

    console.log('Subscription setup result:', subscriptionResult)

    // Store payment record
    const { data: payment, error: paymentError } = await supabaseAdmin
      .from('payments')
      .insert({
        user_id: userId,
        amount: amount,
        currency: 'INR',
        status: 'pending',
        payment_gateway: 'phonepe_autopay',
        gateway_payment_id: subscriptionResult.merchantOrderId,
        metadata: {
          subscriptionId: subscriptionResult.subscriptionId,
          orderId: subscriptionResult.orderId
        }
      })
      .select()
      .single()

    if (paymentError) {
      console.error('Error creating payment record:', paymentError)
    }

    return NextResponse.json({
      success: true,
      intentUrl: subscriptionResult.intentUrl,
      subscriptionId: subscriptionResult.subscriptionId,
      orderId: subscriptionResult.orderId,
      paymentRecord: payment
    })

  } catch (error) {
    console.error('PhonePe Autopay setup error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to setup subscription' 
      },
      { status: 500 }
    )
  }
}
