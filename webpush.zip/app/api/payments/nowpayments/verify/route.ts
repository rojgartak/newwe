import { NextRequest, NextResponse } from 'next/server'
import { nowPayments } from '@/lib/nowpayments'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { paymentId } = body

    if (!paymentId) {
      return NextResponse.json(
        { success: false, error: 'Missing paymentId' },
        { status: 400 }
      )
    }

    // Get payment status from NOWPayments
    const payment = await nowPayments.getPaymentStatus(paymentId)

    return NextResponse.json({
      success: true,
      payment: payment
    })

  } catch (error) {
    console.error('NOWPayments payment verification error:', error)
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : 'Payment verification failed' },
      { status: 500 }
    )
  }
}
