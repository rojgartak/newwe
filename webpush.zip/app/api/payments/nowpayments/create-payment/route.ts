import { NextRequest, NextResponse } from 'next/server'
import { nowPayments, generateOrderId, createPaymentDescription } from '@/lib/nowpayments'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      planName,
      amount, // This is now in USD
      originalAmount,
      amountINR, // INR amount for database storage
      originalAmountINR,
      discountAmount,
      couponCode,
      currency,
      userEmail,
      userName,
      method
    } = body

    if (!planName || !userEmail || !userName || !currency) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    console.log('Crypto Payment Request:', {
      planName,
      amountUSD: amount,
      amountINR,
      currency
    })

    // Get or create user in Supabase
    const supabaseAdmin = createSupabaseAdmin()
    let userId: string

    // Try to find existing user
    const { data: existingUser } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('email', userEmail)
      .single()

    if (existingUser) {
      userId = existingUser.id
    } else {
      // Create new user if not exists
      const { data: newUser, error: createError } = await supabaseAdmin
        .from('users')
        .insert({ email: userEmail })
        .select('id')
        .single()

      if (createError || !newUser) {
        console.error('Error creating user:', createError)
        return NextResponse.json(
          { success: false, error: 'Failed to create user account' },
          { status: 500 }
        )
      }
      userId = newUser.id
    }

    // Amount is already in USD from frontend
    const finalAmount = amount || originalAmount

    // Generate order details
    const orderId = generateOrderId(userId, planName.toLowerCase().replace(' premium', ''))
    const orderDescription = createPaymentDescription(planName, userEmail)

    // Create payment request (NOWPayments expects USD)
    const paymentRequest = {
      price_amount: finalAmount,
      price_currency: 'USD', // Always USD for crypto
      pay_currency: currency, // Actual crypto currency selected by user
      order_id: orderId,
      order_description: orderDescription,
      ipn_callback_url: `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/nowpayments`,
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/payment/success`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/payment/cancel`
    }

    // Create invoice via NOWPayments API (provides hosted payment page)
    const invoice = await nowPayments.createInvoice(paymentRequest)

    console.log('NOWPayments Invoice Response:', JSON.stringify(invoice, null, 2))

    // Store payment record in database (using INR amount for consistency)
    const { data: paymentRecord, error: paymentError } = await supabaseAdmin
      .from('payments')
      .insert({
        user_id: userId,
        amount: amountINR || amount, // Store INR amount for admin panel
        currency: 'USD', // Crypto payments are in USD
        status: 'pending',
        payment_gateway: 'nowpayments',
        gateway_payment_id: invoice.id || invoice.payment_id
      })
      .select()
      .single()

    if (paymentError) {
      console.error('Error creating payment record:', paymentError)
      return NextResponse.json(
        { success: false, error: 'Failed to create payment record' },
        { status: 500 }
      )
    }

    // NOWPayments invoice returns invoice_url for hosted payment page
    const paymentUrl = invoice.invoice_url || invoice.payment_url || 
                       `https://nowpayments.io/payment/?iid=${invoice.id}`

    return NextResponse.json({
      success: true,
      payment: {
        ...invoice,
        paymentUrl: paymentUrl,
        invoiceUrl: invoice.invoice_url,
        payAddress: invoice.pay_address,
        payAmount: invoice.pay_amount,
        payCurrency: invoice.pay_currency
      },
      paymentRecord: paymentRecord
    })

  } catch (error) {
    console.error('NOWPayments create payment error:', error)
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : 'Payment creation failed' },
      { status: 500 }
    )
  }
}
