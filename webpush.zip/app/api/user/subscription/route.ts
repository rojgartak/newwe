import { NextRequest, NextResponse } from 'next/server'
import { subscriptionService, userService } from '@/lib/supabase-services'

// Get user subscription status
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    // Get user data
    const user = await userService.getUser(userId)
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Get active subscription
    const subscription = await subscriptionService.getActiveSubscription(userId)

    return NextResponse.json({
      user,
      subscription,
      hasActiveSubscription: user.subscription_status === 'active' && 
                            user.subscription_expires_at && 
                            new Date(user.subscription_expires_at) > new Date()
    })

  } catch (error) {
    console.error('Subscription check error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Create subscription after successful payment
export async function POST(request: NextRequest) {
  try {
    const { userId, planType, paymentGateway, amount, currency, gatewayPaymentId } = await request.json()

    if (!userId || !planType || !paymentGateway || !amount) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Calculate expiry date
    const now = new Date()
    const expiresAt = new Date(now)
    if (planType === 'monthly') {
      expiresAt.setMonth(expiresAt.getMonth() + 1)
    } else if (planType === 'yearly') {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1)
    }

    // Create subscription
    const subscription = await subscriptionService.createSubscription({
      user_id: userId,
      plan_type: planType,
      status: 'active',
      expires_at: expiresAt.toISOString(),
      payment_gateway: paymentGateway,
      amount: parseFloat(amount),
      currency: currency || 'USD'
    })

    if (!subscription) {
      return NextResponse.json(
        { error: 'Failed to create subscription' },
        { status: 500 }
      )
    }

    // Update user subscription status
    await userService.updateSubscriptionStatus(
      userId, 
      'active', 
      expiresAt.toISOString()
    )

    return NextResponse.json({ 
      success: true, 
      subscription,
      message: 'Subscription activated successfully'
    })

  } catch (error) {
    console.error('Subscription creation error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
