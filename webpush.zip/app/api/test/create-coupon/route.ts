import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    // Create a test coupon
    const testCoupon = {
      code: 'TEST20',
      discount_percentage: 20,
      max_uses: 100,
      current_uses: 0,
      expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
      is_active: true,
      created_at: new Date().toISOString()
    }

    const { data: coupon, error } = await supabaseAdmin
      .from('coupons')
      .insert(testCoupon)
      .select()
      .single()

    if (error) {
      console.error('Error creating test coupon:', error)
      return NextResponse.json({ 
        error: 'Failed to create test coupon',
        details: error.message 
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: 'Test coupon created successfully',
      coupon: coupon
    })

  } catch (error) {
    console.error('Error in test coupon creation:', error)
    return NextResponse.json({ 
      error: 'Internal server error',
      details: (error as Error).message 
    }, { status: 500 })
  }
}
