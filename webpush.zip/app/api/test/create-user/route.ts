import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    // Create a test user
    const testUser = {
      id: `test_${Date.now()}`,
      email: 'testuser@example.com',
      subscription_status: 'inactive',
      subscription_plan: null,
      subscription_expires_at: null,
      profiles_created: 0,
      last_login: new Date().toISOString(),
      created_at: new Date().toISOString()
    }

    const { data: user, error } = await supabaseAdmin
      .from('users')
      .insert(testUser)
      .select()
      .single()

    if (error) {
      console.error('Error creating test user:', error)
      return NextResponse.json({ 
        error: 'Failed to create test user',
        details: error.message 
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: 'Test user created successfully',
      user: user
    })

  } catch (error) {
    console.error('Error in test user creation:', error)
    return NextResponse.json({ 
      error: 'Internal server error',
      details: (error as Error).message 
    }, { status: 500 })
  }
}

// GET method to check if users table exists and show current users
export async function GET() {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    const { data: users, error } = await supabaseAdmin
      .from('users')
      .select('*')
      .limit(10)

    if (error) {
      console.error('Error fetching users:', error)
      return NextResponse.json({ 
        error: 'Failed to fetch users',
        details: error.message 
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      count: users?.length || 0,
      users: users || []
    })

  } catch (error) {
    console.error('Error in test user fetch:', error)
    return NextResponse.json({ 
      error: 'Internal server error',
      details: (error as Error).message 
    }, { status: 500 })
  }
}
