import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdmin } from '@/lib/supabase';
import { createClient } from '@supabase/supabase-js';
import { cookies } from 'next/headers';

export async function POST(request: NextRequest) {
  try {
    // Get user ID from request body instead of auth
    const body = await request.json();
    const userId = body.userId;
    
    if (!userId) {
      return NextResponse.json({ 
        success: false, 
        error: 'Unauthorized - User ID required' 
      }, { status: 401 });
    }

    const supabase = createSupabaseAdmin();

    // Check if user already has an active free plan
    const { data: existingPlan, error: checkError } = await supabase
      .from('free_plan_users')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (checkError && checkError.code !== 'PGRST116') {
      console.error('Error checking existing plan:', checkError);
    }

    // If user already has an active plan that hasn't expired
    if (existingPlan && existingPlan.is_active && new Date(existingPlan.expires_at) > new Date()) {
      return NextResponse.json({
        success: true,
        alreadyActive: true,
        message: 'You already have an active free plan',
        expiresAt: existingPlan.expires_at,
        daysRemaining: Math.ceil((new Date(existingPlan.expires_at).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
      });
    }

    // Activate free plan (7 days from now)
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    const { data: planData, error: activateError } = await supabase
      .from('free_plan_users')
      .upsert({
        user_id: userId,
        activated_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        is_active: true,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'user_id'
      })
      .select()
      .single();

    if (activateError) {
      console.error('Error activating free plan:', activateError);
      return NextResponse.json({ 
        success: false, 
        error: activateError.message 
      }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: '7-Day Free Plan activated successfully!',
      plan: planData,
      expiresAt: expiresAt.toISOString(),
      daysRemaining: 7
    });

  } catch (error: any) {
    console.error('Free plan activation error:', error);
    return NextResponse.json({ 
      success: false, 
      error: error.message || 'Failed to activate free plan' 
    }, { status: 500 });
  }
}
