import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdmin } from '@/lib/supabase';
import { getCurrentUser } from '@/lib/supabase-auth';

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json({ 
        success: false, 
        error: 'Unauthorized' 
      }, { status: 401 });
    }

    const { profileName, profileData } = await request.json();

    if (!profileName) {
      return NextResponse.json({ 
        success: false, 
        error: 'Profile name is required' 
      }, { status: 400 });
    }

    const supabase = createSupabaseAdmin();

    // Check if user has active free plan
    const { data: freePlan, error: planError } = await supabase
      .from('free_plan_users')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (planError || !freePlan) {
      return NextResponse.json({ 
        success: false, 
        error: 'No active free plan found. Please activate the free plan first.' 
      }, { status: 403 });
    }

    // Check if plan is active and not expired
    if (!freePlan.is_active || new Date(freePlan.expires_at) < new Date()) {
      return NextResponse.json({ 
        success: false, 
        error: 'Your free plan has expired. Please upgrade to a paid plan.' 
      }, { status: 403 });
    }

    // Get today's date
    const today = new Date().toISOString().split('T')[0];

    // Get or create today's limit record
    const { data: limitData, error: limitError } = await supabase
      .from('daily_profile_limits')
      .select('*')
      .eq('user_id', user.id)
      .eq('date', today)
      .single();

    let profilesCreatedToday = 0;

    if (limitError && limitError.code !== 'PGRST116') {
      console.error('Error fetching daily limits:', limitError);
    }

    if (limitData) {
      profilesCreatedToday = limitData.profiles_created || 0;
    }

    // Check if user has reached daily limit (10 profiles)
    const maxProfiles = 10;
    if (profilesCreatedToday >= maxProfiles) {
      return NextResponse.json({ 
        success: false, 
        error: `Daily limit reached! You can create ${maxProfiles} profiles per day. Come back tomorrow!`,
        profilesCreatedToday,
        maxProfiles,
        remainingProfiles: 0
      }, { status: 403 });
    }

    // Create the profile
    const { data: newProfile, error: profileError } = await supabase
      .from('free_plan_profiles')
      .insert({
        user_id: user.id,
        profile_name: profileName,
        profile_data: profileData || {},
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single();

    if (profileError) {
      console.error('Error creating profile:', profileError);
      return NextResponse.json({ 
        success: false, 
        error: profileError.message 
      }, { status: 500 });
    }

    // Increment daily profile count
    const { error: incrementError } = await supabase
      .from('daily_profile_limits')
      .upsert({
        user_id: user.id,
        date: today,
        profiles_created: profilesCreatedToday + 1,
        max_profiles: maxProfiles,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'user_id,date'
      });

    if (incrementError) {
      console.error('Error incrementing profile count:', incrementError);
    }

    return NextResponse.json({
      success: true,
      message: 'Profile created successfully!',
      profile: newProfile,
      profilesCreatedToday: profilesCreatedToday + 1,
      maxProfiles,
      remainingProfiles: maxProfiles - (profilesCreatedToday + 1)
    });

  } catch (error: any) {
    console.error('Profile creation error:', error);
    return NextResponse.json({ 
      success: false, 
      error: error.message || 'Failed to create profile' 
    }, { status: 500 });
  }
}
