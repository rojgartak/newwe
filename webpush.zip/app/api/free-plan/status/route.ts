import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdmin } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  try {
    // Get userId from query params
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    
    if (!userId) {
      return NextResponse.json({ 
        success: false, 
        error: 'Unauthorized - User ID required' 
      }, { status: 401 });
    }

    const supabase = createSupabaseAdmin();

    // Get user's free plan
    const { data: freePlan, error: planError } = await supabase
      .from('free_plan_users')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (planError && planError.code !== 'PGRST116') {
      console.error('Error fetching free plan:', planError);
      return NextResponse.json({ 
        success: false, 
        error: planError.message 
      }, { status: 500 });
    }

    // If no free plan exists
    if (!freePlan) {
      return NextResponse.json({
        success: true,
        hasPlan: false,
        message: 'No free plan activated'
      });
    }

    // Check if plan is expired
    const now = new Date();
    const expiresAt = new Date(freePlan.expires_at);
    const isExpired = expiresAt < now;
    const daysRemaining = Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    // Get today's profile count
    const today = new Date().toISOString().split('T')[0];
    const { data: limitData, error: limitError } = await supabase
      .from('daily_profile_limits')
      .select('*')
      .eq('user_id', userId)
      .eq('date', today)
      .single();

    let profilesCreatedToday = 0;
    const maxProfiles = 10;

    if (limitData) {
      profilesCreatedToday = limitData.profiles_created || 0;
    }

    const remainingProfiles = Math.max(0, maxProfiles - profilesCreatedToday);

    // Get total profiles created during free plan
    const { count: totalProfiles, error: countError } = await supabase
      .from('free_plan_profiles')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId);

    if (countError) {
      console.error('Error counting profiles:', countError);
    }

    return NextResponse.json({
      success: true,
      hasPlan: true,
      plan: {
        isActive: freePlan.is_active && !isExpired,
        isExpired,
        activatedAt: freePlan.activated_at,
        expiresAt: freePlan.expires_at,
        daysRemaining: isExpired ? 0 : daysRemaining
      },
      daily: {
        profilesCreatedToday,
        maxProfiles,
        remainingProfiles,
        canCreateMore: remainingProfiles > 0 && !isExpired
      },
      totalProfiles: totalProfiles || 0
    });

  } catch (error: any) {
    console.error('Status check error:', error);
    return NextResponse.json({ 
      success: false, 
      error: error.message || 'Failed to get status' 
    }, { status: 500 });
  }
}
