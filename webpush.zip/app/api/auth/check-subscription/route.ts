import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json()
    
    if (!userId) {
      return NextResponse.json(
        { error: 'Missing userId' },
        { status: 400 }
      )
    }

    const supabaseAdmin = createSupabaseAdmin()

    const { data: user, error } = await supabaseAdmin
      .from('users')
      .select('*')
      .eq('id', userId)
      .single()

    if (error || !user) {
      return NextResponse.json({
        hasActiveSubscription: false,
        subscriptionPlan: null,
        expiresAt: null,
        message: 'User not found'
      })
    }

    const now = new Date()
    const isActive = user.subscription_status === 'active' && 
                    user.subscription_expires_at && 
                    new Date(user.subscription_expires_at) > now

    return NextResponse.json({
      hasActiveSubscription: isActive,
      subscriptionPlan: user.subscription_plan,
      expiresAt: user.subscription_expires_at,
      message: isActive ? 'Subscription active' : 'No active subscription'
    })
  } catch (error) {
    console.error('Error checking subscription:', error)
    return NextResponse.json({
      hasActiveSubscription: false,
      subscriptionPlan: null,
      expiresAt: null,
      message: 'Error checking subscription'
    }, { status: 500 })
  }
}
