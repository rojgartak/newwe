import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const { userId, email, action } = await request.json()
    
    if (!userId || !email || !action) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const supabaseAdmin = createSupabaseAdmin()

    if (action === 'create') {
      // Create new user record
      const { error } = await supabaseAdmin
        .from('users')
        .insert({
          id: userId,
          email: email,
          subscription_status: 'inactive',
          profiles_created: 0,
          last_login: new Date().toISOString()
        })

      if (error && !error.message.includes('duplicate key')) {
        console.error('Error creating user:', error)
        return NextResponse.json(
          { error: 'Failed to create user' },
          { status: 500 }
        )
      }
    } else if (action === 'login') {
      // Update last login
      const { error } = await supabaseAdmin
        .from('users')
        .update({ last_login: new Date().toISOString() })
        .eq('id', userId)

      if (error) {
        console.error('Error updating last login:', error)
        return NextResponse.json(
          { error: 'Failed to update login' },
          { status: 500 }
        )
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error syncing user:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
