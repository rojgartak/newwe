import { NextRequest, NextResponse } from 'next/server'
import { userService } from '@/lib/supabase-services'

// Sync Firebase user with Supabase
export async function POST(request: NextRequest) {
  try {
    const { userId, email, action } = await request.json()

    if (!userId || !email) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    if (action === 'create') {
      // Create user in Supabase
      const user = await userService.createUser({
        id: userId,
        email: email,
        created_at: new Date().toISOString(),
        subscription_status: 'inactive',
        profiles_created: 0
      })

      if (!user) {
        return NextResponse.json(
          { error: 'Failed to create user in Supabase' },
          { status: 500 }
        )
      }

      return NextResponse.json({ success: true, user })
    }

    if (action === 'login') {
      // Update last login
      const user = await userService.getUser(userId)
      
      if (!user) {
        // Create user if doesn't exist
        const newUser = await userService.createUser({
          id: userId,
          email: email,
          created_at: new Date().toISOString(),
          subscription_status: 'inactive',
          profiles_created: 0,
          last_login: new Date().toISOString()
        })
        
        return NextResponse.json({ success: true, user: newUser })
      }

      return NextResponse.json({ success: true, user })
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    )

  } catch (error) {
    console.error('Supabase sync error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
