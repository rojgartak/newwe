import { sendVerificationEmail, resendVerificationCode } from '@/lib/emailVerification'

export const runtime = 'nodejs'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age': '86400'
}

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: corsHeaders })
}

export async function POST(req: Request) {
  try {
    const { email, action } = await req.json()
    if (!email) {
      return new Response(JSON.stringify({ ok: false, error: 'Email is required' }), { status: 400, headers: corsHeaders })
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return new Response(JSON.stringify({ ok: false, error: 'Invalid email address' }), { status: 400, headers: corsHeaders })
    }

    let result

    if (action === 'resend') {
      result = await resendVerificationCode(email)
    } else {
      result = await sendVerificationEmail(email)
    }

    if (result.success) {
      return new Response(JSON.stringify({ ok: true, 
        message: action === 'resend' ? 'New verification code sent!' : 'Verification code sent successfully!'
      }), { status: 200, headers: corsHeaders })
    } else {
      return new Response(JSON.stringify({ ok: false, error: result.error }), { status: 500, headers: corsHeaders })
    }
  } catch (err: any) {
    console.error('send-verification error:', err?.message || err)
    return new Response(JSON.stringify({ ok: false, error: 'Failed to send email' }), { status: 500, headers: corsHeaders })
  }
}
