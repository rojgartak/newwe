import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'
import { nowPayments } from '@/lib/nowpayments'

export async function POST(request: NextRequest) {
  try {
    const rawBody = await request.text()
    const payload = JSON.parse(rawBody)
    
    // Verify IPN signature (optional but recommended)
    const signature = request.headers.get('x-nowpayments-sig')
    if (signature && !nowPayments.verifyIPNSignature(rawBody, signature)) {
      console.error('Invalid NOWPayments signature')
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
    }
    
    console.log('NOWPayments webhook received:', payload)
    
    // Log webhook for debugging
    const supabaseAdmin = createSupabaseAdmin()
    await supabaseAdmin.from('webhook_logs').insert({
      gateway: 'nowpayments',
      event_type: payload.payment_status || 'unknown',
      payload: payload,
      status: 'processed'
    })
    
    // Handle different NOWPayments statuses
    switch (payload.payment_status) {
      case 'finished':
        await handlePaymentSuccess(payload)
        break
      case 'failed':
      case 'expired':
        await handlePaymentFailed(payload)
        break
      case 'waiting':
      case 'confirming':
        // Payment is pending, no action needed
        console.log('NOWPayments payment pending:', payload.payment_id)
        break
      default:
        console.log('Unhandled NOWPayments status:', payload.payment_status)
    }

    return NextResponse.json({ status: 'success' })

  } catch (error) {
    console.error('NOWPayments webhook error:', error)
    
    // Log failed webhook
    try {
      const supabaseAdmin = createSupabaseAdmin()
      await supabaseAdmin.from('webhook_logs').insert({
        gateway: 'nowpayments',
        event_type: 'error',
        payload: { error: (error as Error).message },
        status: 'failed'
      })
    } catch (logError) {
      console.error('Failed to log webhook error:', logError)
    }
    
    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    )
  }
}

async function handlePaymentSuccess(payload: any) {
  const { payment_id, order_id, price_amount, pay_currency } = payload

  try {
    // Extract user info from order_id (format: "BB_userid_plan_timestamp")
    const orderParts = order_id.split('_')
    if (orderParts.length < 3) {
      throw new Error('Invalid order_id format')
    }
    
    const userId = orderParts[1]
    const planType = orderParts[2]
    
    if (!userId || !planType) {
      throw new Error('Invalid order_id format')
    }

    const supabaseAdmin = createSupabaseAdmin()

    // Update existing payment record to completed
    const { error: paymentError } = await supabaseAdmin
      .from('payments')
      .update({ 
        status: 'completed',
        gateway_payment_id: payment_id 
      })
      .eq('gateway_payment_id', payment_id)

    if (paymentError) {
      console.error('Error updating payment:', paymentError)
    }

    // Create subscription
    const now = new Date()
    const expiresAt = new Date(now)
    if (planType === 'monthly') {
      expiresAt.setMonth(expiresAt.getMonth() + 1)
    } else if (planType === 'yearly') {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1)
    }

    const { data: subscription, error: subscriptionError } = await supabaseAdmin
      .from('subscriptions')
      .insert({
        user_id: userId,
        plan_type: planType as 'monthly' | 'yearly',
        status: 'active',
        expires_at: expiresAt.toISOString(),
        payment_gateway: 'nowpayments',
        amount: parseFloat(price_amount),
        currency: pay_currency || 'USD'
      })
      .select()
      .single()

    if (subscriptionError) {
      console.error('Error creating subscription:', subscriptionError)
      throw new Error('Failed to create subscription')
    }

    // Update user subscription status
    const { error: userError } = await supabaseAdmin
      .from('users')
      .update({
        subscription_status: 'active',
        subscription_plan: planType as 'monthly' | 'yearly',
        subscription_expires_at: expiresAt.toISOString()
      })
      .eq('id', userId)

    if (userError) {
      console.error('Error updating user subscription:', userError)
    }

    console.log(`NOWPayments payment successful: ${payment_id} for user ${userId}`)

  } catch (error) {
    console.error('Error handling NOWPayments payment success:', error)
    throw error
  }
}

async function handlePaymentFailed(payload: any) {
  const { payment_id, order_id, payment_status } = payload

  try {
    // Extract user info from order_id (format: "BB_userid_plan_timestamp")
    const orderParts = order_id.split('_')
    if (orderParts.length < 2) {
      throw new Error('Invalid order_id format')
    }
    
    const userId = orderParts[1]
    
    if (!userId) {
      throw new Error('Invalid order_id format')
    }

    const supabaseAdmin = createSupabaseAdmin()

    // Update payment status to failed
    const { error: paymentError } = await supabaseAdmin
      .from('payments')
      .update({ status: 'failed' })
      .eq('gateway_payment_id', payment_id)

    if (paymentError) {
      console.error('Error updating failed payment:', paymentError)
    }

    console.log(`NOWPayments payment failed: ${payment_id} for user ${userId}. Status: ${payment_status}`)

  } catch (error) {
    console.error('Error handling NOWPayments payment failure:', error)
    throw error
  }
}
