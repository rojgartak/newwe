import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  const supabaseAdmin = createSupabaseAdmin()
  
  try {
    const body = await request.json()
    const event = body.event
    const payload = body.payload

    console.log('=== PhonePe Autopay Webhook ===')
    console.log('Event:', event)
    console.log('Payload:', JSON.stringify(payload, null, 2))

    // Log webhook
    await supabaseAdmin
      .from('webhook_logs')
      .insert({
        gateway: 'phonepe_autopay',
        event_type: event,
        payload: body,
        status: 'received'
      })

    // Handle different events
    if (event === 'subscription.setup.order.completed') {
      await handleSubscriptionSetupCompleted(payload, supabaseAdmin)
    } else if (event === 'subscription.redemption.order.completed') {
      await handleRedemptionCompleted(payload, supabaseAdmin)
    } else if (event === 'subscription.state.changed') {
      await handleSubscriptionStateChanged(payload, supabaseAdmin)
    }

    return NextResponse.json({ status: 'success' })

  } catch (error) {
    console.error('PhonePe Autopay webhook error:', error)
    
    await supabaseAdmin
      .from('webhook_logs')
      .insert({
        gateway: 'phonepe_autopay',
        event_type: 'error',
        payload: { error: (error as Error).message },
        status: 'failed'
      })
    
    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    )
  }
}

async function handleSubscriptionSetupCompleted(payload: any, supabase: any) {
  try {
    const merchantOrderId = payload.merchantOrderId
    const state = payload.state

    console.log('Subscription setup completed:', merchantOrderId, state)

    if (state === 'COMPLETED') {
      // Update payment status
      const { error: paymentError } = await supabase
        .from('payments')
        .update({ status: 'completed' })
        .eq('gateway_payment_id', merchantOrderId)

      if (paymentError) {
        console.error('Failed to update payment:', paymentError)
        return
      }

      // Get user from payment record
      const { data: payment } = await supabase
        .from('payments')
        .select('user_id, amount, metadata')
        .eq('gateway_payment_id', merchantOrderId)
        .single()

      if (!payment) {
        console.error('Payment not found for:', merchantOrderId)
        return
      }

      // Determine plan type from amount
      const isMonthly = payment.amount < 10000 // ₹100 in paise
      const planType = isMonthly ? 'monthly' : 'yearly'
      
      // Calculate expiry
      const now = new Date()
      const expiresAt = new Date(now)
      if (planType === 'monthly') {
        expiresAt.setMonth(expiresAt.getMonth() + 1)
      } else {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1)
      }

      // Create subscription
      const { error: subError } = await supabase
        .from('subscriptions')
        .insert({
          user_id: payment.user_id,
          plan_type: planType,
          status: 'active',
          expires_at: expiresAt.toISOString(),
          payment_gateway: 'phonepe_autopay',
          amount: payment.amount,
          currency: 'INR',
          metadata: {
            subscriptionId: payment.metadata?.subscriptionId,
            autopay: true
          }
        })

      if (subError) {
        console.error('Failed to create subscription:', subError)
        return
      }

      // Update user
      await supabase
        .from('users')
        .update({
          subscription_status: 'active',
          subscription_plan: planType,
          subscription_expires_at: expiresAt.toISOString()
        })
        .eq('id', payment.user_id)

      console.log(`Subscription activated for user ${payment.user_id}`)
    }

  } catch (error) {
    console.error('Error handling subscription setup:', error)
    throw error
  }
}

async function handleRedemptionCompleted(payload: any, supabase: any) {
  try {
    const merchantOrderId = payload.merchantOrderId
    const state = payload.state
    const amount = payload.amount

    console.log('Redemption completed:', merchantOrderId, state, amount)

    if (state === 'COMPLETED') {
      // Record successful recurring payment
      await supabase
        .from('payments')
        .insert({
          amount: amount,
          currency: 'INR',
          status: 'completed',
          payment_gateway: 'phonepe_autopay',
          gateway_payment_id: merchantOrderId,
          metadata: {
            type: 'redemption',
            autopay: true
          }
        })

      console.log('Recurring payment recorded:', merchantOrderId)
    }

  } catch (error) {
    console.error('Error handling redemption:', error)
    throw error
  }
}

async function handleSubscriptionStateChanged(payload: any, supabase: any) {
  try {
    const subscriptionId = payload.merchantSubscriptionId
    const newState = payload.state

    console.log('Subscription state changed:', subscriptionId, newState)

    // Update subscription status
    await supabase
      .from('subscriptions')
      .update({ 
        status: newState.toLowerCase(),
        metadata: { autopayState: newState }
      })
      .eq('metadata->>subscriptionId', subscriptionId)

    console.log('Subscription status updated:', newState)

  } catch (error) {
    console.error('Error handling state change:', error)
    throw error
  }
}
