import { NextRequest, NextResponse } from 'next/server'
import { validatePhonePeWebhook } from '@/lib/phonepe-payment'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  const supabaseAdmin = createSupabaseAdmin()
  try {
    const body = await request.text()
    const signature = request.headers.get('X-VERIFY') || ''
    
    // Validate webhook signature
    if (!validatePhonePeWebhook(body, signature)) {
      console.error('Invalid PhonePe webhook signature')
      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 401 }
      )
    }

    const payload = JSON.parse(body)
    
    // Log webhook for debugging
    await supabaseAdmin
      .from('webhook_logs')
      .insert({
        gateway: 'phonepe',
        event_type: payload.code || 'unknown',
        payload: payload,
        status: 'processed'
      })

    // Handle different PhonePe response codes
    if (payload.code === 'PAYMENT_SUCCESS') {
      await handlePaymentSuccess(payload)
    } else if (payload.code === 'PAYMENT_ERROR' || payload.code === 'PAYMENT_DECLINED') {
      await handlePaymentFailure(payload)
    }

    return NextResponse.json({ status: 'success' })

  } catch (error) {
    console.error('PhonePe webhook error:', error)
    
    // Log failed webhook
    await supabaseAdmin
      .from('webhook_logs')
      .insert({
        gateway: 'phonepe',
        event_type: 'error',
        payload: { error: (error as Error).message },
        status: 'failed'
      })
    
    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    )
  }
}

async function handlePaymentSuccess(payload: any) {
  const supabaseAdmin = createSupabaseAdmin()
  try {
    const merchantTransactionId = payload.data?.merchantTransactionId
    
    if (!merchantTransactionId) {
      throw new Error('Missing merchantTransactionId in payload')
    }

    // Extract user info from merchantTransactionId (format: "BB_userId_planType_timestamp")
    const parts = merchantTransactionId.split('_')
    if (parts.length < 3) {
      throw new Error('Invalid merchantTransactionId format')
    }
    
    const userId = parts[1]
    const planType = parts[2] === 'Monthly' ? 'monthly' : 'yearly'

    // Update payment status
    const { error: paymentError } = await supabaseAdmin
      .from('payments')
      .update({
        status: 'completed',
        gateway_payment_id: payload.data?.transactionId || merchantTransactionId
      })
      .eq('gateway_payment_id', merchantTransactionId)

    if (paymentError) {
      throw new Error(`Failed to update payment: ${paymentError.message}`)
    }

    // Calculate subscription expiry
    const now = new Date()
    const expiresAt = new Date(now)
    if (planType === 'monthly') {
      expiresAt.setMonth(expiresAt.getMonth() + 1)
    } else {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1)
    }

    // Create subscription
    const { data: subscription, error: subscriptionError } = await supabaseAdmin
      .from('subscriptions')
      .insert({
        user_id: userId,
        plan_type: planType,
        status: 'active',
        expires_at: expiresAt.toISOString(),
        payment_gateway: 'phonepe',
        amount: planType === 'monthly' ? 2550 : 21165,
        currency: 'INR'
      })
      .select()
      .single()

    if (subscriptionError) {
      throw new Error(`Failed to create subscription: ${subscriptionError.message}`)
    }

    // Update user subscription status
    const { error: userError } = await supabaseAdmin
      .from('users')
      .update({
        subscription_status: 'active',
        subscription_plan: planType,
        subscription_expires_at: expiresAt.toISOString()
      })
      .eq('id', userId)

    if (userError) {
      throw new Error(`Failed to update user: ${userError.message}`)
    }

    console.log(`PhonePe payment successful: ${merchantTransactionId} for user ${userId}`)

  } catch (error) {
    console.error('Error handling PhonePe payment success:', error)
    throw error
  }
}

async function handlePaymentFailure(payload: any) {
  const supabaseAdmin = createSupabaseAdmin()
  try {
    const merchantTransactionId = payload.data?.merchantTransactionId
    
    if (!merchantTransactionId) {
      throw new Error('Missing merchantTransactionId in payload')
    }

    // Update payment status to failed
    const { error } = await supabaseAdmin
      .from('payments')
      .update({
        status: 'failed'
      })
      .eq('gateway_payment_id', merchantTransactionId)

    if (error) {
      throw new Error(`Failed to update payment status: ${error.message}`)
    }

    console.log(`PhonePe payment failed: ${merchantTransactionId}`)

  } catch (error) {
    console.error('Error handling PhonePe payment failure:', error)
    throw error
  }
}
