import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  const supabaseAdmin = createSupabaseAdmin()
  
  try {
    // Verify webhook Authorization header if present (SHA256(username:password))
    const authHeader = request.headers.get('authorization') || request.headers.get('Authorization')
    if (authHeader && authHeader.startsWith('SHA256 ')) {
      try {
        const providedHash = authHeader.replace('SHA256 ', '')
        const username = process.env.PHONEPE_WEBHOOK_USERNAME || 'beastbrowser2'
        const password = process.env.PHONEPE_WEBHOOK_PASSWORD || 'beastbrowser2'
        const crypto = require('crypto')
        const expectedHash = crypto.createHash('sha256').update(`${username}:${password}`).digest('hex')
        if (providedHash !== expectedHash) {
          console.warn('Invalid webhook auth signature')
          return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
        }
      } catch (e) {
        console.warn('Webhook auth verification error', e)
        return NextResponse.json({ error: 'Auth verification failed' }, { status: 401 })
      }
    }

    const body = await request.json()
    const event = body.event
    const payload = body.payload

    console.log('=== PhonePe Checkout Webhook ===')
    console.log('Event:', event)
    console.log('Payload:', JSON.stringify(payload, null, 2))

    // Log webhook
    await supabaseAdmin
      .from('webhook_logs')
      .insert({
        gateway: 'phonepe_checkout',
        event_type: event,
        payload: body,
        status: 'received'
      })

    // Handle different events
    if (event === 'checkout.order.completed') {
      await handleOrderCompleted(payload, supabaseAdmin)
    } else if (event === 'checkout.order.failed') {
      await handleOrderFailed(payload, supabaseAdmin)
    }

    return NextResponse.json({ status: 'success' })

  } catch (error) {
    console.error('PhonePe checkout webhook error:', error)
    
    await supabaseAdmin
      .from('webhook_logs')
      .insert({
        gateway: 'phonepe_checkout',
        event_type: 'error',
        payload: { error: (error as Error).message },
        status: 'failed'
      })
    
    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    )
  }
}

async function handleOrderCompleted(payload: any, supabase: any) {
  try {
    const merchantOrderId = payload.merchantOrderId
    const state = payload.state
    const amount = payload.amount

    console.log('Order completed:', merchantOrderId, state)

    if (state === 'COMPLETED') {
      // Update payment status
      const { error: paymentError } = await supabase
        .from('payments')
        .update({ status: 'completed' })
        .eq('gateway_payment_id', merchantOrderId)

      if (paymentError) {
        console.error('Failed to update payment:', paymentError)
        return
      }

      // Get user from payment record
      const { data: payment } = await supabase
        .from('payments')
        .select('user_id, amount')
        .eq('gateway_payment_id', merchantOrderId)
        .single()

      if (!payment) {
        console.error('Payment not found for:', merchantOrderId)
        return
      }

      // Determine plan type from amount
      const isStarter = payment.amount <= 30000 // ≤ ₹300 in paise (Starter Plan)
      const isMonthly = payment.amount > 30000 && payment.amount < 1000000 // Between ₹300-₹10,000
      const planType = isStarter ? 'starter' : (isMonthly ? 'monthly' : 'yearly')
      
      // Calculate expiry
      const now = new Date()
      const expiresAt = new Date(now)
      if (planType === 'starter') {
        expiresAt.setHours(expiresAt.getHours() + 24) // 24 hours for Starter Plan
      } else if (planType === 'monthly') {
        expiresAt.setMonth(expiresAt.getMonth() + 1)
      } else {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1)
      }

      // Create subscription
      const { error: subError } = await supabase
        .from('subscriptions')
        .insert({
          user_id: payment.user_id,
          plan_type: planType,
          status: 'active',
          expires_at: expiresAt.toISOString(),
          payment_gateway: 'phonepe_checkout',
          amount: payment.amount,
          currency: 'INR'
        })

      if (subError) {
        console.error('Failed to create subscription:', subError)
        return
      }

      // Update user
      await supabase
        .from('users')
        .update({
          subscription_status: 'active',
          subscription_plan: planType,
          subscription_expires_at: expiresAt.toISOString()
        })
        .eq('id', payment.user_id)

      console.log(`Subscription activated for user ${payment.user_id}`)
    }

  } catch (error) {
    console.error('Error handling order completion:', error)
    throw error
  }
}

async function handleOrderFailed(payload: any, supabase: any) {
  try {
    const merchantOrderId = payload.merchantOrderId
    const state = payload.state

    console.log('Order failed:', merchantOrderId, state)

    // Update payment status to failed
    const { error } = await supabase
      .from('payments')
      .update({ status: 'failed' })
      .eq('gateway_payment_id', merchantOrderId)

    if (error) {
      console.error('Failed to update payment status:', error)
    }

    console.log('Payment marked as failed:', merchantOrderId)

  } catch (error) {
    console.error('Error handling order failure:', error)
    throw error
  }
}
