import { NextRequest, NextResponse } from 'next/server'
import { profileService, userService, subscriptionService } from '@/lib/supabase-services'

export async function POST(request: NextRequest) {
  try {
    const { userId, profileName, browserFingerprint, proxySettings } = await request.json()

    if (!userId || !profileName) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check if user exists and has active subscription
    const user = await userService.getUser(userId)
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Check subscription status
    if (user.subscription_status !== 'active') {
      return NextResponse.json(
        { error: 'Active subscription required to create profiles' },
        { status: 403 }
      )
    }

    // Check if subscription is expired
    if (user.subscription_expires_at && new Date(user.subscription_expires_at) <= new Date()) {
      return NextResponse.json(
        { error: 'Subscription has expired. Please renew to create profiles.' },
        { status: 403 }
      )
    }

    // Get today's profile count
    const todayCount = await profileService.getTodayProfilesCount(userId)
    
    // Check daily limits (can be configured based on plan)
    const dailyLimit = user.subscription_plan === 'yearly' ? 50 : 20 // Example limits
    
    if (todayCount >= dailyLimit) {
      return NextResponse.json(
        { error: `Daily profile limit reached (${dailyLimit}). Upgrade your plan for higher limits.` },
        { status: 429 }
      )
    }

    // Create profile
    const profile = await profileService.createProfile({
      user_id: userId,
      profile_name: profileName,
      browser_fingerprint: browserFingerprint,
      proxy_settings: proxySettings
    })

    if (!profile) {
      return NextResponse.json(
        { error: 'Failed to create profile' },
        { status: 500 }
      )
    }

    // Increment user's total profile count
    await userService.incrementProfileCount(userId)

    return NextResponse.json({
      success: true,
      profile,
      message: 'Profile created successfully',
      todayCount: todayCount + 1,
      dailyLimit
    })

  } catch (error) {
    console.error('Profile creation error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Get user profiles
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const profiles = await profileService.getUserProfiles(userId)
    const todayCount = await profileService.getTodayProfilesCount(userId)

    return NextResponse.json({
      profiles,
      todayCount,
      totalProfiles: profiles.length
    })

  } catch (error) {
    console.error('Error fetching profiles:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
