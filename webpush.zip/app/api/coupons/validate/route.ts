import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { code, planName, amount } = body

    if (!code) {
      return NextResponse.json(
        { success: false, error: 'Coupon code is required' },
        { status: 400 }
      )
    }

    // Validate coupon using Supabase
    const supabaseAdmin = createSupabaseAdmin()
    
    const { data: coupon, error } = await supabaseAdmin
      .from('coupons')
      .select('*')
      .eq('code', code.toUpperCase())
      .eq('is_active', true)
      .single()

    if (error || !coupon) {
      return NextResponse.json({
        valid: false,
        error: 'Invalid or expired coupon code'
      }, { status: 400 })
    }

    // Check if coupon is expired
    if (new Date(coupon.expires_at) < new Date()) {
      return NextResponse.json({
        valid: false,
        error: 'Coupon has expired'
      }, { status: 400 })
    }

    // Check usage limit
    if (coupon.current_uses >= coupon.max_uses) {
      return NextResponse.json({
        valid: false,
        error: 'Coupon usage limit exceeded'
      }, { status: 400 })
    }

    return NextResponse.json({
      valid: true,
      coupon: {
        id: coupon.id,
        code: coupon.code,
        discount_percentage: coupon.discount_percentage,
        expires_at: coupon.expires_at,
        max_uses: coupon.max_uses,
        current_uses: coupon.current_uses
      }
    })

  } catch (error) {
    console.error('Coupon validation error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to validate coupon' },
      { status: 500 }
    )
  }
}