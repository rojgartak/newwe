import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'
import { couponService } from '@/lib/supabase-services'

// GET - Get coupon usage statistics
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const couponCode = searchParams.get('code')

    // For now, we'll return a simple response since we don't have usage tracking in Firestore yet
    // In a real implementation, you would track coupon usage in a separate collection
    
    if (couponCode) {
      // Get the coupon to verify it exists
      const coupon = await couponService.validateCoupon(couponCode)
      
      if (!coupon) {
        return NextResponse.json(
          { success: false, error: 'Coupon not found' },
          { status: 404 }
        )
      }
      
      return NextResponse.json({
        success: true,
        code: couponCode,
        totalUsage: coupon.current_uses,
        // In a real implementation, you would fetch actual usage history
        usageHistory: []
      })
    } else {
      // Get all coupons for overall statistics
      const { data: coupons, error } = await createSupabaseAdmin()
        .from('coupons')
        .select('*')
        .eq('is_active', true)

      if (error) {
        throw error
      }

      const stats = coupons?.map((coupon: any) => ({
        code: coupon.code,
        count: coupon.current_uses,
        // In a real implementation, you would calculate unique users
        uniqueUsers: 0,
        lastUsed: null
      })) || []

      return NextResponse.json({
        success: true,
        totalCoupons: coupons?.length || 0,
        // In a real implementation, you would calculate total usage
        totalUsage: coupons?.reduce((sum: number, coupon: any) => sum + coupon.current_uses, 0) || 0,
        stats
      })
    }

  } catch (error) {
    console.error('Coupon usage tracking error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to get usage statistics' },
      { status: 500 }
    )
  }
}

// POST - Track a new coupon usage (this would be called when a coupon is successfully applied)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { couponCode, userEmail, planName, paymentId } = body

    if (!couponCode || !userEmail || !planName) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // In a real implementation, you would store coupon usage in a separate collection
    // For now, we'll just validate the coupon exists
    
    const coupon = await couponService.validateCoupon(couponCode)
    
    if (!coupon) {
      return NextResponse.json(
        { success: false, error: 'Invalid coupon code' },
        { status: 400 }
      )
    }

    // Create usage record (in a real implementation, save to Firestore)
    const usageRecord = {
      id: Date.now().toString(),
      couponCode,
      userEmail,
      planName,
      paymentId: paymentId || null,
      usedAt: new Date().toISOString(),
      ipAddress: request.headers.get('x-forwarded-for') || 'unknown',
      userAgent: request.headers.get('user-agent') || 'unknown'
    }

    return NextResponse.json({
      success: true,
      message: 'Coupon usage tracked successfully',
      usageRecord
    })

  } catch (error) {
    console.error('Coupon usage tracking error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to track coupon usage' },
      { status: 500 }
    )
  }
}