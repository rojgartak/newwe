import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { code, planName, userEmail } = body

    if (!code) {
      return NextResponse.json(
        { success: false, error: 'Coupon code is required' },
        { status: 400 }
      )
    }

    const supabaseAdmin = createSupabaseAdmin()

    // Validate coupon from Supabase
    const { data: coupon, error: couponError } = await supabaseAdmin
      .from('coupons')
      .select('*')
      .eq('code', code.toUpperCase())
      .eq('is_active', true)
      .single()

    if (couponError || !coupon) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired coupon code' },
        { status: 400 }
      )
    }

    // Check if coupon is expired
    if (new Date(coupon.expires_at) < new Date()) {
      return NextResponse.json(
        { success: false, error: 'Coupon has expired' },
        { status: 400 }
      )
    }

    // Check if usage limit reached
    if (coupon.current_uses >= coupon.max_uses) {
      return NextResponse.json(
        { success: false, error: 'Coupon usage limit reached' },
        { status: 400 }
      )
    }

    // Increment usage count
    const { error: updateError } = await supabaseAdmin
      .from('coupons')
      .update({ current_uses: coupon.current_uses + 1 })
      .eq('id', coupon.id)

    if (updateError) {
      console.error('Failed to update coupon usage:', updateError)
    }

    // Return success response
    return NextResponse.json({
      success: true,
      message: 'Coupon applied successfully',
      coupon: {
        id: coupon.id,
        code: coupon.code,
        discount_percentage: coupon.discount_percentage,
        is_active: coupon.is_active,
        expires_at: coupon.expires_at,
        max_uses: coupon.max_uses,
        current_uses: coupon.current_uses + 1
      }
    })

  } catch (error) {
    console.error('Coupon apply error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to apply coupon' },
      { status: 500 }
    )
  }
}