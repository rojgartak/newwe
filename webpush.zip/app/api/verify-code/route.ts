import { NextRequest, NextResponse } from 'next/server'
import { verifyCode } from '@/lib/emailVerification'

export const runtime = 'nodejs'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age': '86400'
}

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders })
}

export async function POST(request: NextRequest) {
  try {
    const { email, code } = await request.json()

    if (!email || !code) {
      return NextResponse.json(
        { success: false, error: 'Email and verification code are required' },
        { status: 400 }
      )
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid email address' },
        { status: 400 }
      )
    }

    // Verify the code
    const result = verifyCode(email, code)

    if (result.success) {
      return NextResponse.json({
        success: true,
        message: 'Email verified successfully!',
        verified: true
      }, { headers: corsHeaders })
    } else {
      return NextResponse.json(
        { 
          success: false, 
          error: result.error,
          remainingAttempts: result.remainingAttempts 
        },
        { status: 400, headers: corsHeaders }
      )
    }
  } catch (error) {
    console.error('Code verification error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500, headers: corsHeaders }
    )
  }
}
