import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function GET() {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    console.log('=== DEBUGGING USERS TABLE ===')
    
    // Try to select from users table
    const { data: users, error } = await supabaseAdmin
      .from('users')
      .select('*')
      .limit(10)
    
    if (error) {
      console.error('Error fetching users:', {
        message: error.message,
        details: error.details,
        hint: error.hint,
        code: error.code
      })
      
      return NextResponse.json({
        success: false,
        error: 'Failed to fetch users',
        errorDetails: {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        }
      })
    }
    
    console.log('Users fetched successfully:', users?.length || 0)
    
    return NextResponse.json({
      success: true,
      userCount: users?.length || 0,
      users: users || [],
      message: 'Users table accessible'
    })
    
  } catch (error) {
    console.error('Catch block error:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}

export async function POST() {
  try {
    const supabaseAdmin = createSupabaseAdmin()
    
    // Create a test user
    const testUser = {
      id: `user_${Date.now()}`,
      email: `testuser${Date.now()}@example.com`,
      subscription_status: 'inactive',
      profiles_created: 0,
      created_at: new Date().toISOString()
    }
    
    const { data: newUser, error } = await supabaseAdmin
      .from('users')
      .insert(testUser)
      .select()
      .single()
    
    if (error) {
      console.error('Error creating test user:', error)
      return NextResponse.json({
        success: false,
        error: 'Failed to create test user',
        errorDetails: error
      }, { status: 500 })
    }
    
    return NextResponse.json({
      success: true,
      message: 'Test user created successfully',
      user: newUser
    })
    
  } catch (error) {
    console.error('Error creating test user:', error)
    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      details: (error as Error).message
    }, { status: 500 })
  }
}
