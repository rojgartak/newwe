import { NextRequest, NextResponse } from 'next/server'
import { sendContactFormEmail } from '@/lib/email'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.json()

    // Validate required fields
    if (!formData.name || !formData.email || !formData.message) {
      return NextResponse.json(
        { success: false, error: 'Name, email, and message are required' },
        { status: 400 }
      )
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(formData.email)) {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid email address' },
        { status: 400 }
      )
    }

    // Send email to admin
    const adminEmail = process.env.ADMIN_EMAIL || 'beastbrowser2@beastbrowser.com'
    const result = await sendContactFormEmail(adminEmail, formData)

    if (result.success) {
      // Also send confirmation email to user
      try {
        await sendUserConfirmationEmail(formData.email, formData.name)
      } catch (error) {
        console.warn('Failed to send confirmation email to user:', error)
        // Don't fail the entire request if user confirmation fails
      }

      return NextResponse.json({
        success: true,
        message: 'Message sent successfully! We will get back to you within 2 hours.',
        messageId: result.messageId
      })
    } else {
      console.error('Failed to send email:', result.error)
      return NextResponse.json(
        { 
          success: false, 
          error: 'Failed to send message. Please try again or contact us directly via WhatsApp.' 
        },
        { status: 500 }
      )
    }
  } catch (error) {
    console.error('Contact form error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Helper function to send confirmation email to user
async function sendUserConfirmationEmail(email: string, name: string) {
  const { sendEmail, emailTemplates } = await import('@/lib/email')
  
  const confirmationTemplate = {
    subject: 'Thank you for contacting BeastBrowser!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
        <div style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Thank You!</h1>
        </div>
        
        <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          <h2 style="color: #1f2937; margin-bottom: 20px;">Hi ${name},</h2>
          
          <p style="color: #4b5563; line-height: 1.6; margin-bottom: 20px;">
            Thank you for reaching out to BeastBrowser! We have received your message and our team will get back to you within 2 hours.
          </p>
          
          <div style="background: #ecfdf5; border-left: 4px solid #10b981; padding: 15px; margin: 20px 0; border-radius: 0 4px 4px 0;">
            <p style="margin: 0; color: #047857;">
              <strong>📧 Message received!</strong> We'll respond to your inquiry as soon as possible.
            </p>
          </div>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #1f2937; margin-top: 0;">🚀 While you wait:</h3>
            <ul style="color: #4b5563; line-height: 1.6;">
              <li>Check out our <a href="https://beastbrowser.com/features" style="color: #ff6b35;">features</a></li>
              <li>Download our <a href="https://beastbrowser.com/download" style="color: #ff6b35;">free trial</a></li>
              <li>Read our <a href="https://beastbrowser.com/docs" style="color: #ff6b35;">documentation</a></li>
            </ul>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; text-align: center; margin-top: 30px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
            Need immediate help? Contact us at <a href="mailto:beastbrowser2@beastbrowser.com" style="color: #ff6b35;">beastbrowser2@beastbrowser.com</a> or 
            <a href="https://wa.me/917991985013" style="color: #25d366;">WhatsApp: +91 79919 85013</a>
          </p>
        </div>
      </div>
    `
  }
  
  return await sendEmail(email, confirmationTemplate)
}