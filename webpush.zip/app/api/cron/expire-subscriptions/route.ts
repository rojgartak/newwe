import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

/**
 * Cron Job: Auto-Expire Subscriptions
 * GET /api/cron/expire-subscriptions
 * 
 * This endpoint should be called daily to expire subscriptions
 * Use with cron services like Vercel Cron, GitHub Actions, or external cron
 */
export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseAdmin()
    
    console.log('🕒 BeastBrowser: Starting subscription expiry check...')
    
    const now = new Date()
    console.log('Current time:', now.toISOString())
    
    // Find all active subscriptions that have expired
    const { data: expiredSubscriptions, error: fetchError } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('status', 'active')
      .lt('expires_at', now.toISOString())
    
    if (fetchError) {
      throw new Error('Failed to fetch expired subscriptions: ' + fetchError.message)
    }
    
    console.log(`Found ${expiredSubscriptions?.length || 0} expired subscriptions`)
    
    if (!expiredSubscriptions || expiredSubscriptions.length === 0) {
      return NextResponse.json({
        success: true,
        message: 'No subscriptions to expire',
        expired: 0,
        timestamp: now.toISOString()
      })
    }
    
    let expiredCount = 0
    const results = []
    
    // Update each expired subscription
    for (const subscription of expiredSubscriptions) {
      try {
        // Update subscription status to expired
        const { error: subscriptionError } = await supabase
          .from('subscriptions')
          .update({
            status: 'expired',
            updated_at: now.toISOString()
          })
          .eq('id', subscription.id)
        
        if (subscriptionError) {
          console.error(`❌ Failed to expire subscription ${subscription.id}:`, subscriptionError)
          results.push({
            subscriptionId: subscription.id,
            userEmail: subscription.user_email,
            success: false,
            error: subscriptionError.message
          })
          continue
        }
        
        // Update user status to expired (trigger will handle this automatically, but let's be explicit)
        if (subscription.user_email) {
          const { error: userError } = await supabase
            .from('users')
            .update({
              subscription_status: 'expired',
              updated_at: now.toISOString()
            })
            .eq('email', subscription.user_email)
          
          if (userError) {
            console.error(`⚠️ Failed to update user status for ${subscription.user_email}:`, userError)
          }
        }
        
        console.log(`✅ Expired subscription for ${subscription.user_email} (Plan: ${subscription.plan_type})`)
        expiredCount++
        
        results.push({
          subscriptionId: subscription.id,
          userEmail: subscription.user_email,
          planType: subscription.plan_type,
          expiredAt: subscription.expires_at,
          success: true
        })
        
        // Optional: Send expiry notification email
        try {
          const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
          const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
          
          if (supabaseUrl && serviceKey && subscription.user_email) {
            await fetch(`${supabaseUrl}/functions/v1/send-expiry-email`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${serviceKey}`
              },
              body: JSON.stringify({
                email: subscription.user_email,
                plan: subscription.plan_type,
                expiredAt: subscription.expires_at
              })
            })
            
            console.log(`📧 Expiry notification sent to ${subscription.user_email}`)
          }
        } catch (emailError) {
          console.error('Failed to send expiry email:', emailError)
        }
        
      } catch (error: any) {
        console.error(`❌ Error processing subscription ${subscription.id}:`, error)
        results.push({
          subscriptionId: subscription.id,
          userEmail: subscription.user_email,
          success: false,
          error: error.message
        })
      }
    }
    
    console.log(`🎯 BeastBrowser: Expired ${expiredCount} subscriptions`)
    
    return NextResponse.json({
      success: true,
      message: `Successfully expired ${expiredCount} subscriptions`,
      expired: expiredCount,
      total: expiredSubscriptions.length,
      timestamp: now.toISOString(),
      results: results
    })
    
  } catch (error: any) {
    console.error('❌ Subscription expiry cron error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error.message,
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
}

// Also allow POST for manual triggering
export async function POST(request: NextRequest) {
  return GET(request)
}
