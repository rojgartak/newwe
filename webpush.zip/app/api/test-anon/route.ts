import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

export async function GET() {
  try {
    console.log('Testing Supabase with anon key...')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL!
    const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    
    console.log('URL:', url)
    console.log('Anon Key exists:', !!anonKey)
    console.log('Anon Key length:', anonKey?.length)
    
    const supabase = createClient(url, anonKey)
    
    // Test connection by trying to fetch from a public table
    const { data, error } = await supabase
      .from('coupons')
      .select('count(*)')
      .limit(1)

    if (error) {
      console.error('Supabase anon error:', error)
      return NextResponse.json({ 
        success: false, 
        error: error.message,
        hint: error.hint 
      }, { status: 500 })
    }

    return NextResponse.json({ 
      success: true, 
      message: 'Supabase anon connection working!',
      data 
    })
  } catch (error) {
    console.error('Test anon error:', error)
    return NextResponse.json({ 
      success: false, 
      error: (error as Error).message 
    }, { status: 500 })
  }
}
