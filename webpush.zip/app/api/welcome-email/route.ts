import { NextRequest, NextResponse } from 'next/server'
import { sendWelcomeEmail } from '@/lib/email'

export const runtime = 'nodejs'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age': '86400'
}

export async function OPTIONS() {
  return NextResponse.json({}, { status: 204, headers: corsHeaders })
}

export async function POST(request: NextRequest) {
  try {
    const { email, name } = await request.json()

    if (!email || !name) {
      return NextResponse.json(
        { success: false, error: 'Email and name are required' },
        { status: 400 }
      )
    }

    // Send welcome email
    const result = await sendWelcomeEmail(email, name)

    if (result.success) {
      return NextResponse.json({
        success: true,
        message: 'Welcome email sent successfully!',
        messageId: result.messageId
      }, { headers: corsHeaders })
    } else {
      console.error('Failed to send welcome email:', result.error)
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to send welcome email' },
        { status: 500, headers: corsHeaders }
      )
    }
  } catch (error) {
    console.error('Welcome email error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500, headers: corsHeaders }
    )
  }
}