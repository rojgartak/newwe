import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseAdmin } from '@/lib/supabase'

export async function GET() {
  try {
    console.log('Testing Supabase connection...')
    console.log('URL:', process.env.NEXT_PUBLIC_SUPABASE_URL)
    console.log('Service Role Key exists:', !!process.env.SUPABASE_SERVICE_ROLE_KEY)
    console.log('Service Role Key length:', process.env.SUPABASE_SERVICE_ROLE_KEY?.length)
    console.log('Service Role Key starts with:', process.env.SUPABASE_SERVICE_ROLE_KEY?.substring(0, 20))
    console.log('Service Role Key ends with:', process.env.SUPABASE_SERVICE_ROLE_KEY?.substring(-20))
    
    const supabaseAdmin = createSupabaseAdmin()
    
    // Test connection by trying to fetch users
    const { data, error } = await supabaseAdmin
      .from('users')
      .select('count(*)')
      .limit(1)

    if (error) {
      console.error('Supabase error:', error)
      return NextResponse.json({ 
        success: false, 
        error: error.message,
        hint: error.hint,
        details: error.details 
      }, { status: 500 })
    }

    return NextResponse.json({ 
      success: true, 
      message: 'Supabase connection working!',
      data 
    })
  } catch (error) {
    console.error('Test error:', error)
    return NextResponse.json({ 
      success: false, 
      error: (error as Error).message 
    }, { status: 500 })
  }
}
