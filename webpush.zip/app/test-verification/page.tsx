'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, Send, Check, AlertCircle, RefreshCw } from 'lucide-react'
import { apiFetch } from '@/lib/api'

export default function TestVerificationPage() {
  const [email, setEmail] = useState('')
  const [code, setCode] = useState('')
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'verifying' | 'verified' | 'error'>('idle')
  const [message, setMessage] = useState('')
  const [remainingAttempts, setRemainingAttempts] = useState<number | null>(null)

  const sendVerification = async () => {
    if (!email) {
      setMessage('Please enter an email address')
      setStatus('error')
      return
    }

    setStatus('sending')
    setMessage('')

    try {
      const response = await apiFetch('/api/send-verification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email })
      })

      const result = await response.json()

      if (result.ok) {
        setStatus('sent')
        setMessage('Verification code sent successfully! Please check your email.')
      } else {
        setStatus('error')
        setMessage(result.error || 'Failed to send verification code')
      }
    } catch (error) {
      setStatus('error')
      setMessage('Network error. Please try again.')
    }
  }

  const resendCode = async () => {
    setStatus('sending')
    setMessage('')

    try {
      const response = await apiFetch('/api/send-verification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, action: 'resend' })
      })

      const result = await response.json()

      if (result.ok) {
        setStatus('sent')
        setMessage('New verification code sent successfully!')
        setCode('') // Clear the input
      } else {
        setStatus('error')
        setMessage(result.error || 'Failed to resend verification code')
      }
    } catch (error) {
      setStatus('error')
      setMessage('Network error. Please try again.')
    }
  }

  const verifyCode = async () => {
    if (!code) {
      setMessage('Please enter the verification code')
      setStatus('error')
      return
    }

    setStatus('verifying')
    setMessage('')

    try {
      const response = await apiFetch('/api/verify-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, code })
      })

      const result = await response.json()

      if (result.success) {
        setStatus('verified')
        setMessage('Email verified successfully! 🎉')
        setRemainingAttempts(null)
      } else {
        setStatus('error')
        setMessage(result.error || 'Invalid verification code')
        setRemainingAttempts(result.remainingAttempts || null)
      }
    } catch (error) {
      setStatus('error')
      setMessage('Network error. Please try again.')
    }
  }

  const reset = () => {
    setEmail('')
    setCode('')
    setStatus('idle')
    setMessage('')
    setRemainingAttempts(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 flex items-center justify-center py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full bg-white rounded-2xl shadow-xl border border-gray-100 p-8"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-primary-orange to-primary-red rounded-full flex items-center justify-center mx-auto mb-4">
            <Mail className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Email Verification Test</h1>
          <p className="text-gray-600 text-sm">Test the email verification system</p>
        </div>

        {status !== 'verified' && (
          <div className="space-y-6">
            {/* Email Input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={status === 'sending' || status === 'verifying'}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-transparent disabled:bg-gray-100"
                placeholder="Enter your email address"
              />
            </div>

            {/* Send Code Button */}
            {status === 'idle' && (
              <button
                onClick={sendVerification}
                className="w-full bg-gradient-to-r from-primary-orange to-primary-red text-white py-3 px-4 rounded-lg font-medium hover:shadow-lg transition-all duration-300 flex items-center justify-center space-x-2"
              >
                <Send className="w-4 h-4" />
                <span>Send Verification Code</span>
              </button>
            )}

            {/* Code Input */}
            {(status === 'sent' || status === 'verifying' || (status === 'error' && code)) && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Verification Code
                </label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  disabled={status === 'verifying'}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-transparent text-center text-2xl font-mono tracking-widest disabled:bg-gray-100"
                  placeholder="000000"
                  maxLength={6}
                />
              </div>
            )}

            {/* Action Buttons */}
            {status === 'sent' && (
              <div className="space-y-3">
                <button
                  onClick={verifyCode}
                  disabled={!code || code.length !== 6}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-3 px-4 rounded-lg font-medium hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  <Check className="w-4 h-4" />
                  <span>Verify Code</span>
                </button>
                <button
                  onClick={resendCode}
                  className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg font-medium hover:bg-gray-50 transition-all duration-300 flex items-center justify-center space-x-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Resend Code</span>
                </button>
              </div>
            )}

            {/* Loading States */}
            {status === 'sending' && (
              <div className="text-center py-4">
                <div className="animate-spin w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full mx-auto mb-2"></div>
                <p className="text-gray-600">Sending verification code...</p>
              </div>
            )}

            {status === 'verifying' && (
              <div className="text-center py-4">
                <div className="animate-spin w-8 h-8 border-2 border-green-500 border-t-transparent rounded-full mx-auto mb-2"></div>
                <p className="text-gray-600">Verifying code...</p>
              </div>
            )}
          </div>
        )}

        {/* Success State */}
        {status === 'verified' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-center py-8"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Email Verified!</h2>
            <p className="text-gray-600 mb-6">Your email has been successfully verified.</p>
            <button
              onClick={reset}
              className="bg-gradient-to-r from-primary-orange to-primary-red text-white py-2 px-6 rounded-lg font-medium hover:shadow-lg transition-all duration-300"
            >
              Test Again
            </button>
          </motion.div>
        )}

        {/* Message Display */}
        {message && status !== 'verified' && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className={`mt-4 p-4 rounded-lg flex items-start space-x-3 ${
              status === 'error'
                ? 'bg-red-50 border border-red-200 text-red-800'
                : status === 'sent'
                ? 'bg-green-50 border border-green-200 text-green-800'
                : 'bg-blue-50 border border-blue-200 text-blue-800'
            }`}
          >
            <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm">{message}</p>
              {remainingAttempts !== null && (
                <p className="text-xs mt-1 opacity-80">
                  {remainingAttempts} attempts remaining
                </p>
              )}
            </div>
          </motion.div>
        )}

        {/* Help Text */}
        <div className="mt-6 pt-6 border-t border-gray-100 text-center">
          <p className="text-xs text-gray-500">
            This is a test page for email verification functionality.
            <br />
            Codes expire in 10 minutes and allow 5 verification attempts.
          </p>
        </div>
      </motion.div>
    </div>
  )
}