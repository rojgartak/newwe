'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { HelpCircle, Search, MessageCircle, Book } from 'lucide-react'
import Link from 'next/link'

export default function HelpPage() {
  const faqs = [
    {
      question: 'How does BeastBrowser protect my privacy?',
      answer: 'BeastBrowser uses advanced anti-detection technology including fingerprint spoofing, IP masking, and behavioral pattern randomization to keep you completely anonymous online.'
    },
    {
      question: 'Can I use unlimited browser profiles?',
      answer: 'Yes! With our premium plans, you can create unlimited browser profiles, each with unique fingerprints and complete isolation from other profiles.'
    },
    {
      question: 'Is BeastBrowser compatible with my operating system?',
      answer: 'BeastBrowser supports Windows 10+, macOS 10.15+, and major Linux distributions including Ubuntu 18.04+.'
    },
    {
      question: 'How fast is profile switching?',
      answer: 'Profile switching takes less than 2 seconds thanks to our optimized profile management system and pre-loading technology.'
    },
    {
      question: 'Does BeastBrowser work with proxies?',
      answer: 'Yes, BeastBrowser has built-in proxy support for HTTP, HTTPS, SOCKS4, and SOCKS5 protocols with automatic rotation capabilities.'
    }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
              <HelpCircle className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Help Center</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Find answers to common questions, troubleshooting guides, and comprehensive help for using BeastBrowser.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-20">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Book className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Documentation</h3>
              <p className="text-gray-600 mb-6">Comprehensive guides and technical documentation for all features.</p>
              <Link href="/docs" className="text-primary-orange hover:text-primary-red font-medium">Browse Docs →</Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <MessageCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Contact Support</h3>
              <p className="text-gray-600 mb-6">Get direct help from our expert support team within 2 hours.</p>
              <Link href="/contact" className="text-primary-orange hover:text-primary-red font-medium">Contact Us →</Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Search className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Search Help</h3>
              <p className="text-gray-600 mb-6">Search our knowledge base for specific topics and solutions.</p>
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Search help articles..." 
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-transparent"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Frequently Asked <span className="gradient-text">Questions</span>
            </h2>
          </motion.div>

          <div className="max-w-4xl mx-auto space-y-6">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border p-8"
              >
                <h3 className="text-lg font-bold text-gray-900 mb-4">{faq.question}</h3>
                <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}