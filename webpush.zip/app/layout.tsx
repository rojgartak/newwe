import type { Metadata, Viewport } from 'next'
import './globals.css'

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  themeColor: '#FF6B00',
}

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'https://beastbrowser.com'),
  title: 'BeastBrowser - The Ultimate Anti-Detect Multi-Browser | Privacy & Security',
  description: 'Experience complete online anonymity with BeastBrowser. Advanced anti-detection technology, unlimited browser profiles, and military-grade fingerprint protection. Free download available.',
  keywords: 'anti-detect browser, anonymous browsing, fingerprint protection, multi-browser, privacy browser, secure browsing, proxy browser, BeastBrowser, digital privacy, online anonymity',
  authors: [{ name: 'BeastBrowser Team' }],
  creator: 'BeastBrowser',
  publisher: 'BeastBrowser',
  robots: 'index, follow',
  icons: {
    icon: [
      { url: '/Beast_B.png', type: 'image/png' },
    ],
    shortcut: '/Beast_B.png',
    apple: [
      { url: '/Beast_B.png', sizes: '180x180', type: 'image/png' },
    ],
  },
  manifest: '/site.webmanifest',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://beastbrowser.com',
    title: 'BeastBrowser - The Ultimate Anti-Detect Multi-Browser',
    description: 'The first ultra-lightweight anti-detect browser with lightning-fast performance and advanced fingerprint protection.',
    siteName: 'BeastBrowser',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'BeastBrowser - The Ultimate Anti-Detect Multi-Browser',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BeastBrowser - The Ultimate Anti-Detect Multi-Browser',
    description: 'The first ultra-lightweight anti-detect browser with lightning-fast performance and advanced fingerprint protection.',
    images: ['/og-image.png'],
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="antialiased">
        {children}
      </body>
    </html>
  )
}
