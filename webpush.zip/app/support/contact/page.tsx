'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { MessageCircle } from 'lucide-react'
import Link from 'next/link'

export default function SupportContactPage() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50">
        <div className="container-custom text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
            <MessageCircle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold font-poppins mb-6">
            <span className="gradient-text">Contact Support</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Get direct support from our team of experts. We're here to help you with any questions or issues.
          </p>
          <Link 
            href="/contact"
            className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
          >
            Contact Us
          </Link>
        </div>
      </section>
      <Footer />
    </main>
  )
}