'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { HelpCircle, MessageCircle, Users, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function SupportPage() {
  const supportOptions = [
    {
      icon: HelpCircle,
      title: 'Help Center',
      description: 'Find answers to common questions and troubleshooting guides.',
      link: '/support/help'
    },
    {
      icon: MessageCircle,
      title: 'Contact Us',
      description: 'Get direct support from our team of experts.',
      link: '/support/contact'
    },
    {
      icon: Users,
      title: 'Community',
      description: 'Join our community forum to connect with other users.',
      link: '/support/community'
    }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Support</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              We're here to help you get the most out of BeastBrowser. Find answers, get support, and connect with our community.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {supportOptions.map((option, index) => (
              <motion.div
                key={option.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border p-8 hover:shadow-2xl transition-all duration-300 group text-center"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <option.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4">{option.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{option.description}</p>
                
                <Link 
                  href={option.link}
                  className="inline-flex items-center space-x-2 text-primary-orange font-medium hover:text-primary-red transition-colors duration-200 group"
                >
                  <span>Get Help</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}