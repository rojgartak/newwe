'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'
import { checkSubscriptionStatus } from '@/lib/supabase-auth'

export default function BeastBrowserPage() {
  const router = useRouter()
  const { user, loading } = useSupabaseAuth()
  const [hasAccess, setHasAccess] = useState(false)
  const [checking, setChecking] = useState(true)

  useEffect(() => {
    async function checkAccess() {
      if (loading) return

      if (!user) {
        router.push('/login?redirect=/beastbrowser')
        return
      }

      try {
        const status = await checkSubscriptionStatus(user.id)
        
        if (status.hasActiveSubscription) {
          setHasAccess(true)
        } else {
          router.push('/pricing')
        }
      } catch (error) {
        console.error('Error checking access:', error)
        router.push('/pricing')
      } finally {
        setChecking(false)
      }
    }

    checkAccess()
  }, [user, loading, router])

  if (loading || checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-black to-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary-orange mx-auto mb-4"></div>
          <p className="text-white text-lg">Loading BeastBrowser...</p>
        </div>
      </div>
    )
  }

  if (!hasAccess) {
    return null // Will redirect
  }

  return (
    <div className="w-full h-screen overflow-hidden">
      <iframe
        src="/beastbrowser/index.html"
        className="w-full h-full border-0"
        title="BeastBrowser Application"
        allow="clipboard-read; clipboard-write"
      />
    </div>
  )
}
