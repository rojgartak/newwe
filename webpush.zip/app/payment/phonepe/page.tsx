"use client"

import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { CheckCircle, XCircle, ArrowRight, Home } from 'lucide-react'

function PhonePePaymentPageInner() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const txnId = searchParams.get('txnId')
  const amount = searchParams.get('amount')
  
  const [paymentStatus, setPaymentStatus] = useState<'processing' | 'success' | 'failed'>('processing')
  const [message, setMessage] = useState('')

  useEffect(() => {
    // Simulate payment processing
    const timer = setTimeout(() => {
      // For demo purposes, randomly succeed or fail
      const success = Math.random() > 0.3 // 70% success rate
      
      if (success) {
        setPaymentStatus('success')
        setMessage('Payment completed successfully!')
        
        // In real implementation, you would verify payment with PhonePe API
        // and update the database accordingly
        
        // Redirect to dashboard after 3 seconds
        setTimeout(() => {
          router.push('/dashboard')
        }, 3000)
      } else {
        setPaymentStatus('failed')
        setMessage('Payment failed. Please try again.')
      }
    }, 2000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
      <div className="max-w-md w-full mx-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-8 text-center"
        >
          {paymentStatus === 'processing' && (
            <>
              <div className="w-16 h-16 border-4 border-primary-orange border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
              <h2 className="text-2xl font-semibold text-white mb-4">Processing Payment</h2>
              <p className="text-gray-300 mb-4">Please wait while we process your payment...</p>
              <div className="bg-white/10 rounded-lg p-4">
                <p className="text-sm text-gray-400">Transaction ID: {txnId}</p>
                <p className="text-sm text-gray-400">Amount: ₹{amount}</p>
              </div>
            </>
          )}

          {paymentStatus === 'success' && (
            <>
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-6" />
              <h2 className="text-2xl font-semibold text-white mb-4">Payment Successful!</h2>
              <p className="text-gray-300 mb-6">{message}</p>
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 mb-6">
                <p className="text-green-400 text-sm">Your subscription has been activated!</p>
                <p className="text-sm text-gray-400 mt-2">Transaction ID: {txnId}</p>
              </div>
              <div className="space-y-3">
                <Link
                  href="/dashboard"
                  className="w-full py-3 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-lg hover:shadow-lg transition-all flex items-center justify-center"
                >
                  <Home className="w-5 h-5 mr-2" />
                  Go to Dashboard
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
                <p className="text-gray-400 text-xs">Redirecting automatically in 3 seconds...</p>
              </div>
            </>
          )}

          {paymentStatus === 'failed' && (
            <>
              <XCircle className="w-16 h-16 text-red-500 mx-auto mb-6" />
              <h2 className="text-2xl font-semibold text-white mb-4">Payment Failed</h2>
              <p className="text-gray-300 mb-6">{message}</p>
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 mb-6">
                <p className="text-red-400 text-sm">Transaction could not be completed</p>
                <p className="text-sm text-gray-400 mt-2">Transaction ID: {txnId}</p>
              </div>
              <div className="space-y-3">
                <button
                  onClick={() => router.push('/purchase')}
                  className="w-full py-3 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-lg hover:shadow-lg transition-all flex items-center justify-center"
                >
                  Try Again
                  <ArrowRight className="w-5 h-5 ml-2" />
                </button>
                <Link
                  href="/dashboard"
                  className="block w-full py-3 bg-white/10 text-white font-medium rounded-lg hover:bg-white/20 transition-all text-center"
                >
                  Back to Dashboard
                </Link>
              </div>
            </>
          )}
        </motion.div>
      </div>
    </div>
  )
}

export default function PhonePePaymentPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center"><div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin"></div></div>}>
      <PhonePePaymentPageInner />
    </Suspense>
  )
}
