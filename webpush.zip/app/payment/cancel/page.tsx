'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { XCircle, ArrowLeft, RefreshCcw, HelpCircle } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

export default function PaymentCancelPage() {
  const router = useRouter()
  const [planName, setPlanName] = useState('')
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [reason, setReason] = useState('')

  useEffect(() => {
    const authenticated = localStorage.getItem('isAuthenticated')
    if (!authenticated) {
      router.push('/login')
      return
    }
    setIsAuthenticated(true)

    // Get plan and reason from URL params
    const urlParams = new URLSearchParams(window.location.search)
    const plan = urlParams.get('plan') || 'Premium Plan'
    const failureReason = urlParams.get('reason') || 'cancelled'
    setPlanName(plan)
    setReason(failureReason)
  }, [router])

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  const getTitle = () => {
    switch (reason) {
      case 'failed':
        return 'Payment Failed'
      case 'expired':
        return 'Payment Expired'
      case 'cancelled':
      default:
        return 'Payment Cancelled'
    }
  }

  const getMessage = () => {
    switch (reason) {
      case 'failed':
        return 'Your payment could not be processed. Please try again or contact support.'
      case 'expired':
        return 'Your payment session has expired. Please try again.'
      case 'cancelled':
      default:
        return 'You have cancelled the payment process. No charges have been made to your account.'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-red-50 flex items-center justify-center py-12 px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full text-center"
      >
        {/* Error Icon */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, duration: 0.8, type: "spring" }}
          className="w-20 h-20 bg-gradient-to-br from-red-400 to-red-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-lg"
        >
          <XCircle className="w-10 h-10 text-white" />
        </motion.div>

        {/* Error Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            {getTitle()}
          </h1>
          <p className="text-lg text-gray-600 mb-2">
            {getMessage()}
          </p>
          <p className="text-gray-500">
            You can try again or contact our support team for assistance.
          </p>
        </motion.div>

        {/* Plan Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 mb-8"
        >
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Attempted Plan
          </h3>
          <p className="text-gray-600">{planName}</p>
          <div className="mt-4 text-sm text-gray-500">
            <p>Don't worry, no charges have been made to your account.</p>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="space-y-4"
        >
          <button
            onClick={() => router.back()}
            className="w-full bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold py-3 px-6 rounded-lg hover:shadow-lg transition-all duration-300 flex items-center justify-center space-x-2"
          >
            <RefreshCcw className="w-5 h-5" />
            <span>Try Again</span>
          </button>
          
          <div className="grid grid-cols-2 gap-3">
            <Link
              href="/dashboard"
              className="flex items-center justify-center space-x-2 py-2 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-300"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Dashboard</span>
            </Link>
            <Link
              href="/contact"
              className="flex items-center justify-center space-x-2 py-2 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all duration-300"
            >
              <HelpCircle className="w-4 h-4" />
              <span>Get Help</span>
            </Link>
          </div>
        </motion.div>

        {/* Common Issues */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.6 }}
          className="mt-8 bg-gray-50 rounded-lg p-4 text-left"
        >
          <h4 className="font-semibold text-gray-900 mb-3 text-center">Common Solutions</h4>
          <div className="space-y-2 text-sm text-gray-600">
            <div className="flex items-start space-x-2">
              <span className="text-primary-orange">•</span>
              <span>Check your internet connection</span>
            </div>
            <div className="flex items-start space-x-2">
              <span className="text-primary-orange">•</span>
              <span>Verify your payment method details</span>
            </div>
            <div className="flex items-start space-x-2">
              <span className="text-primary-orange">•</span>
              <span>Try using a different payment method</span>
            </div>
            <div className="flex items-start space-x-2">
              <span className="text-primary-orange">•</span>
              <span>Contact your bank if using card payments</span>
            </div>
          </div>
        </motion.div>

        {/* Support Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.6 }}
          className="mt-8 text-sm text-gray-500"
        >
          <p>Need immediate help?</p>
          <p>
            <a
              href="mailto:support@beastbrowser.com"
              className="text-primary-orange hover:text-primary-red transition-colors"
            >
              support@beastbrowser.com
            </a>{' '}
            or{' '}
            <a
              href="https://wa.me/917991985013"
              className="text-green-600 hover:text-green-700 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              WhatsApp Support
            </a>
          </p>
        </motion.div>
      </motion.div>
    </div>
  )
}