"use client"

import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Copy, CheckCircle, Clock, QrCode, ArrowLeft } from 'lucide-react'

function CryptoPaymentPageInner() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const paymentId = searchParams.get('payment_id')
  
  const [paymentData, setPaymentData] = useState<any>(null)
  const [copied, setCopied] = useState(false)
  const [timeLeft, setTimeLeft] = useState(30 * 60) // 30 minutes in seconds

  useEffect(() => {
    // In a real implementation, you would fetch payment details from your API
    // For now, we'll use mock data
    const mockPaymentData = {
      payment_id: paymentId,
      pay_address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
      pay_amount: 0.00045,
      pay_currency: 'BTC',
      price_amount: 30.72,
      price_currency: 'USD',
      qr_code_url: 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'
    }
    
    setPaymentData(mockPaymentData)
  }, [paymentId])

  useEffect(() => {
    // Countdown timer
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  if (!paymentData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/purchase" className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Purchase</span>
          </Link>
          
          <Link href="/" className="flex items-center space-x-2">
            <img src="/Beast_B.png" alt="BeastBrowser" className="w-8 h-8 rounded-lg" />
            <span className="text-xl font-bold gradient-text">BeastBrowser</span>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card p-8"
          >
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-white mb-2">Complete Your Payment</h1>
              <p className="text-gray-300">Send the exact amount to the address below</p>
            </div>

            {/* Timer */}
            <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-4 mb-8 text-center">
              <div className="flex items-center justify-center mb-2">
                <Clock className="w-5 h-5 text-orange-400 mr-2" />
                <span className="text-orange-400 font-medium">Payment expires in</span>
              </div>
              <div className="text-2xl font-bold text-white">{formatTime(timeLeft)}</div>
            </div>

            {/* Payment Details */}
            <div className="space-y-6">
              {/* Amount */}
              <div className="bg-white/5 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Amount to Send</h3>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary-orange mb-2">
                    {paymentData.pay_amount} {paymentData.pay_currency}
                  </div>
                  <div className="text-gray-400">
                    ≈ ${paymentData.price_amount} USD
                  </div>
                </div>
              </div>

              {/* Address */}
              <div className="bg-white/5 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Payment Address</h3>
                <div className="bg-black/20 rounded-lg p-4 border border-white/10">
                  <div className="flex items-center justify-between">
                    <code className="text-primary-orange text-sm break-all mr-4">
                      {paymentData.pay_address}
                    </code>
                    <button
                      onClick={() => copyToClipboard(paymentData.pay_address)}
                      className="flex-shrink-0 p-2 bg-primary-orange/20 hover:bg-primary-orange/30 rounded-lg transition-colors"
                    >
                      {copied ? (
                        <CheckCircle className="w-5 h-5 text-green-400" />
                      ) : (
                        <Copy className="w-5 h-5 text-primary-orange" />
                      )}
                    </button>
                  </div>
                </div>
                {copied && (
                  <p className="text-green-400 text-sm mt-2">✓ Address copied to clipboard!</p>
                )}
              </div>

              {/* QR Code */}
              <div className="bg-white/5 rounded-lg p-6 text-center">
                <h3 className="text-lg font-semibold text-white mb-4">QR Code</h3>
                <div className="inline-block p-4 bg-white rounded-lg">
                  <img 
                    src={paymentData.qr_code_url} 
                    alt="Payment QR Code"
                    className="w-48 h-48"
                  />
                </div>
                <p className="text-gray-400 text-sm mt-4">
                  Scan with your crypto wallet
                </p>
              </div>

              {/* Instructions */}
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Payment Instructions</h3>
                <ol className="text-gray-300 space-y-2 text-sm">
                  <li className="flex items-start">
                    <span className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5">1</span>
                    Copy the payment address or scan the QR code
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5">2</span>
                    Send exactly <strong>{paymentData.pay_amount} {paymentData.pay_currency}</strong> to the address
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5">3</span>
                    Wait for blockchain confirmation (usually 10-30 minutes)
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5">4</span>
                    Your subscription will be activated automatically
                  </li>
                </ol>
              </div>

              {/* Warning */}
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                <p className="text-red-400 text-sm">
                  ⚠️ <strong>Important:</strong> Send only {paymentData.pay_currency} to this address. 
                  Sending other cryptocurrencies will result in permanent loss of funds.
                </p>
              </div>
            </div>

            {/* Status Check */}
            <div className="mt-8 text-center">
              <button
                onClick={() => window.location.reload()}
                className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors"
              >
                Check Payment Status
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

export default function CryptoPaymentPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center"><div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin"></div></div>}>
      <CryptoPaymentPageInner />
    </Suspense>
  )
}
