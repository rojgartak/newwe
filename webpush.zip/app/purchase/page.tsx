"use client"

import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Check, CreditCard, Smartphone, ArrowRight, Bitcoin, Shield, Zap } from 'lucide-react'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'

const PLANS = [
  { 
    key: 'starter', 
    name: 'Starter Plan', 
    price: 266, 
    currency: 'INR',
    features: ['Unlimited profiles', 'All premium features', 'Valid for 24 hours only']
  },
  { 
    key: 'monthly', 
    name: 'Monthly Premium', 
    price: 2665, 
    currency: 'INR',
    features: ['Unlimited profiles', 'Premium support', 'All features unlocked']
  },
  { 
    key: 'yearly', 
    name: 'Yearly Premium', 
    price: 22122, 
    currency: 'INR',
    features: ['Unlimited profiles', 'Priority support', 'All features unlocked', 'Best value']
  },
]

const CRYPTO_CURRENCIES = [
  { code: 'BTC', name: 'Bitcoin', icon: '₿' },
  { code: 'ETH', name: 'Ethereum', icon: 'Ξ' },
  { code: 'USDTTRC20', name: 'USDT (TRC20)', icon: '₮' },
  { code: 'USDTERC20', name: 'USDT (ERC20)', icon: '₮' },
  { code: 'USDC', name: 'USD Coin', icon: '$' },
  { code: 'LTC', name: 'Litecoin', icon: 'Ł' }
]

export default function PurchasePageWrapper() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <PurchasePage />
    </Suspense>
  )
}

function PurchasePage() {
  const router = useRouter()
  const params = useSearchParams()
  const planParam = params.get('plan')
  const { user, loading } = useSupabaseAuth()

  // Handle both old and new plan parameter formats
  const normalizedPlan = planParam === 'Starter Plan' ? 'starter'
    : planParam === 'Monthly Premium' ? 'monthly' 
    : planParam === 'Yearly Premium' ? 'yearly' 
    : planParam || 'monthly'
  
  const [selectedPlan, setSelectedPlan] = useState<string>(normalizedPlan)
  const [paymentMethod, setPaymentMethod] = useState<'phonepe' | 'crypto'>('phonepe')
  const [selectedCurrency, setSelectedCurrency] = useState<string>('USDTTRC20')
  const [couponCode, setCouponCode] = useState<string>('')
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [message, setMessage] = useState({ type: '', text: '' })

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login')
    }
  }, [user, loading, router])

  const selectedPlanData = PLANS.find(p => p.key === selectedPlan) || PLANS[0]
  const selectedCryptoData = CRYPTO_CURRENCIES.find(c => c.code === selectedCurrency) || CRYPTO_CURRENCIES[0]
  
  // Calculate final price with coupon discount
  const finalPrice = appliedCoupon 
    ? selectedPlanData.price - (selectedPlanData.price * appliedCoupon.discount_percentage / 100)
    : selectedPlanData.price

  // Convert INR to USD for crypto display (1 USD = 83 INR approx)
  const finalPriceUSD = Math.round((finalPrice / 83) * 100) / 100
  const originalPriceUSD = Math.round((selectedPlanData.price / 83) * 100) / 100

  const applyCoupon = async () => {
    if (!couponCode.trim()) {
      setMessage({ type: 'error', text: 'Please enter a coupon code' })
      return
    }
    
    try {
      const response = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode })
      })
      
      const result = await response.json()
      
      if (response.ok && result.valid) {
        setAppliedCoupon(result.coupon)
        setMessage({ type: 'success', text: `Coupon applied! ${result.coupon.discount_percentage}% discount` })
      } else {
        setMessage({ type: 'error', text: 'Invalid or expired coupon code' })
      }
    } catch (error) {
      console.error('Error applying coupon:', error)
      setMessage({ type: 'error', text: 'Error applying coupon. Please try again.' })
    }
  }

  const handlePhonePePayment = async () => {
    if (!user) return
    
    setIsProcessing(true)
    setMessage({ type: '', text: '' })
    
    try {
      console.log('=== FRONTEND DEBUG ===')
      console.log('Selected Plan:', selectedPlanData.name)
      console.log('Original Price (₹):', selectedPlanData.price)
      console.log('Final Price (₹):', finalPrice)
      console.log('Applied Coupon:', appliedCoupon)
      console.log('Discount Amount (₹):', appliedCoupon ? (selectedPlanData.price - finalPrice) : 0)
      
      // Handle 100% discount case
      const paymentAmount = finalPrice === 0 ? 1 : finalPrice // Minimum ₹1 when fully discounted
      console.log('Payment Amount (₹):', paymentAmount)
      
      console.log('Creating PhonePe payment...')
      const response = await fetch('/api/payments/phonepe-checkout/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planName: selectedPlanData.name,
          amount: paymentAmount * 100, // Convert to paise
          originalAmount: selectedPlanData.price * 100,
          discountAmount: appliedCoupon ? (selectedPlanData.price - finalPrice) * 100 : 0,
          couponCode: appliedCoupon?.code || null,
          userEmail: user.email,
          userName: user.email?.split('@')[0] || 'User'
        })
      })
      
      const result = await response.json()
      console.log('Payment response:', result)
      
      if (response.ok && result.success) {
        // Redirect to PhonePe checkout page (prefer paymentUrl if present)
        const redirect = result.paymentUrl || result.redirectUrl
        if (redirect) {
          window.location.href = redirect
        } else {
          throw new Error('Redirect URL not received')
        }
      } else {
        setMessage({ type: 'error', text: result.error || 'Failed to create payment' })
        setIsProcessing(false)
      }
    } catch (error) {
      console.error('PhonePe payment error:', error)
      setMessage({ type: 'error', text: error instanceof Error ? error.message : 'Failed to process payment. Please try again.' })
      setIsProcessing(false)
    }
  }

  const handleCryptoPayment = async () => {
    if (!user) return
    
    // Check minimum amount for crypto (NOWPayments minimum is typically $5-10)
    const CRYPTO_MINIMUM_USD = 5
    if (finalPriceUSD < CRYPTO_MINIMUM_USD) {
      setMessage({ 
        type: 'error', 
        text: `Minimum crypto payment amount is $${CRYPTO_MINIMUM_USD} USD (₹${Math.ceil(CRYPTO_MINIMUM_USD * 83)}). Please choose a higher plan or use PhonePe for smaller amounts.` 
      })
      return
    }
    
    setIsProcessing(true)
    setMessage({ type: '', text: '' })
    
    try {
      // Send USD amount for crypto payments
      const response = await fetch('/api/payments/nowpayments/create-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planName: selectedPlanData.name,
          amount: finalPriceUSD, // Send USD amount
          originalAmount: originalPriceUSD, // Send original USD amount
          amountINR: finalPrice, // Also send INR for reference
          originalAmountINR: selectedPlanData.price,
          discountAmount: appliedCoupon ? (originalPriceUSD - finalPriceUSD) : 0,
          couponCode: appliedCoupon?.code || null,
          currency: selectedCurrency,
          userEmail: user.email,
          userName: user.email?.split('@')[0] || 'User',
          method: 'crypto'
        })
      })
      
      const result = await response.json()
      
      if (response.ok && result.success) {
        // Store payment record
        const payments = JSON.parse(localStorage.getItem('cryptoPayments') || '[]')
        payments.unshift(result.paymentRecord)
        localStorage.setItem('cryptoPayments', JSON.stringify(payments))
        
        // Redirect to crypto payment page or show payment details
        window.location.href = result.payment.paymentUrl
      } else {
        setMessage({ type: 'error', text: result.error || 'Failed to create crypto payment' })
      }
    } catch (error) {
      console.error('Crypto payment error:', error)
      setMessage({ type: 'error', text: 'Failed to process crypto payment. Please try again.' })
    } finally {
      setIsProcessing(false)
    }
  }

  const handlePayment = () => {
    if (paymentMethod === 'phonepe') {
      handlePhonePePayment()
    } else {
      handleCryptoPayment()
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <img src="/Beast_B.png" alt="BeastBrowser" className="w-8 h-8 rounded-lg" />
            <span className="text-xl font-bold gradient-text">BeastBrowser</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <span className="text-gray-300">Welcome, {user.email?.split('@')[0]}</span>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl font-bold text-white mb-4">Choose Your Plan</h1>
            <p className="text-gray-300 text-lg">Unlock the full power of BeastBrowser</p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Plan Selection */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-semibold text-white mb-6">Select Plan</h2>
              
              <div className="space-y-4 mb-8">
                {PLANS.map((plan) => (
                  <div
                    key={plan.key}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedPlan === plan.key
                        ? 'border-primary-orange bg-primary-orange/10'
                        : 'border-white/20 hover:border-white/40'
                    }`}
                    onClick={() => setSelectedPlan(plan.key)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-white">{plan.name}</h3>
                      <span className="text-2xl font-bold text-primary-orange">
                        ₹{plan.price.toLocaleString()}
                      </span>
                    </div>
                    <div className="space-y-1">
                      {plan.features.map((feature, index) => (
                        <div key={index} className="flex items-center text-gray-300 text-sm">
                          <Check className="w-4 h-4 text-green-500 mr-2" />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Coupon Code */}
              <div className="mb-6">
                <label className="block text-white text-sm font-medium mb-2">
                  Coupon Code (Optional)
                </label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="Enter coupon code"
                    className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-orange"
                  />
                  <button
                    onClick={applyCoupon}
                    className="px-4 py-2 bg-primary-orange text-white rounded-lg hover:bg-primary-orange/80 transition-colors"
                  >
                    Apply
                  </button>
                </div>
                {appliedCoupon && (
                  <p className="text-green-400 text-sm mt-2">
                    ✓ {appliedCoupon.discount_percentage}% discount applied
                  </p>
                )}
              </div>

              {/* Final Price */}
              <div className="bg-white/5 rounded-lg p-4 mb-6">
                <div className="flex items-center justify-between text-white">
                  <span className="text-lg">Total Amount:</span>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary-orange">
                      {paymentMethod === 'phonepe' ? (
                        <>₹{finalPrice.toLocaleString()}</>
                      ) : (
                        <>${finalPriceUSD.toFixed(2)}</>
                      )}
                    </div>
                    {paymentMethod === 'crypto' && (
                      <div className="text-xs text-gray-400 mt-1">
                        ≈ ₹{finalPrice.toLocaleString()} INR
                      </div>
                    )}
                  </div>
                </div>
                {appliedCoupon && (
                  <div className="text-sm text-gray-400 mt-1">
                    {paymentMethod === 'phonepe' ? (
                      <>
                        Original: ₹{selectedPlanData.price.toLocaleString()} 
                        <span className="text-green-400 ml-2">
                          (Save ₹{(selectedPlanData.price - finalPrice).toLocaleString()})
                        </span>
                      </>
                    ) : (
                      <>
                        Original: ${originalPriceUSD.toFixed(2)} 
                        <span className="text-green-400 ml-2">
                          (Save ${(originalPriceUSD - finalPriceUSD).toFixed(2)})
                        </span>
                      </>
                    )}
                  </div>
                )}
              </div>
            </motion.div>

            {/* Payment Method Selection */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-semibold text-white mb-6">Payment Method</h2>
              
              {/* Payment Method Tabs */}
              <div className="flex space-x-2 mb-6">
                <button
                  onClick={() => setPaymentMethod('phonepe')}
                  className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                    paymentMethod === 'phonepe'
                      ? 'bg-primary-orange text-white'
                      : 'bg-white/10 text-gray-300 hover:bg-white/20'
                  }`}
                >
                  <Smartphone className="w-5 h-5 inline mr-2" />
                  PhonePe
                </button>
                <button
                  onClick={() => setPaymentMethod('crypto')}
                  className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                    paymentMethod === 'crypto'
                      ? 'bg-primary-orange text-white'
                      : 'bg-white/10 text-gray-300 hover:bg-white/20'
                  }`}
                >
                  <Bitcoin className="w-5 h-5 inline mr-2" />
                  Crypto
                </button>
              </div>

              {/* Payment Method Details */}
              {paymentMethod === 'phonepe' && (
                <div className="mb-6">
                  <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Smartphone className="w-5 h-5 text-purple-400 mr-2" />
                      <span className="text-white font-medium">PhonePe Payment</span>
                    </div>
                    <p className="text-gray-300 text-sm">
                      Pay securely with UPI, Cards, Net Banking via PhonePe. Instant activation after payment confirmation.
                    </p>
                    <div className="mt-2 text-xs text-purple-300">
                      ✓ UPI ✓ Cards ✓ Net Banking ✓ Secure checkout
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'crypto' && (
                <div className="mb-6">
                  {finalPriceUSD < 5 && (
                    <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mb-4">
                      <div className="flex items-start">
                        <Shield className="w-5 h-5 text-yellow-400 mr-2 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-yellow-400 font-semibold text-sm mb-1">Minimum Amount Required</p>
                          <p className="text-gray-300 text-xs">
                            Crypto payments require a minimum of <span className="font-semibold text-white">$5 USD (₹415)</span>. 
                            For this plan, please use <span className="font-semibold text-purple-400">PhonePe</span> payment method.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-4 mb-4">
                    <div className="flex items-center mb-2">
                      <Bitcoin className="w-5 h-5 text-orange-400 mr-2" />
                      <span className="text-white font-medium">Cryptocurrency Payment</span>
                    </div>
                    <p className="text-gray-300 text-sm mb-3">
                      Pay with popular cryptocurrencies. Activation after blockchain confirmation.
                    </p>
                    <div className="bg-black/20 rounded-lg p-3 text-sm">
                      <div className="flex items-center justify-between text-gray-300">
                        <span>You will pay:</span>
                        <span className={`font-semibold text-lg ${finalPriceUSD < 5 ? 'text-yellow-400' : 'text-white'}`}>
                          ${finalPriceUSD.toFixed(2)} USD
                        </span>
                      </div>
                      <div className="text-xs text-gray-400 mt-1">
                        Equivalent to ₹{finalPrice.toLocaleString()} INR (approx)
                      </div>
                      {finalPriceUSD < 5 && (
                        <div className="text-xs text-yellow-400 mt-2 font-semibold">
                          ⚠️ Below minimum ($5 USD)
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <label className="block text-white text-sm font-medium mb-2">
                    Select Cryptocurrency
                  </label>
                  <select
                    value={selectedCurrency}
                    onChange={(e) => setSelectedCurrency(e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-orange"
                  >
                    {CRYPTO_CURRENCIES.map((crypto) => (
                      <option key={crypto.code} value={crypto.code} className="bg-gray-800">
                        {crypto.icon} {crypto.name}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-400 mt-2">
                    * Crypto payments are processed in USD. Final crypto amount will be calculated at checkout.
                  </p>
                </div>
              )}

              {/* Message Display */}
              {message.text && (
                <div className={`p-4 rounded-lg mb-6 ${
                  message.type === 'error' 
                    ? 'bg-red-500/10 border border-red-500/20 text-red-400'
                    : 'bg-green-500/10 border border-green-500/20 text-green-400'
                }`}>
                  {message.text}
                </div>
              )}

              {/* Payment Button */}
              <button
                onClick={handlePayment}
                disabled={isProcessing || (paymentMethod === 'crypto' && finalPriceUSD < 5)}
                className="w-full py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-lg hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isProcessing ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                ) : (
                  <>
                    <Shield className="w-5 h-5 mr-2" />
                    {paymentMethod === 'phonepe' 
                      ? 'Pay with PhonePe'
                      : (finalPriceUSD < 5 ? 'Amount Below Minimum' : 'Pay with Crypto')}
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </button>
              
              {paymentMethod === 'crypto' && finalPriceUSD < 5 && (
                <p className="text-yellow-400 text-xs text-center mt-2">
                  Switch to PhonePe or choose a higher plan to use crypto payment
                </p>
              )}

              <p className="text-gray-400 text-xs text-center mt-4">
                Secure payment processing. Your data is protected.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}
