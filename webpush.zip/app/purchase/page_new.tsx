"use client"

import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Check, CreditCard, Smartphone, ArrowRight, Bitcoin, Shield, Zap } from 'lucide-react'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'

const PLANS = [
  { 
    key: 'monthly', 
    name: 'Monthly Premium', 
    price: 2550, 
    currency: 'INR',
    features: ['20 profiles per day', 'Premium support', 'All features unlocked']
  },
  { 
    key: 'yearly', 
    name: 'Yearly Premium', 
    price: 21165, 
    currency: 'INR',
    features: ['50 profiles per day', 'Priority support', 'All features unlocked', '17% savings']
  },
]

const CRYPTO_CURRENCIES = [
  { code: 'btc', name: 'Bitcoin', icon: '₿' },
  { code: 'eth', name: 'Ethereum', icon: 'Ξ' },
  { code: 'usdt', name: 'Tether USDT', icon: '₮' },
  { code: 'usdc', name: 'USD Coin', icon: '$' },
  { code: 'ltc', name: 'Litecoin', icon: 'Ł' },
  { code: 'trx', name: 'TRON', icon: 'T' }
]

export default function PurchasePageWrapper() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <PurchasePage />
    </Suspense>
  )
}

function PurchasePage() {
  const router = useRouter()
  const params = useSearchParams()
  const planParam = params.get('plan')
  const { user, loading } = useSupabaseAuth()

  const [selectedPlan, setSelectedPlan] = useState<string>(planParam || 'monthly')
  const [paymentMethod, setPaymentMethod] = useState<'phonepe' | 'crypto'>('phonepe')
  const [selectedCurrency, setSelectedCurrency] = useState<string>('btc')
  const [couponCode, setCouponCode] = useState<string>('')
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [message, setMessage] = useState({ type: '', text: '' })

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login')
    }
  }, [user, loading, router])

  const selectedPlanData = PLANS.find(p => p.key === selectedPlan) || PLANS[0]
  const selectedCryptoData = CRYPTO_CURRENCIES.find(c => c.code === selectedCurrency) || CRYPTO_CURRENCIES[0]
  
  // Calculate final price with coupon discount
  const finalPrice = appliedCoupon 
    ? selectedPlanData.price - (selectedPlanData.price * appliedCoupon.discount_percentage / 100)
    : selectedPlanData.price

  const applyCoupon = async () => {
    if (!couponCode.trim()) {
      setMessage({ type: 'error', text: 'Please enter a coupon code' })
      return
    }
    
    try {
      const response = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode })
      })
      
      const result = await response.json()
      
      if (response.ok && result.valid) {
        setAppliedCoupon(result.coupon)
        setMessage({ type: 'success', text: `Coupon applied! ${result.coupon.discount_percentage}% discount` })
      } else {
        setMessage({ type: 'error', text: 'Invalid or expired coupon code' })
      }
    } catch (error) {
      console.error('Error applying coupon:', error)
      setMessage({ type: 'error', text: 'Error applying coupon. Please try again.' })
    }
  }

  const handlePhonePePayment = async () => {
    if (!user) return
    
    setIsProcessing(true)
    setMessage({ type: '', text: '' })
    
    try {
      const response = await fetch('/api/payments/phonepe/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          planType: selectedPlan,
          userEmail: user.email,
          couponCode: appliedCoupon?.code || null,
          finalAmount: finalPrice
        })
      })
      
      const result = await response.json()
      
      if (response.ok && result.success) {
        // Redirect to PhonePe payment page
        window.location.href = result.payment_url
      } else {
        setMessage({ type: 'error', text: result.error || 'Failed to create payment' })
      }
    } catch (error) {
      console.error('PhonePe payment error:', error)
      setMessage({ type: 'error', text: 'Failed to process payment. Please try again.' })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleCryptoPayment = async () => {
    if (!user) return
    
    setIsProcessing(true)
    setMessage({ type: '', text: '' })
    
    try {
      const response = await fetch('/api/payments/nowpayments/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          planType: selectedPlan,
          userEmail: user.email,
          cryptoCurrency: selectedCurrency,
          couponCode: appliedCoupon?.code || null,
          finalAmount: finalPrice
        })
      })
      
      const result = await response.json()
      
      if (response.ok && result.success) {
        // Redirect to crypto payment page or show payment details
        router.push(`/payment/crypto?payment_id=${result.payment_id}`)
      } else {
        setMessage({ type: 'error', text: result.error || 'Failed to create crypto payment' })
      }
    } catch (error) {
      console.error('Crypto payment error:', error)
      setMessage({ type: 'error', text: 'Failed to process crypto payment. Please try again.' })
    } finally {
      setIsProcessing(false)
    }
  }

  const handlePayment = () => {
    if (paymentMethod === 'phonepe') {
      handlePhonePePayment()
    } else {
      handleCryptoPayment()
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <img src="/Beast_B.png" alt="BeastBrowser" className="w-8 h-8 rounded-lg" />
            <span className="text-xl font-bold gradient-text">BeastBrowser</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <span className="text-gray-300">Welcome, {user.email?.split('@')[0]}</span>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl font-bold text-white mb-4">Choose Your Plan</h1>
            <p className="text-gray-300 text-lg">Unlock the full power of BeastBrowser</p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Plan Selection */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-semibold text-white mb-6">Select Plan</h2>
              
              <div className="space-y-4 mb-8">
                {PLANS.map((plan) => (
                  <div
                    key={plan.key}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedPlan === plan.key
                        ? 'border-primary-orange bg-primary-orange/10'
                        : 'border-white/20 hover:border-white/40'
                    }`}
                    onClick={() => setSelectedPlan(plan.key)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-white">{plan.name}</h3>
                      <span className="text-2xl font-bold text-primary-orange">
                        ₹{plan.price.toLocaleString()}
                      </span>
                    </div>
                    <div className="space-y-1">
                      {plan.features.map((feature, index) => (
                        <div key={index} className="flex items-center text-gray-300 text-sm">
                          <Check className="w-4 h-4 text-green-500 mr-2" />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Coupon Code */}
              <div className="mb-6">
                <label className="block text-white text-sm font-medium mb-2">
                  Coupon Code (Optional)
                </label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="Enter coupon code"
                    className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-orange"
                  />
                  <button
                    onClick={applyCoupon}
                    className="px-4 py-2 bg-primary-orange text-white rounded-lg hover:bg-primary-orange/80 transition-colors"
                  >
                    Apply
                  </button>
                </div>
                {appliedCoupon && (
                  <p className="text-green-400 text-sm mt-2">
                    ✓ {appliedCoupon.discount_percentage}% discount applied
                  </p>
                )}
              </div>

              {/* Final Price */}
              <div className="bg-white/5 rounded-lg p-4 mb-6">
                <div className="flex items-center justify-between text-white">
                  <span className="text-lg">Total Amount:</span>
                  <span className="text-2xl font-bold text-primary-orange">
                    ₹{finalPrice.toLocaleString()}
                  </span>
                </div>
                {appliedCoupon && (
                  <div className="text-sm text-gray-400 mt-1">
                    Original: ₹{selectedPlanData.price.toLocaleString()} 
                    <span className="text-green-400 ml-2">
                      (Save ₹{(selectedPlanData.price - finalPrice).toLocaleString()})
                    </span>
                  </div>
                )}
              </div>
            </motion.div>

            {/* Payment Method Selection */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-semibold text-white mb-6">Payment Method</h2>
              
              {/* Payment Method Tabs */}
              <div className="flex space-x-2 mb-6">
                <button
                  onClick={() => setPaymentMethod('phonepe')}
                  className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                    paymentMethod === 'phonepe'
                      ? 'bg-primary-orange text-white'
                      : 'bg-white/10 text-gray-300 hover:bg-white/20'
                  }`}
                >
                  <Smartphone className="w-5 h-5 inline mr-2" />
                  PhonePe UPI
                </button>
                <button
                  onClick={() => setPaymentMethod('crypto')}
                  className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                    paymentMethod === 'crypto'
                      ? 'bg-primary-orange text-white'
                      : 'bg-white/10 text-gray-300 hover:bg-white/20'
                  }`}
                >
                  <Bitcoin className="w-5 h-5 inline mr-2" />
                  Crypto
                </button>
              </div>

              {/* Payment Method Details */}
              {paymentMethod === 'phonepe' && (
                <div className="mb-6">
                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Smartphone className="w-5 h-5 text-blue-400 mr-2" />
                      <span className="text-white font-medium">PhonePe UPI Payment</span>
                    </div>
                    <p className="text-gray-300 text-sm">
                      Pay securely with PhonePe UPI. Instant activation after payment confirmation.
                    </p>
                  </div>
                </div>
              )}

              {paymentMethod === 'crypto' && (
                <div className="mb-6">
                  <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-4 mb-4">
                    <div className="flex items-center mb-2">
                      <Bitcoin className="w-5 h-5 text-orange-400 mr-2" />
                      <span className="text-white font-medium">Cryptocurrency Payment</span>
                    </div>
                    <p className="text-gray-300 text-sm">
                      Pay with popular cryptocurrencies. Activation after blockchain confirmation.
                    </p>
                  </div>
                  
                  <label className="block text-white text-sm font-medium mb-2">
                    Select Cryptocurrency
                  </label>
                  <select
                    value={selectedCurrency}
                    onChange={(e) => setSelectedCurrency(e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-orange"
                  >
                    {CRYPTO_CURRENCIES.map((crypto) => (
                      <option key={crypto.code} value={crypto.code} className="bg-gray-800">
                        {crypto.icon} {crypto.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Message Display */}
              {message.text && (
                <div className={`p-4 rounded-lg mb-6 ${
                  message.type === 'error' 
                    ? 'bg-red-500/10 border border-red-500/20 text-red-400'
                    : 'bg-green-500/10 border border-green-500/20 text-green-400'
                }`}>
                  {message.text}
                </div>
              )}

              {/* Payment Button */}
              <button
                onClick={handlePayment}
                disabled={isProcessing}
                className="w-full py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-lg hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isProcessing ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                ) : (
                  <>
                    <Shield className="w-5 h-5 mr-2" />
                    {paymentMethod === 'phonepe' ? 'Pay with PhonePe' : 'Pay with Crypto'}
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </button>

              <p className="text-gray-400 text-xs text-center mt-4">
                Secure payment processing. Your data is protected.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}
