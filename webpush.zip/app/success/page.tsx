'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Check, ArrowRight, Download, Settings, Users } from 'lucide-react'
import Link from 'next/link'

function SuccessContent() {
  const searchParams = useSearchParams()
  const sessionId = searchParams.get('session_id')
  const [isVerified, setIsVerified] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  const [countdown, setCountdown] = useState(3)

  useEffect(() => {
    if (sessionId) {
      // In a real app, you'd verify the session with Stripe
      // For now, we'll just set it as verified
      setTimeout(() => {
        setIsVerified(true)
        setIsLoading(false)
        // Start countdown for redirect
        const countdownInterval = setInterval(() => {
          setCountdown((prev) => {
            if (prev <= 1) {
              clearInterval(countdownInterval)
              router.push('/dashboard')
              return 0
            }
            return prev - 1
          })
        }, 1000)
      }, 2000)
    } else {
      setIsLoading(false)
    }
  }, [sessionId, router])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Verifying your payment...</p>
        </div>
      </div>
    )
  }

  if (!sessionId || !isVerified) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-red-500 text-2xl">✕</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Payment Not Found</h1>
          <p className="text-gray-600 mb-6">We couldn't verify your payment. Please contact support if you believe this is an error.</p>
          <Link href="/support" className="inline-flex items-center px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
            Contact Support
            <ArrowRight className="w-4 h-4 ml-2" />
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          {/* Success Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5, type: "spring", bounce: 0.5 }}
            className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg"
          >
            <Check className="w-10 h-10 text-white" />
          </motion.div>

          <h1 className="text-4xl font-bold text-gray-900 mb-4">Payment Successful!</h1>
          <p className="text-xl text-gray-600 mb-4">
            Welcome to BeastBrowser Premium! Your account has been upgraded and you're ready to get started.
          </p>
          {isVerified && (
            <p className="text-green-600 font-medium">
              Redirecting to dashboard in {countdown} seconds...
            </p>
          )}

          {/* Features unlocked */}
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">What's now available to you:</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Unlimited Profiles</h3>
                <p className="text-sm text-gray-600">Create unlimited browser profiles for maximum flexibility</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Settings className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Advanced Features</h3>
                <p className="text-sm text-gray-600">Access all premium anti-detection capabilities</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Download className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Priority Support</h3>
                <p className="text-sm text-gray-600">Get priority customer support and faster responses</p>
              </div>
            </div>
          </div>

          {/* Next Steps */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
            >
              <Link 
                href="/download"
                className="block bg-gradient-to-r from-primary-orange to-primary-red text-white p-6 rounded-xl hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <Download className="w-8 h-8 mb-4" />
                <h3 className="text-xl font-semibold mb-2">Download BeastBrowser</h3>
                <p className="text-sm opacity-90 mb-4">Get the latest version of BeastBrowser for your operating system</p>
                <div className="flex items-center text-sm font-medium">
                  Download Now <ArrowRight className="w-4 h-4 ml-2" />
                </div>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6, duration: 0.6 }}
            >
              <Link 
                href="/dashboard"
                className="block bg-white border-2 border-gray-200 text-gray-900 p-6 rounded-xl hover:shadow-lg transition-all duration-300 hover:-translate-y-1 hover:border-primary-orange"
              >
                <Settings className="w-8 h-8 mb-4 text-primary-orange" />
                <h3 className="text-xl font-semibold mb-2">Access Dashboard</h3>
                <p className="text-sm text-gray-600 mb-4">Manage your account settings and view your subscription details</p>
                <div className="flex items-center text-sm font-medium text-primary-orange">
                  Go to Dashboard <ArrowRight className="w-4 h-4 ml-2" />
                </div>
              </Link>
            </motion.div>
          </div>

          {/* Help & Support */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.6 }}
            className="mt-12 text-center"
          >
            <p className="text-gray-600 mb-4">Need help getting started?</p>
            <div className="space-x-4">
              <Link href="/tutorials" className="text-primary-orange hover:text-primary-red font-medium">
                View Tutorials
              </Link>
              <span className="text-gray-300">•</span>
              <Link href="/support" className="text-primary-orange hover:text-primary-red font-medium">
                Contact Support
              </Link>
              <span className="text-gray-300">•</span>
              <Link href="/docs" className="text-primary-orange hover:text-primary-red font-medium">
                Documentation
              </Link>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}

export default function SuccessPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <SuccessContent />
    </Suspense>
  )
}