'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { ShoppingCart, Users, Search, Target, UserCheck, Shield, ArrowRight, Check } from 'lucide-react'
import Link from 'next/link'

const UseCaseCard = ({ icon: Icon, title, description, link, benefits }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6 }}
    className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300 group"
  >
    <div className="flex items-center space-x-4 mb-6">
      <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="text-xl font-bold text-gray-900">{title}</h3>
    </div>
    
    <p className="text-gray-600 mb-6 leading-relaxed">{description}</p>
    
    <div className="space-y-3 mb-6">
      {benefits.map((benefit: string, index: number) => (
        <div key={index} className="flex items-start space-x-2">
          <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
          <span className="text-sm text-gray-600">{benefit}</span>
        </div>
      ))}
    </div>
    
    <Link 
      href={link}
      className="inline-flex items-center space-x-2 text-primary-orange font-medium hover:text-primary-red transition-colors duration-200 group"
    >
      <span>Learn More</span>
      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
    </Link>
  </motion.div>
)

export default function UseCasesPage() {
  const useCases = [
    {
      icon: ShoppingCart,
      title: 'E-commerce Testing',
      description: 'Test e-commerce websites, monitor prices, and manage multiple shopping accounts without detection.',
      link: '/use-cases/e-commerce',
      benefits: [
        'Price monitoring and comparison',
        'Multiple account management',
        'Checkout process testing',
        'Inventory tracking'
      ]
    },
    {
      icon: Users,
      title: 'Social Media Management',
      description: 'Manage multiple social media accounts safely and efficiently with complete profile isolation.',
      link: '/use-cases/social-media',
      benefits: [
        'Multiple account management',
        'Content scheduling and posting',
        'Engagement tracking',
        'Brand monitoring'
      ]
    },
    {
      icon: Search,
      title: 'Market Research',
      description: 'Conduct comprehensive market research and competitive analysis without revealing your identity.',
      link: '/use-cases/market-research',
      benefits: [
        'Competitor analysis',
        'Market trend research',
        'Consumer behavior analysis',
        'Data collection'
      ]
    },
    {
      icon: Target,
      title: 'Ad Verification',
      description: 'Verify ad placements, monitor campaigns, and ensure brand safety across different regions.',
      link: '/use-cases/ad-verification',
      benefits: [
        'Ad placement verification',
        'Campaign monitoring',
        'Brand safety checks',
        'Geographic ad testing'
      ]
    },
    {
      icon: UserCheck,
      title: 'Account Management',
      description: 'Safely manage multiple business accounts across platforms without triggering security flags.',
      link: '/use-cases/account-management',
      benefits: [
        'Multi-platform management',
        'Security compliance',
        'Risk mitigation',
        'Workflow automation'
      ]
    },
    {
      icon: Shield,
      title: 'Privacy Protection',
      description: 'Browse the internet with complete privacy and anonymity for personal or professional use.',
      link: '/use-cases/privacy',
      benefits: [
        'Complete anonymity',
        'Data protection',
        'Tracking prevention',
        'Identity security'
      ]
    }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Use Cases</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Discover how BeastBrowser empowers professionals across different industries with secure, anonymous, and efficient browsing solutions.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Use Cases Grid */}
      <section className="py-20">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {useCases.map((useCase, index) => (
              <UseCaseCard key={useCase.title} {...useCase} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container-custom text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Transform Your Workflow?
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Join thousands of professionals who trust BeastBrowser for their critical browsing needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/pricing"
                className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
              >
                Start Free Trial
              </Link>
              <Link 
                href="/contact"
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-gray-900 transition-all duration-300"
              >
                Contact Sales
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}