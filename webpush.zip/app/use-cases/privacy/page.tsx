'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { Shield } from 'lucide-react'
import Link from 'next/link'

export default function PrivacyPage() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50">
        <div className="container-custom text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold font-poppins mb-6">
            <span className="gradient-text">Privacy Protection</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Browse the internet with complete privacy and anonymity for personal or professional use.
          </p>
        </div>
      </section>
      <section className="py-20 bg-gray-900 text-white text-center">
        <div className="container-custom">
          <h2 className="text-3xl font-bold mb-6">Maximum Privacy & Anonymity</h2>
          <Link href="/pricing" className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300">
            Start Free Trial
          </Link>
        </div>
      </section>
      <Footer />
    </main>
  )
}