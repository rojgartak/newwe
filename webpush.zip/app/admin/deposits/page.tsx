"use client"

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { CheckCircle, XCircle, Search, Eye, DollarSign } from 'lucide-react'

export default function AdminDepositsPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [authed, setAuthed] = useState(false)
  const [deposits, setDeposits] = useState<any[]>([])
  const [query, setQuery] = useState('')
  const [previewId, setPreviewId] = useState<number | null>(null)

  useEffect(() => {
    const authenticated = localStorage.getItem('isAuthenticated')
    const role = localStorage.getItem('userRole')
    if (authenticated && role === 'admin') {
      setAuthed(true)
    } else {
      router.push('/admin')
    }
    setLoading(false)
  }, [router])

  useEffect(() => {
    try {
      const stored = localStorage.getItem('deposits')
      const parsed = stored ? JSON.parse(stored) : []
      setDeposits(Array.isArray(parsed) ? parsed : [])
    } catch {
      setDeposits([])
    }
  }, [])

  const filtered = useMemo(() => {
    if (!query) return deposits
    const q = query.toLowerCase()
    return deposits.filter(d =>
      (d.userEmail || '').toLowerCase().includes(q) ||
      (d.plan || '').toLowerCase().includes(q) ||
      (d.status || '').toLowerCase().includes(q)
    )
  }, [deposits, query])

  const updateAndPersist = (next: any[]) => {
    setDeposits(next)
    localStorage.setItem('deposits', JSON.stringify(next))
  }

  const approve = (id: number) => {
    try {
      const next = deposits.map(d => d.id === id ? { ...d, status: 'Approved' } : d)
      updateAndPersist(next)
      const dep = deposits.find(d => d.id === id)
      if (dep) {
        const usersRaw = localStorage.getItem('users')
        const users = usersRaw ? JSON.parse(usersRaw) : []
        const idx = users.findIndex((u: any) => u.email === dep.userEmail)
        if (idx >= 0) {
          users[idx] = { ...users[idx], plan: dep.plan }
          localStorage.setItem('users', JSON.stringify(users))
        }
        // Referral conversion
        try {
          const referralsRaw = localStorage.getItem('referrals')
          const referrals = referralsRaw ? JSON.parse(referralsRaw) : []
          const rIdx = referrals.findIndex((r: any) => r.refereeEmail === dep.userEmail && r.status === 'Pending')
          if (rIdx >= 0) {
            const commission = Number(dep.amount) * 0.3
            referrals[rIdx] = { ...referrals[rIdx], status: 'Converted', plan: dep.plan, commission }
            localStorage.setItem('referrals', JSON.stringify(referrals))
          }
        } catch {}
      }
    } catch {}
  }

  const reject = (id: number) => {
    const next = deposits.map(d => d.id === id ? { ...d, status: 'Rejected' } : d)
    updateAndPersist(next)
  }

  if (loading || !authed) return null

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-orange via-red-500 to-primary-red rounded-xl flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold">Deposit Requests</div>
              <div className="text-xs text-gray-500">Review and approve purchases</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/admin" className="text-sm text-gray-600 hover:text-primary-orange">Dashboard</Link>
            <span className="text-gray-300">/</span>
            <span className="text-sm text-gray-800 font-medium">Deposits</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between mb-6">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search by email, plan, or status"
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange"
            />
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="text-left px-4 py-3">User</th>
                  <th className="text-left px-4 py-3">Plan</th>
                  <th className="text-left px-4 py-3">Amount</th>
                  <th className="text-left px-4 py-3">Currency</th>
                  <th className="text-left px-4 py-3">Status</th>
                  <th className="text-right px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-gray-500">No deposit requests</td>
                  </tr>
                )}
                {filtered.map(d => (
                  <tr key={d.id} className="border-t border-gray-100">
                    <td className="px-4 py-3 text-gray-700">{d.userEmail}</td>
                    <td className="px-4 py-3 text-gray-700">{d.plan}</td>
                    <td className="px-4 py-3 text-gray-700">${Number(d.amount).toFixed(2)}</td>
                    <td className="px-4 py-3 text-gray-700">{d.currency}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 text-xs rounded-full ${d.status === 'Pending' ? 'bg-yellow-100 text-yellow-700' : d.status === 'Approved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{d.status}</span>
                    </td>
                    <td className="px-4 py-3 text-right space-x-2">
                      <button onClick={() => setPreviewId(d.id)} className="inline-flex items-center px-2 py-1 text-xs text-gray-700 hover:bg-gray-100 rounded border border-gray-200">
                        <Eye className="w-4 h-4 mr-1" /> Preview
                      </button>
                      <button onClick={() => approve(d.id)} className="inline-flex items-center px-2 py-1 text-xs text-green-700 hover:bg-green-50 rounded border border-green-200">
                        <CheckCircle className="w-4 h-4 mr-1" /> Approve
                      </button>
                      <button onClick={() => reject(d.id)} className="inline-flex items-center px-2 py-1 text-xs text-red-700 hover:bg-red-50 rounded border border-red-200">
                        <XCircle className="w-4 h-4 mr-1" /> Reject
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Preview modal */}
        {previewId && (() => {
          const d = deposits.find(x => x.id === previewId)
          if (!d) return null
          return (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setPreviewId(null)}>
              <div className="bg-white rounded-xl max-w-2xl w-full p-4" onClick={(e) => e.stopPropagation()}>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm text-gray-500">{d.userEmail}</div>
                    <div className="text-lg font-semibold">{d.plan} — ${Number(d.amount).toFixed(2)} ({d.currency})</div>
                    <div className="text-xs text-gray-500 break-all">Address: {d.address}</div>
                  </div>
                  <button onClick={() => setPreviewId(null)} className="text-gray-600 hover:text-gray-900">✕</button>
                </div>
                {d.screenshot ? (
                  <img src={d.screenshot} alt="Screenshot" className="max-h-[70vh] w-auto mx-auto rounded-lg border border-gray-200" />
                ) : (
                  <div className="text-sm text-gray-500">No screenshot uploaded.</div>
                )}
                <div className="mt-4 flex items-center gap-2 justify-end">
                  <button onClick={() => approve(d.id)} className="px-3 py-2 text-sm text-white bg-green-600 rounded-lg hover:bg-green-700">Approve</button>
                  <button onClick={() => reject(d.id)} className="px-3 py-2 text-sm text-white bg-red-600 rounded-lg hover:bg-red-700">Reject</button>
                </div>
              </div>
            </div>
          )
        })()}
      </main>
    </div>
  )
}
