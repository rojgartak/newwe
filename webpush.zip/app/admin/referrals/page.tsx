"use client"

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Users, DollarSign, CheckCircle, Trash2, Search, Wallet } from 'lucide-react'

export default function AdminReferralsPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [authed, setAuthed] = useState(false)
  const [referrals, setReferrals] = useState<any[]>([])
  const [query, setQuery] = useState('')

  useEffect(() => {
    const authenticated = localStorage.getItem('isAuthenticated')
    const role = localStorage.getItem('userRole')
    if (authenticated && role === 'admin') {
      setAuthed(true)
    } else {
      router.push('/admin')
    }
    setLoading(false)
  }, [router])

  useEffect(() => {
    try {
      const stored = localStorage.getItem('referrals')
      const parsed = stored ? JSON.parse(stored) : []
      setReferrals(Array.isArray(parsed) ? parsed : [])
    } catch {
      setReferrals([])
    }
  }, [])

  const filtered = useMemo(() => {
    if (!query) return referrals
    const q = query.toLowerCase()
    return referrals.filter(r =>
      (r.referrerEmail || '').toLowerCase().includes(q) ||
      (r.refereeEmail || '').toLowerCase().includes(q) ||
      (r.status || '').toLowerCase().includes(q)
    )
  }, [referrals, query])

  const totals = useMemo(() => {
    const converted = referrals.filter(r => r.status === 'Converted' || r.status === 'Paid')
    const commission = converted.reduce((sum, r) => sum + (Number(r.commission) || 0), 0)
    return { count: referrals.length, converted: converted.length, commission }
  }, [referrals])

  const markPaid = (id: number) => {
    const next = referrals.map(r => r.id === id ? { ...r, status: 'Paid' } : r)
    setReferrals(next)
    localStorage.setItem('referrals', JSON.stringify(next))
  }

  const remove = (id: number) => {
    const next = referrals.filter(r => r.id !== id)
    setReferrals(next)
    localStorage.setItem('referrals', JSON.stringify(next))
  }

  if (loading || !authed) return null

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-orange via-red-500 to-primary-red rounded-xl flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold">Referrals</div>
              <div className="text-xs text-gray-500">Track referral performance</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/admin" className="text-sm text-gray-600 hover:text-primary-orange">Dashboard</Link>
            <span className="text-gray-300">/</span>
            <span className="text-sm text-gray-800 font-medium">Referrals</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <div className="text-xs text-gray-500">Total Referrals</div>
            <div className="text-2xl font-semibold">{totals.count}</div>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <div className="text-xs text-gray-500">Converted</div>
            <div className="text-2xl font-semibold">{totals.converted}</div>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <div className="text-xs text-gray-500">Total Commission</div>
            <div className="text-2xl font-semibold">${totals.commission.toFixed(2)}</div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between mb-6">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search by email or status"
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange"
            />
          </div>
        </div>

        {/* Coming Soon Banner */}
        <div className="bg-gradient-to-r from-primary-orange to-primary-red rounded-xl p-8 text-center text-white mb-6">
          <h2 className="text-2xl font-bold mb-2">🚀 Referral Program Coming Soon!</h2>
          <p className="text-lg opacity-90 mb-4">
            Earn up to 30% commission for every successful referral
          </p>
          <div className="bg-white/20 rounded-lg p-4 max-w-md mx-auto">
            <p className="text-sm">
              We're building an amazing referral system that will launch soon. 
              Stay tuned for updates!
            </p>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="text-left px-4 py-3">Referrer</th>
                  <th className="text-left px-4 py-3">Referee</th>
                  <th className="text-left px-4 py-3">Status</th>
                  <th className="text-left px-4 py-3">Plan</th>
                  <th className="text-left px-4 py-3">Commission</th>
                  <th className="text-right px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center">
                    <div className="text-gray-400">
                      <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <h3 className="text-lg font-medium text-gray-600 mb-2">Referral Program Coming Soon</h3>
                      <p className="text-sm text-gray-500 max-w-md mx-auto">
                        We're working on an exciting referral program that will allow you to earn commissions 
                        for bringing new users to BeastBrowser. Stay tuned!
                      </p>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  )
}
