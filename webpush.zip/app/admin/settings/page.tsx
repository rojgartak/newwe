"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { motion } from "framer-motion"
import { 
  Settings, 
  Shield, 
  Bell, 
  Save, 
  Users, 
  Activity, 
  CreditCard, 
  Tag, 
  DollarSign, 
  Home,
  ArrowLeft
} from "lucide-react"
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'
import { checkAdminAccess } from '@/lib/admin-auth'

export default function AdminSettingsPage() {
  const { user, loading } = useSupabaseAuth()
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  const [siteName, setSiteName] = useState("BeastBrowser")
  const [siteEmail, setSiteEmail] = useState("support@beastbrowser.com")
  const [starterPlanPrice, setStarterPlanPrice] = useState(266)
  const [monthlyPlanPrice, setMonthlyPlanPrice] = useState(2665)
  const [yearlyPlanPrice, setYearlyPlanPrice] = useState(22122)
  const [saved, setSaved] = useState<string | null>(null)

  useEffect(() => {
    if (!loading) {
      if (user) {
        checkUserAccess()
      } else {
        router.push('/admin')
      }
    }
  }, [user, loading, router])

  const checkUserAccess = async () => {
    if (!user) return

    const isAdmin = await checkAdminAccess(user)
    if (isAdmin) {
      setIsAuthenticated(true)
      loadSettings()
    } else {
      router.push('/admin')
    }
  }

  const loadSettings = () => {
    try {
      const raw = localStorage.getItem("adminSettings")
      if (raw) {
        const s = JSON.parse(raw)
        if (s.siteName) setSiteName(s.siteName)
        if (s.siteEmail) setSiteEmail(s.siteEmail)
        if (s.starterPlanPrice) setStarterPlanPrice(s.starterPlanPrice)
        if (s.monthlyPlanPrice) setMonthlyPlanPrice(s.monthlyPlanPrice)
        if (s.yearlyPlanPrice) setYearlyPlanPrice(s.yearlyPlanPrice)
      }
    } catch {}
  }


  const save = () => {
    const data = { siteName, siteEmail, starterPlanPrice, monthlyPlanPrice, yearlyPlanPrice }
    localStorage.setItem("adminSettings", JSON.stringify(data))
    setSaved("Settings saved successfully!")
    setTimeout(() => setSaved(null), 3000)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed top-0 left-0 h-screen w-64 bg-gray-900 text-white z-50 overflow-y-auto">
        <div className="p-6 border-b border-white/10">
          <Link href="/" className="flex items-center space-x-3">
            <img src="/Beast_B.png" alt="BeastBrowser" className="w-10 h-10 rounded-xl" />
            <span className="text-xl font-bold gradient-text">BeastBrowser</span>
          </Link>
        </div>
        
        <nav className="p-4">
          <ul className="space-y-2">
            <li>
              <Link
                href="/admin"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                <Activity className="w-5 h-5" />
                <span>Dashboard</span>
              </Link>
            </li>
            <li>
              <Link
                href="/admin/users"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                <Users className="w-5 h-5" />
                <span>Users</span>
              </Link>
            </li>
            <li>
              <Link
                href="/admin/plans"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                <CreditCard className="w-5 h-5" />
                <span>Plans</span>
              </Link>
            </li>
            <li>
              <Link
                href="/admin/coupons"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                <Tag className="w-5 h-5" />
                <span>Coupons</span>
              </Link>
            </li>
            <li>
              <Link
                href="/admin/payments"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                <DollarSign className="w-5 h-5" />
                <span>Payments</span>
              </Link>
            </li>
            <li>
              <Link
                href="/admin/settings"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg bg-white/10 text-white"
              >
                <Settings className="w-5 h-5" />
                <span>Settings</span>
              </Link>
            </li>
            <li className="pt-4 border-t border-white/10">
              <Link
                href="/"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                <Home className="w-5 h-5" />
                <span>Back to Website</span>
              </Link>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Main Content */}
      <div className="ml-64 min-h-screen">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
          <div className="px-8 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link 
                href="/admin"
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Dashboard</span>
              </Link>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          </div>
        </header>

        <main className="p-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {saved && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 text-sm text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-3"
              >
                ✅ {saved}
              </motion.div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                {/* General Settings */}
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900">General Settings</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Site Name</label>
                      <input 
                        type="text"
                        value={siteName} 
                        onChange={e => setSiteName(e.target.value)} 
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange" 
                        placeholder="BeastBrowser"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Site Email</label>
                      <input 
                        type="email"
                        value={siteEmail} 
                        onChange={e => setSiteEmail(e.target.value)} 
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange" 
                        placeholder="support@beastbrowser.com"
                      />
                    </div>
                  </div>
                </div>

                {/* Pricing Settings */}
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900">Pricing Settings</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Starter Plan Price (₹)</label>
                      <input 
                        type="number"
                        min="0"
                        step="1"
                        value={starterPlanPrice} 
                        onChange={e => setStarterPlanPrice(parseInt(e.target.value) || 0)} 
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange" 
                      />
                      <p className="text-xs text-gray-500 mt-1">24-hour trial plan price</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Monthly Premium Price (₹)</label>
                      <input 
                        type="number"
                        min="0"
                        step="1"
                        value={monthlyPlanPrice} 
                        onChange={e => setMonthlyPlanPrice(parseInt(e.target.value) || 0)} 
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange" 
                      />
                      <p className="text-xs text-gray-500 mt-1">Monthly subscription price</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Yearly Premium Price (₹)</label>
                      <input 
                        type="number"
                        min="0"
                        step="1"
                        value={yearlyPlanPrice} 
                        onChange={e => setYearlyPlanPrice(parseInt(e.target.value) || 0)} 
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange" 
                      />
                      <p className="text-xs text-gray-500 mt-1">Yearly subscription price</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                  <h3 className="text-lg font-semibold mb-4 text-gray-900">Actions</h3>
                  <button 
                    onClick={save} 
                    className="w-full inline-flex items-center justify-center px-4 py-3 bg-gradient-to-r from-primary-orange to-primary-red text-white rounded-lg hover:shadow-lg transition-all"
                  >
                    <Save className="w-4 h-4 mr-2" /> 
                    Save Settings
                  </button>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-2 text-blue-900">ℹ️ About</h3>
                  <p className="text-sm text-blue-700">These settings are stored locally in your browser. Changes will apply to your admin session only.</p>
                </div>
              </div>
            </div>
          </motion.div>
        </main>
      </div>
    </div>
  )
}
