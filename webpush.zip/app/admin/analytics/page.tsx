"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { BarChart3 } from "lucide-react"

function lastNDates(n: number) {
  const dates: string[] = []
  const d = new Date()
  for (let i = 0; i < n; i++) {
    const dd = new Date(d)
    dd.setDate(d.getDate() - i)
    dates.push(dd.toISOString().split("T")[0])
  }
  return dates.reverse()
}

export default function AdminAnalyticsPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [authed, setAuthed] = useState(false)
  const [users, setUsers] = useState<any[]>([])

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { getCurrentUser } = await import('@/lib/supabase-auth')
        const user = await getCurrentUser()
        
        if (user && user.email === 'beastbrowser2@beastbrowser.com') {
          setAuthed(true)
        } else {
          router.push('/admin')
        }
      } catch (error) {
        console.error('Analytics auth error:', error)
        router.push('/admin')
      }
      setLoading(false)
    }
    
    checkAuth()
  }, [router])

  useEffect(() => {
    try {
      const stored = localStorage.getItem("users")
      const parsed = stored ? JSON.parse(stored) : []
      setUsers(Array.isArray(parsed) ? parsed : [])
    } catch {
      setUsers([])
    }
  }, [])

  const total = users.length
  const last7 = lastNDates(7)
  const signupsByDay = last7.map(date => ({
    date,
    count: users.filter(u => u.joined === date).length,
  }))

  const maxCount = signupsByDay.reduce((m, x) => Math.max(m, x.count), 0) || 1

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!authed) return null

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold">Analytics</div>
              <div className="text-xs text-gray-500">Overview of usage</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/admin" className="text-sm text-gray-600 hover:text-primary-orange">Dashboard</Link>
            <span className="text-gray-300">/</span>
            <span className="text-sm text-gray-800 font-medium">Analytics</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Top stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-white border border-gray-200 rounded-xl p-5">
            <div className="text-sm text-gray-600">Total Users</div>
            <div className="text-3xl font-bold">{total}</div>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-5">
            <div className="text-sm text-gray-600">Active Sessions</div>
            <div className="text-3xl font-bold">0</div>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-5">
            <div className="text-sm text-gray-600">Revenue</div>
            <div className="text-3xl font-bold">$0</div>
          </div>
        </div>

        {/* Signups last 7 days */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="font-semibold mb-4">Signups (last 7 days)</div>
          <div className="flex items-end gap-3 h-40">
            {signupsByDay.map(({ date, count }) => (
              <div key={date} className="flex flex-col items-center gap-2 flex-1">
                <div className="w-full bg-gradient-to-t from-primary-orange to-primary-red rounded-t-md" style={{ height: `${(count / maxCount) * 100}%` }} />
                <div className="text-xs text-gray-600">{date.slice(5)}</div>
                <div className="text-xs text-gray-800 font-medium">{count}</div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
