"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Users, Trash2, Plus, Search, Shield, Calendar, CreditCard } from "lucide-react"
import { createSupabaseAdmin } from '@/lib/supabase'
import { getCurrentUser } from '@/lib/supabase-auth'

interface SupabaseUser {
  id: string
  email: string
  created_at: string
  subscription_status: 'active' | 'inactive' | 'expired'
  subscription_plan?: 'monthly' | 'yearly'
  subscription_expires_at?: string
  profiles_created: number
  last_login?: string
}

export default function AdminUsersPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [authed, setAuthed] = useState(false)
  const [users, setUsers] = useState<SupabaseUser[]>([])
  const [query, setQuery] = useState("")

  useEffect(() => {
    const checkAuth = async () => {
      try {
        console.log('🔐 Checking admin access via Supabase...')
        const user = await getCurrentUser()
        console.log('Current user:', user)
        
        if (user && user.email === 'beastbrowser2@beastbrowser.com') {
          console.log('✅ Admin access granted')
          setAuthed(true)
          await loadUsers()
        } else {
          console.log('❌ Admin access denied, redirecting...')
          router.push('/admin')
        }
      } catch (error) {
        console.error('❌ Auth check error:', error)
        router.push('/admin')
      }
      setLoading(false)
    }

    checkAuth()
  }, [router])

  const loadUsers = async () => {
    try {
      console.log('🔄 Loading users via API...')
      
      const response = await fetch('/api/admin/users-simple', {
        method: 'GET',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      })
      const data = await response.json()
      
      console.log('API Response:', data)
      
      if (data.success) {
        console.log('✅ Users loaded successfully:', data.count)
        setUsers(data.users || [])
        
        if (data.synced) {
          console.log('🔄 Users were synced from Auth to database')
        }
      } else {
        console.error('❌ Error loading users:', data.error)
        setUsers([])
        alert('Error loading users: ' + data.error)
      }
    } catch (error) {
      console.error('❌ Error loading users:', error)
      setUsers([])
      alert('Failed to load users. Check console for details.')
    }
  }

  const filtered = useMemo(() => {
    if (!query) return users
    const q = query.toLowerCase()
    return users.filter(u =>
      u.email.toLowerCase().includes(q) ||
      u.id.toLowerCase().includes(q)
    )
  }, [users, query])

  const updateUserSubscription = async (userId: string, status: 'active' | 'inactive' | 'expired', plan?: 'monthly' | 'yearly') => {
    try {
      console.log('Updating user subscription:', { userId, status, plan })
      
      const response = await fetch('/api/admin/update-user', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          status,
          plan
        })
      })

      const data = await response.json()

      if (data.success) {
        console.log('User subscription updated successfully')
        console.log('Updated user data:', data.user)
        alert('User subscription updated successfully!')
        
        // Force reload users to get fresh data
        setTimeout(async () => {
          console.log('Force refreshing users after update...')
          await loadUsers()
          
          // Double check - reload again after 1 second
          setTimeout(async () => {
            console.log('Double-checking user data...')
            await loadUsers()
          }, 1000)
        }, 500)
      } else {
        console.error('Error updating user subscription:', data.error)
        alert(`Failed to update user subscription: ${data.error}`)
      }
    } catch (error) {
      console.error('Error updating user subscription:', error)
      alert('Failed to update user subscription. Please try again.')
    }
  }

  const deleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      return
    }

    try {
      console.log('Deleting user:', userId)
      
      const response = await fetch(`/api/admin/delete-user?userId=${userId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        console.log('User deleted successfully')
        alert('User deleted successfully!')
        await loadUsers() // Reload users
      } else {
        console.error('Error deleting user:', data.error)
        alert(`Failed to delete user: ${data.error}`)
      }
    } catch (error) {
      console.error('Error deleting user:', error)
      alert('Failed to delete user. Please try again.')
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-700'
      case 'expired':
        return 'bg-red-100 text-red-700'
      case 'inactive':
      default:
        return 'bg-gray-100 text-gray-600'
    }
  }

  const getPlanColor = (plan?: string) => {
    switch (plan) {
      case 'monthly':
        return 'bg-blue-100 text-blue-700'
      case 'yearly':
        return 'bg-purple-100 text-purple-700'
      default:
        return 'bg-gray-100 text-gray-600'
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!authed) return null

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-orange via-red-500 to-primary-red rounded-xl flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold">Users ({users.length})</div>
              <div className="text-xs text-gray-500">Manage Supabase users</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/admin" className="text-sm text-gray-600 hover:text-primary-orange">Dashboard</Link>
            <span className="text-gray-300">/</span>
            <span className="text-sm text-gray-800 font-medium">Users</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between mb-6">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search by email or user ID"
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange"
            />
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={async () => {
                try {
                  const response = await fetch('/api/admin/sync-data', { method: 'POST' })
                  const data = await response.json()
                  if (data.success) {
                    alert(`✅ Sync completed! ${data.results.syncedSubscriptions} subscriptions synced`)
                    loadUsers()
                  } else {
                    alert('❌ Sync failed: ' + data.error)
                  }
                } catch (error) {
                  alert('❌ Sync error: ' + error)
                }
              }}
              className="px-3 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700"
            >
              🔄 Sync Data
            </button>
            
            <button
              onClick={async () => {
                try {
                  const response = await fetch('/api/admin/create-test-data', { method: 'POST' })
                  const data = await response.json()
                  if (data.success) {
                    alert('✅ Test data created successfully!')
                    loadUsers()
                  } else {
                    alert('❌ Failed to create test data: ' + data.error)
                  }
                } catch (error) {
                  alert('❌ Test data error: ' + error)
                }
              }}
              className="px-3 py-2 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700"
            >
              🧪 Test Data
            </button>
            
            <button 
              onClick={loadUsers} 
              className="inline-flex items-center px-3 py-2 bg-primary-orange text-white rounded-lg text-sm hover:opacity-95"
            >
              <Plus className="w-4 h-4 mr-1" /> Refresh
            </button>
            
            <button 
              onClick={async () => {
                console.log('Force refreshing...')
                const response = await fetch('/api/admin/force-refresh')
                const data = await response.json()
                if (data.success) {
                  setUsers(data.users || [])
                  console.log('Force refresh completed:', data.count, 'users')
                  if (data.targetUser) {
                    console.log('Target user found:', data.targetUser)
                  }
                }
              }} 
              className="inline-flex items-center px-3 py-2 bg-red-600 text-white rounded-lg text-sm hover:opacity-95"
            >
              Force Refresh
            </button>
            <div className="text-sm text-gray-500">
              Total: {users.length} users
            </div>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="text-left px-4 py-3">Email</th>
                  <th className="text-left px-4 py-3">Joined</th>
                  <th className="text-left px-4 py-3">Status</th>
                  <th className="text-left px-4 py-3">Plan</th>
                  <th className="text-left px-4 py-3">Expires</th>
                  <th className="text-left px-4 py-3">Profiles</th>
                  <th className="text-right px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-gray-500">
                      {query ? 'No users found matching your search' : 'No users found'}
                    </td>
                  </tr>
                )}
                {filtered.map(user => (
                  <tr key={user.id} className="border-t border-gray-100">
                    <td className="px-4 py-3">
                      <div>
                        <div className="font-medium text-gray-900">{user.email}</div>
                        <div className="text-xs text-gray-500">{user.id.slice(0, 8)}...</div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDate(user.created_at)}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(user.subscription_status)}`}>
                        {user.subscription_status.charAt(0).toUpperCase() + user.subscription_status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 text-xs rounded-full ${getPlanColor(user.subscription_plan)}`}>
                        {user.subscription_plan ? user.subscription_plan.charAt(0).toUpperCase() + user.subscription_plan.slice(1) : 'Free'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-500">
                      {user.subscription_expires_at ? (
                        <div className="flex items-center gap-1">
                          <CreditCard className="w-3 h-3" />
                          {formatDate(user.subscription_expires_at)}
                        </div>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="font-medium">{user.profiles_created}</span>
                    </td>
                    <td className="px-4 py-3 text-right space-x-1">
                      <button
                        onClick={() => updateUserSubscription(user.id, 'active', 'monthly')}
                        className="inline-flex items-center px-2 py-1 text-xs text-blue-700 hover:bg-blue-50 rounded border border-blue-200"
                      >Monthly</button>
                      <button
                        onClick={() => updateUserSubscription(user.id, 'active', 'yearly')}
                        className="inline-flex items-center px-2 py-1 text-xs text-purple-700 hover:bg-purple-50 rounded border border-purple-200"
                      >Yearly</button>
                      <button
                        onClick={() => updateUserSubscription(user.id, 'inactive')}
                        className="inline-flex items-center px-2 py-1 text-xs text-yellow-700 hover:bg-yellow-50 rounded border border-yellow-200"
                      >Disable</button>
                      <button 
                        onClick={() => deleteUser(user.id)} 
                        className="inline-flex items-center px-2 py-1 text-xs text-red-600 hover:bg-red-50 rounded"
                      >
                        <Trash2 className="w-4 h-4 mr-1" /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  )
}