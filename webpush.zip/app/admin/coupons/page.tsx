'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Plus, Edit, Trash2, Tag, X, Check, Copy, Calendar } from 'lucide-react'

interface Coupon {
  id: string
  code: string
  discount_percentage: number
  max_uses: number
  current_uses: number
  expires_at: string
  is_active: boolean
  created_at: string
}

export default function CouponsPage() {
  const [coupons, setCoupons] = useState<Coupon[]>([])
  const [loading, setLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null)
  const [message, setMessage] = useState({ type: '', text: '' })
  const router = useRouter()

  const [formData, setFormData] = useState({
    code: '',
    discount: 10,
    expiryDate: '',
    active: true,
    usageLimit: 100
  })

  useEffect(() => {
    const checkAuth = async () => {
      try {
        console.log('🔐 Checking coupon admin access via Supabase...')
        // Import getCurrentUser from supabase-auth
        const { getCurrentUser } = await import('@/lib/supabase-auth')
        const user = await getCurrentUser()
        
        if (user && user.email === 'beastbrowser2@beastbrowser.com') {
          console.log('✅ Coupon admin access granted')
          setIsAuthenticated(true)
          loadCoupons()
        } else {
          console.log('❌ Coupon admin access denied')
          router.push('/admin')
        }
      } catch (error) {
        console.error('❌ Coupon auth error:', error)
        router.push('/admin')
      }
    }

    checkAuth()
  }, [router])

  const loadCoupons = async () => {
    try {
      setLoading(true)
      console.log('🎫 Loading coupons...')
      
      const response = await fetch('/api/admin/coupons', {
        method: 'GET',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      })
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }
      
      const data = await response.json()
      console.log('📊 Response:', data)
      
      if (data.success) {
        setCoupons(data.coupons || [])
        console.log(`✅ Loaded ${data.count} coupons`)
      } else {
        console.error('❌ API error:', data.error)
        setCoupons([])
      }
    } catch (error) {
      console.error('❌ Load error:', error)
      setCoupons([])
      setMessage({ type: 'error', text: 'Failed to load coupons' })
    } finally {
      setLoading(false)
    }
  }

  const generateCouponCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    let result = ''
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  const saveCoupon = async () => {
    setMessage({ type: '', text: '' })

    if (!formData.code.trim()) {
      setMessage({ type: 'error', text: 'Coupon code is required' })
      return
    }

    if (formData.discount < 1 || formData.discount > 100) {
      setMessage({ type: 'error', text: 'Discount must be between 1% and 100%' })
      return
    }

    if (!formData.expiryDate) {
      setMessage({ type: 'error', text: 'Expiry date is required' })
      return
    }

    try {
      const couponData = {
        code: formData.code.toUpperCase(),
        discount_percentage: formData.discount,
        is_active: formData.active,
        expires_at: new Date(formData.expiryDate).toISOString(),
        max_uses: formData.usageLimit
      }

      const url = '/api/admin/coupons'
      const method = editingCoupon ? 'PUT' : 'POST'
      
      let requestData: any = { ...couponData }
      if (editingCoupon) {
        requestData.id = editingCoupon.id
      }

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData)
      })

      const result = await response.json()

      if (response.ok && !result.error) {
        setMessage({ 
          type: 'success', 
          text: `Coupon ${editingCoupon ? 'updated' : 'created'} successfully!` 
        })
        setShowAddForm(false)
        setEditingCoupon(null)
        setFormData({
          code: '',
          discount: 10,
          expiryDate: '',
          active: true,
          usageLimit: 100
        })
        loadCoupons()
      } else {
        setMessage({ type: 'error', text: result.error || 'Failed to save coupon' })
      }
    } catch (error) {
      console.error('Error saving coupon:', error)
      setMessage({ type: 'error', text: 'Failed to save coupon' })
    }
  }

  const deleteCoupon = async (couponId: string) => {
    if (!confirm('Are you sure you want to delete this coupon?')) return

    try {
      const response = await fetch(`/api/admin/coupons?id=${couponId}`, {
        method: 'DELETE'
      })

      const result = await response.json()

      if (response.ok && result.success) {
        setMessage({ type: 'success', text: 'Coupon deleted successfully!' })
        loadCoupons()
      } else {
        setMessage({ type: 'error', text: result.error || 'Failed to delete coupon' })
      }
    } catch (error) {
      console.error('Error deleting coupon:', error)
      setMessage({ type: 'error', text: 'Failed to delete coupon' })
    }
  }

  const editCoupon = (coupon: Coupon) => {
    setEditingCoupon(coupon)
    setFormData({
      code: coupon.code,
      discount: coupon.discount_percentage,
      expiryDate: coupon.expires_at.split('T')[0],
      active: coupon.is_active,
      usageLimit: coupon.max_uses
    })
    setShowAddForm(true)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setMessage({ type: 'success', text: 'Coupon code copied to clipboard!' })
    setTimeout(() => setMessage({ type: '', text: '' }), 2000)
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2">
              <img src="/Beast_B.png" alt="BeastBrowser" className="w-8 h-8 rounded-lg shadow-md" />
              <span className="text-lg font-bold font-poppins gradient-text">BeastBrowser</span>
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/admin" className="text-sm text-gray-600 hover:text-primary-orange">Dashboard</Link>
            <span className="text-gray-300">/</span>
            <span className="text-sm text-gray-800 font-medium">Coupons</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Coupon Management</h1>
              <p className="text-gray-600">Create and manage discount coupons from Supabase</p>
            </div>
            <button
              onClick={() => {
                setShowAddForm(true)
                setEditingCoupon(null)
                setFormData({
                  code: generateCouponCode(),
                  discount: 10,
                  expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                  active: true,
                  usageLimit: 100
                })
              }}
              className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-primary-orange to-primary-red text-white font-medium rounded-lg hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Coupon
            </button>
          </div>

          {/* Message Display */}
          {message.text && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mb-6 p-4 rounded-lg ${
                message.type === 'success' 
                  ? 'bg-green-50 text-green-700 border border-green-200' 
                  : 'bg-red-50 text-red-700 border border-red-200'
              }`}
            >
              {message.text}
            </motion.div>
          )}

          {/* Add/Edit Form */}
          {showAddForm && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 mb-8"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">
                  {editingCoupon ? 'Edit Coupon' : 'Create New Coupon'}
                </h2>
                <button
                  onClick={() => {
                    setShowAddForm(false)
                    setEditingCoupon(null)
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Coupon Code
                  </label>
                  <div className="flex">
                    <input
                      type="text"
                      value={formData.code}
                      onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange"
                      placeholder="SAVE20"
                    />
                    <button
                      onClick={() => setFormData({ ...formData, code: generateCouponCode() })}
                      className="px-3 py-2 bg-gray-100 border border-l-0 border-gray-300 rounded-r-lg hover:bg-gray-200"
                    >
                      Generate
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Discount Percentage
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={formData.discount}
                    onChange={(e) => setFormData({ ...formData, discount: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Expiry Date
                  </label>
                  <input
                    type="date"
                    value={formData.expiryDate}
                    onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Usage Limit
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formData.usageLimit}
                    onChange={(e) => setFormData({ ...formData, usageLimit: parseInt(e.target.value) || 1 })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-orange focus:border-primary-orange"
                  />
                </div>
              </div>

              <div className="flex items-center mt-6">
                <input
                  type="checkbox"
                  id="active"
                  checked={formData.active}
                  onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                  className="w-4 h-4 text-primary-orange border-gray-300 rounded focus:ring-primary-orange"
                />
                <label htmlFor="active" className="ml-2 text-sm text-gray-700">
                  Active (users can use this coupon)
                </label>
              </div>

              <div className="flex justify-end gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowAddForm(false)
                    setEditingCoupon(null)
                  }}
                  className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={saveCoupon}
                  className="px-4 py-2 bg-gradient-to-r from-primary-orange to-primary-red text-white rounded-lg hover:shadow-lg transition-all"
                >
                  <Check className="w-4 h-4 mr-2 inline" />
                  {editingCoupon ? 'Update' : 'Create'} Coupon
                </button>
              </div>
            </motion.div>
          )}

          {/* Loading State */}
          {loading && (
            <div className="flex items-center justify-center py-12">
              <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin" />
              <span className="ml-3 text-gray-600">Loading coupons...</span>
            </div>
          )}

          {/* Coupons Table */}
          {!loading && (
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-lg">
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead className="bg-gray-50 text-gray-600">
                    <tr>
                      <th className="text-left px-6 py-4">Code</th>
                      <th className="text-left px-6 py-4">Discount</th>
                      <th className="text-left px-6 py-4">Usage</th>
                      <th className="text-left px-6 py-4">Expires</th>
                      <th className="text-left px-6 py-4">Status</th>
                      <th className="text-right px-6 py-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {coupons.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-12 text-center">
                          <div className="text-gray-400">
                            <Tag className="w-12 h-12 mx-auto mb-3 opacity-50" />
                            <h3 className="text-lg font-medium text-gray-600 mb-2">No Coupons Found</h3>
                            <p className="text-sm text-gray-500">
                              Create your first coupon to get started with discount management.
                            </p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      coupons.map((coupon) => (
                        <tr key={coupon.id} className="border-t border-gray-100 hover:bg-gray-50">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <div className="font-mono font-semibold text-gray-900">{coupon.code}</div>
                              <button
                                onClick={() => copyToClipboard(coupon.code)}
                                className="text-gray-400 hover:text-primary-orange"
                                title="Copy code"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-green-600 font-medium">{coupon.discount_percentage}% OFF</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-gray-600">
                              {coupon.current_uses} / {coupon.max_uses}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-1 text-gray-600">
                              <Calendar className="w-4 h-4" />
                              {new Date(coupon.expires_at).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 text-xs rounded-full ${
                              coupon.is_active 
                                ? 'bg-green-100 text-green-700' 
                                : 'bg-red-100 text-red-700'
                            }`}>
                              {coupon.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right space-x-2">
                            <button 
                              onClick={() => editCoupon(coupon)}
                              className="inline-flex items-center px-3 py-1 text-xs text-blue-600 hover:bg-blue-50 rounded border border-blue-200"
                            >
                              <Edit className="w-4 h-4 mr-1" /> Edit
                            </button>
                            <button 
                              onClick={() => deleteCoupon(coupon.id)}
                              className="inline-flex items-center px-3 py-1 text-xs text-red-600 hover:bg-red-50 rounded border border-red-200"
                            >
                              <Trash2 className="w-4 h-4 mr-1" /> Delete
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Refresh Button */}
          <div className="mt-6 flex justify-center">
            <button
              onClick={loadCoupons}
              disabled={loading}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 disabled:opacity-50 transition-all"
            >
              {loading ? 'Loading...' : '🔄 Refresh Coupons'}
            </button>
          </div>
        </motion.div>
      </main>
    </div>
  )
}
