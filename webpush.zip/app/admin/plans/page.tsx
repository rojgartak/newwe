'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { 
  Users, 
  CreditCard,
  Star,
  Briefcase,
  ArrowLeft,
  Activity
} from 'lucide-react'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'
import { checkAdminAccess } from '@/lib/admin-auth'

interface PlanStats {
  freeCount: number
  starterCount: number
  monthlyCount: number
  yearlyCount: number
  totalRevenue: number
}

export default function AdminPlansPage() {
  const { user, loading } = useSupabaseAuth()
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [stats, setStats] = useState<PlanStats>({
    freeCount: 0,
    starterCount: 0,
    monthlyCount: 0,
    yearlyCount: 0,
    totalRevenue: 0
  })

  useEffect(() => {
    if (!loading) {
      if (user) {
        checkUserAccess()
      } else {
        router.push('/admin')
      }
    }
  }, [user, loading, router])

  const checkUserAccess = async () => {
    if (!user) return

    const isAdmin = await checkAdminAccess(user)
    if (isAdmin) {
      setIsAuthenticated(true)
      await loadStats()
    } else {
      router.push('/admin')
    }
  }

  const loadStats = async () => {
    try {
      setIsLoading(true)
      
      // Fetch plan statistics from API
      const response = await fetch('/api/admin/plan-stats')
      if (response.ok) {
        const data = await response.json()
        
        if (data.success) {
          setStats({
            freeCount: data.freeCount || 0,
            starterCount: data.starterCount || 0,
            monthlyCount: data.monthlyCount || 0,
            yearlyCount: data.yearlyCount || 0,
            totalRevenue: data.totalRevenue || 0
          })
        }
      }
    } catch (error) {
      console.error('Error loading plan statistics:', error)
    } finally {
      setIsLoading(false)
    }
  }

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed top-0 left-0 h-screen w-64 bg-gray-900 text-white z-50 overflow-y-auto">
        <div className="p-6 border-b border-white/10">
          <Link href="/" className="flex items-center space-x-3">
            <img src="/Beast_B.png" alt="BeastBrowser" className="w-10 h-10 rounded-xl" />
            <span className="text-xl font-bold gradient-text">BeastBrowser</span>
          </Link>
        </div>
        
        <nav className="p-4">
          <ul className="space-y-2">
            <li>
              <Link
                href="/admin"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                <Activity className="w-5 h-5" />
                <span>Dashboard</span>
              </Link>
            </li>
            <li>
              <Link
                href="/admin/users"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                <Users className="w-5 h-5" />
                <span>Users</span>
              </Link>
            </li>
            <li>
              <Link
                href="/admin/plans"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg bg-white/10 text-white"
              >
                <CreditCard className="w-5 h-5" />
                <span>Plans</span>
              </Link>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Main Content */}
      <div className="ml-64 min-h-screen">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
          <div className="px-8 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link 
                href="/admin"
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Dashboard</span>
              </Link>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Plan Statistics</h1>
          </div>
        </header>

        <main className="p-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Subscription Plans</h2>
                <p className="text-gray-600">Overview of user distribution across plans</p>
              </div>
            </div>

            {/* Plan Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 }}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Free Plan</h3>
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <Star className="w-6 h-6 text-green-600" />
                  </div>
                </div>
                <p className="text-4xl font-bold text-gray-900 mb-2">{stats.freeCount}</p>
                <p className="text-sm text-gray-500">₹0 (7 days trial)</p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Revenue</span>
                    <span className="font-semibold text-green-600">₹0</span>
                  </div>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Starter Plan</h3>
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
                <p className="text-4xl font-bold text-gray-900 mb-2">{stats.starterCount}</p>
                <p className="text-sm text-gray-500">₹266 (24 hours)</p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Revenue</span>
                    <span className="font-semibold text-blue-600">₹{(stats.starterCount * 266).toLocaleString()}</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Monthly Premium</h3>
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <Star className="w-6 h-6 text-green-600" />
                  </div>
                </div>
                <p className="text-4xl font-bold text-gray-900 mb-2">{stats.monthlyCount}</p>
                <p className="text-sm text-gray-500">₹2,665/month subscribers</p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Revenue</span>
                    <span className="font-semibold text-green-600">₹{(stats.monthlyCount * 2665).toLocaleString()}</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Yearly Premium</h3>
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <Briefcase className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
                <p className="text-4xl font-bold text-gray-900 mb-2">{stats.yearlyCount}</p>
                <p className="text-sm text-gray-500">₹22,122/year subscribers</p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Revenue</span>
                    <span className="font-semibold text-purple-600">₹{(stats.yearlyCount * 22122).toLocaleString()}</span>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Total Revenue Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-gradient-to-br from-primary-orange to-primary-red rounded-xl shadow-lg p-8 text-white"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold mb-2 opacity-90">Total Monthly Revenue</h3>
                  <p className="text-5xl font-bold">₹{stats.totalRevenue.toLocaleString()}</p>
                  <p className="text-sm opacity-80 mt-2">
                    From {stats.starterCount + stats.monthlyCount + stats.yearlyCount} paid subscriptions
                  </p>
                  <p className="text-xs opacity-70 mt-1">
                    ({stats.freeCount} free trial users)
                  </p>
                </div>
                <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center">
                  <CreditCard className="w-10 h-10" />
                </div>
              </div>
            </motion.div>

            {/* Plan Details Table */}
            <div className="mt-8 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Plan Details</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Plan Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Price
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Subscribers
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Monthly Revenue
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Features
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                            <Star className="w-5 h-5 text-green-600" />
                          </div>
                          <div className="font-medium text-gray-900">Free 7-Day Plan</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        Free
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {stats.freeCount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                        ₹0
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        10 profiles/day for 7 days
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                            <Users className="w-5 h-5 text-blue-600" />
                          </div>
                          <div className="font-medium text-gray-900">Starter Plan</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ₹266
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {stats.starterCount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-blue-600">
                        ₹{(stats.starterCount * 266).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        24-hour trial access
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                            <Star className="w-5 h-5 text-green-600" />
                          </div>
                          <div className="font-medium text-gray-900">Monthly Premium</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ₹2,665/month
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {stats.monthlyCount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                        ₹{(stats.monthlyCount * 2665).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        Unlimited profiles, Advanced features
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                            <Briefcase className="w-5 h-5 text-purple-600" />
                          </div>
                          <div className="font-medium text-gray-900">Yearly Premium</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ₹22,122/year
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {stats.yearlyCount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-purple-600">
                        ₹{(stats.yearlyCount * 22122).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        Priority support, Premium features, Best value
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Refresh Button */}
            <div className="mt-8 flex justify-center">
              <button
                onClick={loadStats}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-sm hover:shadow-md"
              >
                🔄 Refresh Statistics
              </button>
            </div>
          </motion.div>
        </main>
      </div>
    </div>
  )
}
