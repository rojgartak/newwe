"use client"

import { Suspense, useEffect, useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Check, ArrowRight, Mail, Shield } from 'lucide-react'
import { apiFetch } from '@/lib/api'

function generateReferralCode(email: string) {
  const base = Math.abs(Array.from(email).reduce((acc, ch) => acc * 31 + ch.charCodeAt(0), 7))
  const stamp = Date.now() % 1_000_000
  return `BB${(base + stamp).toString(36).toUpperCase()}`
}

export default function VerifyPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-white">Loading...</div>}>
      <VerifyClient />
    </Suspense>
  )
}

function VerifyClient() {
  const router = useRouter()
  const params = useSearchParams()
  const email = params.get('email') || ''

  const [code, setCode] = useState('')
  const [error, setError] = useState('')
  const [isVerifying, setIsVerifying] = useState(false)
  const [info, setInfo] = useState('')
  const [name, setName] = useState('')

  useEffect(() => {
    if (!email) {
      router.push('/signup')
      return
    }
    try {
      const pendingRaw = localStorage.getItem(`pendingUser:${email}`)
      if (pendingRaw) {
        const pending = JSON.parse(pendingRaw)
        setName(pending.name || '')
      }
    } catch {}
  }, [email, router])

  const resend = async () => {
    setError('')
    setInfo('')
    if (!email) return
    
    try {
      const response = await apiFetch('/api/send-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, action: 'resend' })
      })
      
      const result = await response.json()
      if (result.ok) {
        setInfo('New verification code sent! Please check your email.')
      } else {
        setError(result.error || 'Failed to resend verification code.')
      }
    } catch (error) {
      setError('Network error. Please try again.')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsVerifying(true)
    setError('')

    try {
      // Verify code using our new API
      const response = await apiFetch('/api/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code })
      })
      
      const result = await response.json()
      if (!result.success) {
        setError(result.error || 'Invalid verification code.')
        setIsVerifying(false)
        return
      }

      // Build or update users list
      const usersRaw = localStorage.getItem('users')
      const users: any[] = usersRaw ? (JSON.parse(usersRaw) ?? []) : []

      // Pull pending user meta
      const pendingRaw = localStorage.getItem(`pendingUser:${email}`)
      const pending = pendingRaw ? JSON.parse(pendingRaw) : { name: name || 'User' }

      const exists = users.find(u => u.email === email)
      let referralCode = exists?.referralCode
      if (!referralCode) referralCode = generateReferralCode(email)

      let userRecord: any
      if (exists) {
        userRecord = { ...exists, name: pending.name || exists.name, referralCode, status: exists.status || 'Active', plan: exists.plan || 'Free' }
        const idx = users.findIndex(u => u.email === email)
        users[idx] = userRecord
      } else {
        userRecord = {
          id: Date.now(),
          name: pending.name || 'User',
          email,
          status: 'Active',
          plan: 'Free',
          joined: new Date().toISOString().split('T')[0],
          referralCode,
        }
        users.unshift(userRecord)
      }
      localStorage.setItem('users', JSON.stringify(users))

      // Attach referral if a referrer is set in session
      try {
        const referrerCode = sessionStorage.getItem('referrer')
        if (referrerCode && referrerCode !== referralCode) {
          const referrer = users.find(u => u.referralCode === referrerCode)
          if (referrer && referrer.email !== email) {
            const referralsRaw = localStorage.getItem('referrals')
            const referrals: any[] = referralsRaw ? (JSON.parse(referralsRaw) ?? []) : []
            referrals.unshift({
              id: Date.now(),
              referrerCode,
              referrerEmail: referrer.email,
              refereeEmail: email,
              date: new Date().toISOString(),
              status: 'Pending',
              plan: null,
              commission: 0,
            })
            localStorage.setItem('referrals', JSON.stringify(referrals))
          }
        }
      } catch {}

      // Send welcome email
      try {
        await apiFetch('/api/welcome-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, name: userRecord.name })
        })
      } catch (error) {
        // Don't fail signup if welcome email fails
        console.warn('Failed to send welcome email:', error)
      }

      // Clean pending data
      localStorage.removeItem(`pendingUser:${email}`)
      sessionStorage.removeItem('referrer')

      // Authenticate
      localStorage.setItem('isAuthenticated', 'true')
      localStorage.setItem('userRole', 'user')
      localStorage.setItem('userEmail', email)
      localStorage.setItem('userName', userRecord.name || 'User')

      router.push('/dashboard')
    } catch (err) {
      setError('Verification failed. Please try again.')
    } finally {
      setIsVerifying(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full space-y-8 relative z-10">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="glass-card p-8">
          <div className="text-center mb-4">
            <Link href="/" className="inline-flex items-center space-x-2">
              <img src="/Beast_B.png" alt="BeastBrowser" className="w-12 h-12 rounded-xl shadow-lg" />
              <span className="text-xl font-bold font-poppins gradient-text">BeastBrowser</span>
            </Link>
            <h2 className="mt-6 text-3xl font-bold text-white">Verify your email</h2>
            <p className="mt-2 text-sm text-gray-300">We've sent a 6-digit code to <span className="font-semibold">{email}</span></p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm mb-4">{error}</div>
          )}
          {info && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm mb-4">{info}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="sr-only">Verification code</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Shield className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="Enter 6-digit code"
                  className="appearance-none relative block w-full px-12 py-3 border border-white/20 placeholder-gray-400 text-white bg-white/10 backdrop-blur-md rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-orange focus:border-primary-orange focus:z-10 sm:text-sm transition-all duration-300"
                  required
                />
              </div>
            </div>


            <button
              type="submit"
              disabled={isVerifying}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-r from-primary-orange to-primary-red hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-orange transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed hover:-translate-y-1"
            >
              {isVerifying ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  Verify & Continue
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
                </>
              )}
            </button>

            <div className="flex items-center justify-between text-sm text-gray-400">
              <button type="button" onClick={resend} className="text-primary-orange hover:text-primary-red">Resend code</button>
              <Link href="/signup" className="hover:text-white">Change email</Link>
            </div>
          </form>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.6 }} className="glass-card p-6">
          <h3 className="text-lg font-semibold text-white mb-3 text-center">Why verification?</h3>
          <div className="space-y-2 text-sm text-gray-300">
            <div className="flex items-center space-x-2"><Check className="w-4 h-4 text-green-500" /><span>Protect your account</span></div>
            <div className="flex items-center space-x-2"><Check className="w-4 h-4 text-green-500" /><span>Enable referral tracking</span></div>
            <div className="flex items-center space-x-2"><Check className="w-4 h-4 text-green-500" /><span>Secure plan upgrades</span></div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
