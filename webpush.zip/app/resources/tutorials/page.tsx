'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { Play, BookOpen, User, Shield } from 'lucide-react'
import Link from 'next/link'

export default function TutorialsPage() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50">
        <div className="container-custom text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
            <Play className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold font-poppins mb-6">
            <span className="gradient-text">Tutorials</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Step-by-step tutorials and video guides to master BeastBrowser features.
          </p>
        </div>
      </section>

      {/* Tutorial Categories */}
      <section className="py-20">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Tutorial <span className="gradient-text">Categories</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive video guides for every aspect of Beast Browser
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <BookOpen className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Getting Started</h3>
              <p className="text-gray-600 mb-6">Learn the basics of Beast Browser setup and navigation</p>
              <div className="text-sm text-gray-500">5 Videos • 25 min total</div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <User className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Profile Management</h3>
              <p className="text-gray-600 mb-6">Master creating and managing multiple browser profiles</p>
              <div className="text-sm text-gray-500">8 Videos • 45 min total</div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Anti-Detection</h3>
              <p className="text-gray-600 mb-6">Advanced privacy and security features explained</p>
              <div className="text-sm text-gray-500">6 Videos • 35 min total</div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-900 text-white text-center">
        <div className="container-custom">
          <h2 className="text-3xl font-bold mb-6">Learn with Video Tutorials</h2>
          <Link href="/pricing" className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300">
            Get Started
          </Link>
        </div>
      </section>
      <Footer />
    </main>
  )
}