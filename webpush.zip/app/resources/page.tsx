'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Book, Play, Code, FileText, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function ResourcesPage() {
  const resources = [
    {
      icon: Book,
      title: 'Documentation',
      description: 'Complete guides and technical documentation for BeastBrowser features.',
      link: '/resources/docs'
    },
    {
      icon: Play,
      title: 'Tutorials',
      description: 'Step-by-step tutorials and video guides to get you started.',
      link: '/resources/tutorials'
    },
    {
      icon: Code,
      title: 'API Reference',
      description: 'Comprehensive API documentation for developers and integrations.',
      link: '/resources/api'
    },
    {
      icon: FileText,
      title: 'Blog',
      description: 'Latest news, updates, and insights about anti-detection technology.',
      link: '/resources/blog'
    }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Resources</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Everything you need to master BeastBrowser and anti-detection technology.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {resources.map((resource, index) => (
              <motion.div
                key={resource.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border p-8 hover:shadow-2xl transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <resource.icon className="w-6 h-6 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4">{resource.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{resource.description}</p>
                
                <Link 
                  href={resource.link}
                  className="inline-flex items-center space-x-2 text-primary-orange font-medium hover:text-primary-red transition-colors duration-200 group"
                >
                  <span>Explore</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}