'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { Code, Key, Database, Zap } from 'lucide-react'
import Link from 'next/link'

export default function APIPage() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50">
        <div className="container-custom text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
            <Code className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold font-poppins mb-6">
            <span className="gradient-text">API Reference</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive API documentation for developers building integrations with Beast Browser.
          </p>
        </div>
      </section>
      
      <section className="py-20">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              API <span className="gradient-text">Features</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Powerful APIs to integrate Beast Browser into your applications
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Key className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Authentication API</h3>
              <p className="text-gray-600 mb-6">Secure API key authentication with rate limiting and access controls</p>
              <div className="text-sm text-gray-500">REST API • JSON responses</div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Database className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Profile Management</h3>
              <p className="text-gray-600 mb-6">Create, update, and manage browser profiles programmatically</p>
              <div className="text-sm text-gray-500">CRUD operations • Bulk actions</div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Automation API</h3>
              <p className="text-gray-600 mb-6">Automate browser actions and workflows with our powerful API</p>
              <div className="text-sm text-gray-500">WebDriver compatible • Selenium support</div>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-20 bg-gray-900 text-white text-center">
        <div className="container-custom">
          <h2 className="text-3xl font-bold mb-6">Developer-Friendly APIs</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Get API access with your Beast Browser subscription and start building powerful integrations.
          </p>
          <Link href="/pricing" className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300">
            Get API Access
          </Link>
        </div>
      </section>
      <Footer />
    </main>
  )
}