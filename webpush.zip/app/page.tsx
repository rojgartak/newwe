import Navigation from '@/components/Navigation'
import Hero from '@/components/Hero'
import ClientLogos from '@/components/ClientLogos'
import HowItWorks from '@/components/HowItWorks'
import IndustryTiles from '@/components/IndustryTiles'
import Testimonials from '@/components/Testimonials'
import ComparisonBlock from '@/components/ComparisonBlock'
import PricingSection from '@/components/PricingSection'
import Footer from '@/components/Footer'

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <Hero />
      <ClientLogos />
      <HowItWorks />
      <IndustryTiles />
      <Testimonials />
      <ComparisonBlock />
      <PricingSection />
      <Footer />
    </main>
  )
}
