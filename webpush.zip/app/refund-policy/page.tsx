'use client'

import { motion } from 'framer-motion'
import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { FileText, RefreshCw, Clock, Shield, CheckCircle, AlertTriangle } from 'lucide-react'

const RefundPolicy = () => {
  const policySections = [
    {
      icon: RefreshCw,
      title: 'Cancellation Policy',
      content: `ROHIT SRIVASTAV believes in helping its customers as far as possible, and has therefore a liberal cancellation policy. Under this policy:

• Cancellations will be considered only if the request is made immediately after placing the order. However, the cancellation request may not be entertained if the orders have been communicated to the vendors/merchants and they have initiated the process of shipping them.

• ROHIT SRIVASTAV does not accept cancellation requests for perishable items like flowers, eatables etc. However, refund/replacement can be made if the customer establishes that the quality of product delivered is not good.`
    },
    {
      icon: Clock,
      title: 'Reporting Issues',
      content: `• In case of receipt of damaged or defective items please report the same to our Customer Service team. The request will, however, be entertained once the merchant has checked and determined the same at his own end. This should be reported within 7 Days days of receipt of the products.

• In case you feel that the product received is not as shown on the site or as per your expectations, you must bring it to the notice of our customer service within 7 Days days of receiving the product. The Customer Service Team after looking into your complaint will take an appropriate decision.`
    },
    {
      icon: Shield,
      title: 'Warranty Products',
      content: `• In case of complaints regarding products that come with a warranty from manufacturers, please refer the issue to them.`
    },
    {
      icon: CheckCircle,
      title: 'Refund Processing',
      content: `• In case of any Refunds approved by the ROHIT SRIVASTAV, it'll take 1-2 Days days for the refund to be processed to the end customer.`
    }
  ]

  const contactInfo = {
    name: 'ROHIT SRIVASTAV',
    email: 'rohitsriva1204@gmail.com',
    phone: '8177062435',
    address: 'Bhawarnath, Azamgarh, Uttar Pradesh, PIN: 276001'
  }

  return (
    <div className="min-h-screen bg-white">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-20 pb-16 bg-gradient-to-br from-gray-50 to-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <div className="inline-flex items-center px-4 py-2 bg-blue-100 rounded-full text-blue-800 text-sm font-medium mb-6">
              <FileText className="w-4 h-4 mr-2" />
              Refund & Cancellation Policy
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Cancellation & Refund Policy
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Our policies regarding order cancellations, returns, and refunds for Beast Browser services.
            </p>
            <div className="text-sm text-gray-500">
              Last updated: October 8, 2024 • Effective date: October 8, 2024
            </div>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto space-y-8">
            {policySections.map((section, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-xl border border-gray-100 p-8 shadow-sm"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center flex-shrink-0">
                    <section.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">{section.title}</h3>
                    <div className="text-gray-700 leading-relaxed whitespace-pre-line">
                      {section.content}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Contact Information */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="bg-gradient-to-r from-primary-orange/5 to-primary-red/5 rounded-2xl p-8 border border-primary-orange/20"
            >
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Information</h2>
                <p className="text-gray-700">
                  For any questions or concerns regarding cancellations or refunds, please contact us:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary-orange/10 rounded-lg flex items-center justify-center">
                      <span className="text-primary-orange font-semibold">👤</span>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Merchant Legal Entity</p>
                      <p className="text-gray-700">{contactInfo.name}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary-orange/10 rounded-lg flex items-center justify-center">
                      <span className="text-primary-orange font-semibold">📧</span>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Email</p>
                      <p className="text-gray-700">{contactInfo.email}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary-orange/10 rounded-lg flex items-center justify-center">
                      <span className="text-primary-orange font-semibold">📞</span>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Phone</p>
                      <p className="text-gray-700">{contactInfo.phone}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary-orange/10 rounded-lg flex items-center justify-center">
                      <span className="text-primary-orange font-semibold">📍</span>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Address</p>
                      <p className="text-gray-700">{contactInfo.address}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Important Notice */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="bg-amber-50 border border-amber-200 rounded-2xl p-6"
            >
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-amber-900 mb-2">Important Notice</h3>
                  <p className="text-amber-800 text-sm leading-relaxed">
                    Please note that all refund requests are subject to verification and approval by our team.
                    Processing times may vary depending on the payment method and bank policies.
                    We reserve the right to modify this policy at any time without prior notice.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}

export default RefundPolicy
