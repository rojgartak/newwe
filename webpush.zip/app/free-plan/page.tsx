'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { 
  Star, 
  Check, 
  Clock, 
  Calendar,
  Shield,
  Zap,
  ArrowRight,
  Loader2
} from 'lucide-react'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'

export default function FreePlanPage() {
  const { user, loading } = useSupabaseAuth()
  const router = useRouter()
  const [activating, setActivating] = useState(false)
  const [planStatus, setPlanStatus] = useState<any>(null)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    if (!loading && !user) {
      router.push('/signup?redirect=/free-plan')
    }
    if (user) {
      checkPlanStatus()
    }
  }, [user, loading, router])

  const checkPlanStatus = async () => {
    if (!user) return;
    
    try {
      const response = await fetch(`/api/free-plan/status?userId=${user.id}`)
      const data = await response.json()
      
      if (data.success) {
        setPlanStatus(data)
      }
    } catch (error) {
      console.error('Error checking plan status:', error)
    }
  }

  const activateFreePlan = async () => {
    if (!user) {
      router.push('/signup?redirect=/free-plan')
      return
    }

    setActivating(true)
    setError('')

    try {
      const response = await fetch('/api/free-plan/activate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        setSuccess(true)
        setPlanStatus(data)
        
        // Redirect to dashboard after 2 seconds
        setTimeout(() => {
          router.push('/dashboard')
        }, 2000)
      } else {
        setError(data.error || 'Failed to activate free plan')
      }
    } catch (error: any) {
      setError(error.message || 'Failed to activate free plan')
    } finally {
      setActivating(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary-orange" />
      </div>
    )
  }

  // If user already has active plan
  if (planStatus?.hasPlan && planStatus?.plan?.isActive) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 py-20">
        <div className="container mx-auto px-4 max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-xl p-8 text-center"
          >
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-green-600" />
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Free Plan Already Active! 🎉
            </h1>
            
            <p className="text-gray-600 mb-6">
              Your 7-day free trial is currently active
            </p>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-6">
              <div className="grid grid-cols-2 gap-4 text-left">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Days Remaining</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {planStatus.plan.daysRemaining} days
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Today's Profiles</p>
                  <p className="text-2xl font-bold text-green-600">
                    {planStatus.daily.remainingProfiles}/10
                  </p>
                </div>
              </div>
            </div>

            <Link
              href="/dashboard"
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-primary-orange to-primary-red text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg transition-all"
            >
              <span>Go to Dashboard</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Star className="w-4 h-4" />
              <span>100% Free - No Credit Card Required</span>
            </div>
            
            <h1 className="text-5xl font-bold text-gray-900 mb-4">
              Start Your <span className="gradient-text">Free 7-Day Trial</span>
            </h1>
            
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience BeastBrowser with full features. Create up to 10 profiles per day for 7 days!
            </p>
          </div>

          {/* Main Card */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-8 text-white text-center">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-10 h-10" />
              </div>
              <h2 className="text-3xl font-bold mb-2">Free 7-Day Plan</h2>
              <p className="text-lg opacity-90">Perfect for trying out BeastBrowser</p>
            </div>

            <div className="p-8">
              {/* Features */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-6">What's Included:</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">10 Profiles Per Day</p>
                      <p className="text-sm text-gray-600">Create up to 10 browser profiles daily</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">7 Days Access</p>
                      <p className="text-sm text-gray-600">Full access for one week</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Daily Reset</p>
                      <p className="text-sm text-gray-600">Limit resets at midnight</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">No Credit Card</p>
                      <p className="text-sm text-gray-600">Start immediately, no payment info needed</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Fingerprint Protection</p>
                      <p className="text-sm text-gray-600">Basic anti-detection features</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Proxy Support</p>
                      <p className="text-sm text-gray-600">Configure custom proxies</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Info Boxes */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
                  <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-blue-900">Instant Activation</p>
                  <p className="text-xs text-blue-700">Start using immediately</p>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
                  <Calendar className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-green-900">7 Full Days</p>
                  <p className="text-xs text-green-700">Complete trial period</p>
                </div>

                <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 text-center">
                  <Shield className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-purple-900">No Auto-Charge</p>
                  <p className="text-xs text-purple-700">Upgrade when ready</p>
                </div>
              </div>

              {/* Error Message */}
              {error && (
                <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 text-red-700">
                  {error}
                </div>
              )}

              {/* Success Message */}
              {success && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mb-6 bg-green-50 border border-green-200 rounded-xl p-4 text-green-700 text-center"
                >
                  <Check className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <p className="font-semibold">Free Plan Activated Successfully!</p>
                  <p className="text-sm">Redirecting to dashboard...</p>
                </motion.div>
              )}

              {/* Activate Button */}
              <button
                onClick={activateFreePlan}
                disabled={activating || success}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 px-8 rounded-xl font-semibold text-lg hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {activating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Activating...</span>
                  </>
                ) : success ? (
                  <>
                    <Check className="w-5 h-5" />
                    <span>Activated!</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    <span>Activate Free 7-Day Plan</span>
                  </>
                )}
              </button>

              <p className="text-center text-sm text-gray-500 mt-4">
                By activating, you agree to our{' '}
                <Link href="/terms" className="text-primary-orange hover:underline">
                  Terms of Service
                </Link>
              </p>
            </div>
          </div>

          {/* FAQ or Additional Info */}
          <div className="mt-8 text-center">
            <p className="text-gray-600 mb-4">
              Need more features? Check out our{' '}
              <Link href="/pricing" className="text-primary-orange font-semibold hover:underline">
                Premium Plans
              </Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
