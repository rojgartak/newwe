import { Metadata } from 'next'
import FeaturesClient from './FeaturesClient'

export const metadata: Metadata = {
  title: 'Features - BeastBrowser | Advanced Anti-Detection Technology',
  description: "Discover BeastBrowser's powerful features including anti-detection technology, fingerprint protection, multi-profile management, and browser automation.",
  keywords: 'anti-detection browser, fingerprint protection, browser automation, multi-profile management, proxy integration, session management'
}

export default function FeaturesPage() {
  return <FeaturesClient />
}
