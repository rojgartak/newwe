"use client"

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Shield, Zap, Users, Lock, Globe, Settings, ArrowRight, Check } from 'lucide-react'
import Link from 'next/link'

const FeatureCard = ({ icon: Icon, title, description, link, features }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6 }}
    className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300 group"
  >
    <div className="flex items-center space-x-4 mb-6">
      <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="text-xl font-bold text-gray-900">{title}</h3>
    </div>
    
    <p className="text-gray-600 mb-6 leading-relaxed">{description}</p>
    
    <div className="space-y-3 mb-6">
      {features.map((feature: string, index: number) => (
        <div key={index} className="flex items-start space-x-2">
          <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
          <span className="text-sm text-gray-600">{feature}</span>
        </div>
      ))}
    </div>
    
    <Link 
      href={link}
      className="inline-flex items-center space-x-2 text-primary-orange font-medium hover:text-primary-red transition-colors duration-200 group"
    >
      <span>Learn More</span>
      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
    </Link>
  </motion.div>
)

export default function FeaturesClient() {
  const features = [
    {
      icon: Shield,
      title: 'Anti-Detection Technology',
      description: 'Stay completely undetectable with our advanced fingerprint masking and browser environment spoofing.',
      link: '/features/anti-detection',
      features: [
        'Advanced fingerprint masking',
        'Browser environment spoofing',
        'Real device emulation',
        'Hardware profile randomization'
      ]
    },
    {
      icon: Lock,
      title: 'Fingerprint Protection',
      description: 'Protect your digital identity with sophisticated fingerprinting protection techniques.',
      link: '/features/fingerprint-protection',
      features: [
        'Canvas fingerprint protection',
        'WebGL fingerprint masking',
        'Audio context spoofing',
        'Timezone and locale protection'
      ]
    },
    {
      icon: Users,
      title: 'Multi-Profile Management',
      description: 'Create and manage unlimited browser profiles with unique identities and settings.',
      link: '/features/multi-profile',
      features: [
        'Unlimited browser profiles',
        'Unique identity per profile',
        'Bulk profile management',
        'Profile templates and cloning'
      ]
    },
    {
      icon: Settings,
      title: 'Browser Automation',
      description: 'Automate your browsing tasks with built-in scripting and automation tools.',
      link: '/features/automation',
      features: [
        'Built-in automation scripts',
        'Custom script support',
        'Task scheduling',
        'Action recording and playback'
      ]
    },
    {
      icon: Globe,
      title: 'Proxy Integration',
      description: 'Seamlessly integrate with various proxy providers for enhanced anonymity.',
      link: '/features/proxy-integration',
      features: [
        'Multiple proxy protocol support',
        'Automatic proxy rotation',
        'Proxy health monitoring',
        'Geographic location selection'
      ]
    },
    {
      icon: Zap,
      title: 'Session Management',
      description: 'Advanced session handling with persistence and synchronization across devices.',
      link: '/features/session-management',
      features: [
        'Persistent session storage',
        'Cross-device synchronization',
        'Session backup and restore',
        'Automatic session cleanup'
      ]
    }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Powerful Features</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Discover the advanced technologies that make BeastBrowser the ultimate anti-detection solution for professionals and businesses.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature) => (
              <FeatureCard key={feature.title} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container-custom text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Experience These Features?
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Start your free trial today and discover how BeastBrowser can revolutionize your browsing experience.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/pricing"
                className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
              >
                Start Free Trial
              </Link>
              <Link 
                href="/contact"
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-gray-900 transition-all duration-300"
              >
                Contact Sales
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
