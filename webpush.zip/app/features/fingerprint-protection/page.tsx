'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Lock, Shield, Eye, Palette, ArrowRight, Check } from 'lucide-react'
import Link from 'next/link'

export default function FingerprintProtectionPage() {
  const protectionFeatures = [
    {
      icon: Palette,
      title: 'Canvas Fingerprint Protection',
      description: 'Advanced canvas spoofing that generates unique canvas signatures for every session.',
      details: ['2D context manipulation', 'Text rendering spoofing', 'Image data randomization', 'Pixel-level modifications']
    },
    {
      icon: Eye,
      title: 'WebGL Fingerprint Masking',
      description: 'Comprehensive WebGL protection to prevent graphics-based tracking and identification.',
      details: ['Renderer string masking', 'Extension enumeration control', 'Parameter value spoofing', 'Shader compilation masking']
    },
    {
      icon: Shield,
      title: 'Audio Context Spoofing',
      description: 'Protect against audio fingerprinting by masking audio context and device signatures.',
      details: ['Audio fingerprint randomization', 'Device signature masking', 'Sample rate spoofing', 'Audio processing protection']
    },
    {
      icon: Lock,
      title: 'Timezone & Locale Protection',
      description: 'Comprehensive protection against location and language-based tracking.',
      details: ['Timezone offset masking', 'Language preference spoofing', 'Date format randomization', 'Currency symbol protection']
    }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
              <Lock className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Fingerprint Protection</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Protect your digital identity with our advanced fingerprint protection technology. 
              Prevent tracking and maintain complete anonymity across all browsing sessions.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {protectionFeatures.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300"
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-6 leading-relaxed">{feature.description}</p>
                
                <div className="space-y-3">
                  {feature.details.map((detail, detailIndex) => (
                    <div key={detailIndex} className="flex items-start space-x-2">
                      <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{detail}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container-custom text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Protect Your Digital Identity
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Experience the most comprehensive fingerprint protection available. Start your free trial today.
            </p>
            <Link 
              href="/pricing"
              className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
            >
              Start Free Trial
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}