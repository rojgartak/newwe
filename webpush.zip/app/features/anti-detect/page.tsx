'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Shield, Eye, Monitor, Cpu, Globe, Lock, Fingerprint, Bot, ArrowRight, Check, Star, Zap, Users } from 'lucide-react'
import Link from 'next/link'

export default function AntiDetectPage() {
  const antiDetectFeatures = [
    {
      icon: Fingerprint,
      title: 'Advanced Fingerprint Masking',
      description: 'Mask and randomize your browser fingerprint to avoid detection by even the most sophisticated tracking systems and anti-bot technologies.',
      details: [
        'Canvas fingerprint spoofing with dynamic noise injection',
        'WebGL renderer masking with realistic GPU signatures',
        'Font enumeration protection and randomization',
        'Hardware concurrency spoofing for multi-core simulation',
        'Screen resolution and color depth manipulation',
        'Timezone and language preference randomization'
      ]
    },
    {
      icon: Monitor,
      title: 'Browser Environment Spoofing',
      description: 'Create authentic browser environments that perfectly mimic real user behavior patterns and device characteristics.',
      details: [
        'User-Agent string randomization with real browser signatures',
        'Navigator properties spoofing (platform, language, plugins)',
        'Viewport dimensions and pixel ratio manipulation',
        'Browser history depth simulation',
        'Cookie and storage capacity spoofing',
        'Connection speed and network type emulation'
      ]
    },
    {
      icon: Eye,
      title: 'Real Device Emulation',
      description: 'Emulate real devices with authentic hardware signatures, sensor data, and behavioral patterns that pass advanced detection tests.',
      details: [
        'Mobile and desktop device simulation',
        'Touch event and gesture emulation',
        'Accelerometer and gyroscope sensor spoofing',
        'Battery status and charging state masking',
        'Memory and storage capacity simulation',
        'Camera and microphone device enumeration'
      ]
    },
    {
      icon: Cpu,
      title: 'Hardware Profile Randomization',
      description: 'Generate realistic hardware profiles that match real-world device configurations and pass hardware-based detection systems.',
      details: [
        'CPU core count and architecture variation',
        'RAM size and memory timing randomization',
        'Graphics card model and driver spoofing',
        'Audio device and codec emulation',
        'Network adapter MAC address masking',
        'USB device enumeration control'
      ]
    },
    {
      icon: Globe,
      title: 'Network-Level Protection',
      description: 'Advanced network fingerprinting protection that masks your true connection characteristics and location data.',
      details: [
        'WebRTC IP leak prevention and masking',
        'DNS query fingerprinting protection',
        'HTTP header normalization and randomization',
        'SSL/TLS fingerprint masking',
        'Connection timing pattern obfuscation',
        'Geolocation API spoofing with realistic data'
      ]
    },
    {
      icon: Bot,
      title: 'Anti-Bot System Bypass',
      description: 'Specialized technology designed to bypass sophisticated anti-bot systems used by major websites and platforms.',
      details: [
        'Captcha challenge behavior simulation',
        'Mouse movement pattern humanization',
        'Keyboard typing rhythm randomization',
        'Page interaction timing optimization',
        'JavaScript execution environment masking',
        'Automated behavior detection bypass'
      ]
    }
  ]

  const detectionMethods = [
    {
      method: 'Canvas Fingerprinting',
      protection: 'Dynamic noise injection with realistic rendering variations',
      effectiveness: '99.9%'
    },
    {
      method: 'WebGL Fingerprinting',
      protection: 'GPU signature spoofing with authentic hardware emulation',
      effectiveness: '99.8%'
    },
    {
      method: 'Audio Fingerprinting',
      protection: 'Audio context manipulation with device-specific variations',
      effectiveness: '99.7%'
    },
    {
      method: 'Font Enumeration',
      protection: 'Font list randomization with OS-appropriate selections',
      effectiveness: '99.9%'
    },
    {
      method: 'WebRTC Leaks',
      protection: 'Complete IP masking with realistic ICE candidate generation',
      effectiveness: '100%'
    },
    {
      method: 'Browser Plugin Detection',
      protection: 'Plugin enumeration control with authentic configurations',
      effectiveness: '99.6%'
    },
    {
      method: 'Timing Attacks',
      protection: 'Performance timing normalization and jitter injection',
      effectiveness: '99.5%'
    },
    {
      method: 'Behavioral Analysis',
      protection: 'Human-like interaction patterns with ML-based optimization',
      effectiveness: '99.4%'
    }
  ]

  const industryStats = [
    { metric: 'Websites Bypassed', value: '50,000+', description: 'Successfully tested platforms' },
    { metric: 'Detection Rate', value: '<0.1%', description: 'Industry-leading stealth' },
    { metric: 'Fingerprint Variations', value: '10M+', description: 'Unique combinations available' },
    { metric: 'Update Frequency', value: 'Daily', description: 'Continuous protection updates' }
  ]

  const useCases = [
    {
      icon: Users,
      title: 'Social Media Management',
      description: 'Manage multiple social accounts without triggering platform anti-bot systems',
      benefits: ['Account safety', 'Unlimited scaling', 'No shadow bans']
    },
    {
      icon: Globe,
      title: 'Web Scraping & Data Collection',
      description: 'Collect data from websites with sophisticated anti-scraping protection',
      benefits: ['Bypass rate limits', 'Avoid IP blocks', 'Continuous operation']
    },
    {
      icon: Star,
      title: 'Market Research & Testing',
      description: 'Conduct competitive analysis and market research without detection',
      benefits: ['Unbiased results', 'Geographic flexibility', 'Competitor monitoring']
    }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-24 h-24 bg-gradient-to-br from-primary-orange to-primary-red rounded-3xl flex items-center justify-center mx-auto mb-8">
              <Shield className="w-12 h-12 text-white" />
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold font-poppins mb-6">
              <span className="gradient-text">Anti-Detect Technology</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed mb-8">
              Stay completely invisible online with our cutting-edge anti-detection technology. 
              Our advanced algorithms and machine learning models ensure you remain undetectable by even the most sophisticated tracking systems, anti-bot technologies, and fingerprinting methods.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link 
                href="/download"
                className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg hover:scale-105 transition-all duration-300 flex items-center space-x-3"
              >
                <Zap className="w-5 h-5" />
                <span>Try Anti-Detect Now</span>
              </Link>
              <Link 
                href="/pricing"
                className="px-8 py-4 border-2 border-primary-orange text-primary-orange font-semibold rounded-xl hover:bg-primary-orange hover:text-white transition-all duration-300"
              >
                View Pricing Plans
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Industry Stats */}
      <section className="py-20 bg-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Industry-Leading <span className="gradient-text">Performance</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Trusted by professionals worldwide with proven results across thousands of platforms
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {industryStats.map((stat, index) => (
              <motion.div
                key={stat.metric}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Star className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">{stat.value}</h3>
                <p className="text-lg font-semibold text-gray-700 mb-1">{stat.metric}</p>
                <p className="text-gray-600 text-sm">{stat.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Anti-Detection Features */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Advanced <span className="gradient-text">Protection Technologies</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive anti-detection capabilities that protect you from all known fingerprinting and tracking methods
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {antiDetectFeatures.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300"
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-14 h-14 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center">
                    <feature.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-6 leading-relaxed">{feature.description}</p>
                
                <div className="space-y-3">
                  {feature.details.map((detail, detailIndex) => (
                    <div key={detailIndex} className="flex items-start space-x-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{detail}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Detection Methods Protection */}
      <section className="py-20 bg-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Protection Against <span className="gradient-text">All Detection Methods</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive protection against every known fingerprinting and detection technique used by websites and anti-bot systems
            </p>
          </motion.div>

          <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-primary-orange to-primary-red text-white">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold">Detection Method</th>
                    <th className="px-6 py-4 text-left font-semibold">Our Protection</th>
                    <th className="px-6 py-4 text-center font-semibold">Effectiveness</th>
                  </tr>
                </thead>
                <tbody>
                  {detectionMethods.map((method, index) => (
                    <motion.tr
                      key={method.method}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.05, duration: 0.5 }}
                      className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}
                    >
                      <td className="px-6 py-4 font-medium text-gray-900">{method.method}</td>
                      <td className="px-6 py-4 text-gray-600">{method.protection}</td>
                      <td className="px-6 py-4 text-center">
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                          {method.effectiveness}
                        </span>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Perfect for <span className="gradient-text">Professional Use Cases</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Trusted by professionals across industries for mission-critical applications
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {useCases.map((useCase, index) => (
              <motion.div
                key={useCase.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border p-8 text-center hover:shadow-2xl transition-all duration-300"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <useCase.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{useCase.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{useCase.description}</p>
                
                <div className="space-y-2">
                  {useCase.benefits.map((benefit, benefitIndex) => (
                    <div key={benefitIndex} className="flex items-center justify-center space-x-2">
                      <Check className="w-4 h-4 text-green-500" />
                      <span className="text-sm text-gray-600">{benefit}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Deep Dive */}
      <section className="py-20 bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
                How Our <span className="gradient-text">Technology Works</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                BeastBrowser employs a multi-layered approach to anti-detection, combining advanced browser modification techniques with machine learning algorithms to create the most sophisticated stealth browsing solution available.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-sm font-bold">1</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Real-Time Fingerprint Generation</h3>
                    <p className="text-gray-600 text-sm">Our AI algorithms generate unique, realistic browser fingerprints that match real user patterns and device configurations.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-sm font-bold">2</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Behavioral Pattern Simulation</h3>
                    <p className="text-gray-600 text-sm">Advanced mouse movement, keyboard timing, and interaction patterns that mimic natural human behavior.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-sm font-bold">3</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Continuous Adaptation</h3>
                    <p className="text-gray-600 text-sm">Machine learning models continuously adapt to new detection methods and update protection strategies in real-time.</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 shadow-2xl border"
            >
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Protection Layers</h3>
              
              <div className="space-y-4">
                <div className="bg-white rounded-xl p-4 shadow border">
                  <div className="flex items-center space-x-3 mb-2">
                    <Lock className="w-5 h-5 text-primary-orange" />
                    <span className="font-semibold text-gray-900">Browser Core Modification</span>
                  </div>
                  <p className="text-sm text-gray-600">Deep integration with browser engine for authentic behavior</p>
                </div>
                
                <div className="bg-white rounded-xl p-4 shadow border">
                  <div className="flex items-center space-x-3 mb-2">
                    <Shield className="w-5 h-5 text-primary-orange" />
                    <span className="font-semibold text-gray-900">JavaScript Environment</span>
                  </div>
                  <p className="text-sm text-gray-600">Complete isolation and protection of JavaScript APIs</p>
                </div>
                
                <div className="bg-white rounded-xl p-4 shadow border">
                  <div className="flex items-center space-x-3 mb-2">
                    <Globe className="w-5 h-5 text-primary-orange" />
                    <span className="font-semibold text-gray-900">Network Stack Protection</span>
                  </div>
                  <p className="text-sm text-gray-600">Advanced network-level fingerprinting prevention</p>
                </div>
                
                <div className="bg-white rounded-xl p-4 shadow border">
                  <div className="flex items-center space-x-3 mb-2">
                    <Cpu className="w-5 h-5 text-primary-orange" />
                    <span className="font-semibold text-gray-900">Hardware Emulation</span>
                  </div>
                  <p className="text-sm text-gray-600">Realistic hardware signature generation and masking</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/10 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready to Go <span className="gradient-text">Undetected</span>?
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
              Join thousands of professionals who rely on BeastBrowser's anti-detection technology 
              for their most critical browsing needs. Experience true online invisibility today.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-12">
              <Link 
                href="/download"
                className="px-10 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 text-lg"
              >
                Start Free Trial
              </Link>
              <Link 
                href="/contact"
                className="px-10 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-gray-900 transition-all duration-300 text-lg"
              >
                Contact Sales
              </Link>
            </div>
            
            <div className="text-sm text-gray-400">
              ✓ 7-day free trial  ✓ No credit card required  ✓ Full feature access
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}