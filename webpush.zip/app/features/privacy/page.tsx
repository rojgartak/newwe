'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Shield, Lock, Eye, UserX, ArrowRight, Check } from 'lucide-react'
import Link from 'next/link'

export default function PrivacyPage() {
  const privacyFeatures = [
    {
      icon: Shield,
      title: 'Complete Anonymity',
      description: 'Browse the internet without revealing your true identity. Every session is completely isolated and anonymous.',
      details: [
        'Real IP address masking',
        'DNS leak protection',
        'WebRTC leak prevention',
        'Geographic location spoofing'
      ]
    },
    {
      icon: Lock,
      title: 'Data Encryption',
      description: 'All your browsing data is encrypted using military-grade encryption standards.',
      details: [
        'AES-256 encryption',
        'Secure data storage',
        'Encrypted profile backups',
        'Zero-knowledge architecture'
      ]
    },
    {
      icon: Eye,
      title: 'Tracking Prevention',
      description: 'Advanced protection against all forms of online tracking and surveillance.',
      details: [
        'Cookie tracking protection',
        'Pixel tracking blockers',
        'Social media tracking shields',
        'Cross-site tracking prevention'
      ]
    },
    {
      icon: UserX,
      title: 'Identity Protection',
      description: 'Prevent identity linking and profiling across different websites and services.',
      details: [
        'Behavioral pattern masking',
        'Typing pattern protection',
        'Mouse movement randomization',
        'Browsing habit obfuscation'
      ]
    }
  ]

  const privacyStats = [
    { metric: 'Data Encryption', value: 'AES-256', description: 'Military-grade security' },
    { metric: 'Tracking Prevention', value: '99.9%', description: 'Success rate' },
    { metric: 'Identity Protection', value: '100%', description: 'Complete isolation' },
    { metric: 'Privacy Score', value: 'A+', description: 'Top rating' }
  ]

  const threats = [
    { name: 'Browser Fingerprinting', protection: 'Advanced spoofing technology' },
    { name: 'Cookie Tracking', protection: 'Isolated cookie containers' },
    { name: 'IP Address Tracking', protection: 'Built-in proxy integration' },
    { name: 'WebRTC Leaks', protection: 'Automatic leak prevention' },
    { name: 'Canvas Fingerprinting', protection: 'Dynamic canvas spoofing' },
    { name: 'Font Enumeration', protection: 'Font fingerprint protection' }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
              <Shield className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Privacy Protection</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Your privacy is our priority. Browse the internet with complete anonymity and protection against all forms of online tracking and surveillance.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Privacy Stats */}
      <section className="py-20">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {privacyStats.map((stat, index) => (
              <motion.div
                key={stat.metric}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</h3>
                <p className="text-lg font-semibold text-gray-700 mb-1">{stat.metric}</p>
                <p className="text-gray-600 text-sm">{stat.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Privacy Features */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Multi-Layer <span className="gradient-text">Protection</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive privacy protection at every level of your browsing experience
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {privacyFeatures.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300"
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-6 leading-relaxed">{feature.description}</p>
                
                <div className="space-y-3">
                  {feature.details.map((detail, detailIndex) => (
                    <div key={detailIndex} className="flex items-start space-x-2">
                      <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{detail}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Threat Protection */}
      <section className="py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Protection Against <span className="gradient-text">All Threats</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We protect you from the most sophisticated privacy threats and tracking methods
            </p>
          </motion.div>

          <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-primary-orange to-primary-red text-white">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold">Privacy Threat</th>
                    <th className="px-6 py-4 text-left font-semibold">Our Protection</th>
                    <th className="px-6 py-4 text-center font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {threats.map((threat, index) => (
                    <motion.tr
                      key={threat.name}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1, duration: 0.5 }}
                      className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}
                    >
                      <td className="px-6 py-4 font-medium text-gray-900">{threat.name}</td>
                      <td className="px-6 py-4 text-gray-600">{threat.protection}</td>
                      <td className="px-6 py-4 text-center">
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                          ✓ Protected
                        </span>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Privacy Benefits */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
                Why Privacy <span className="gradient-text">Matters</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                In today's digital world, your privacy is constantly under threat. From corporate data harvesting 
                to government surveillance, your online activities are being monitored and tracked.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Check className="w-5 h-5 text-green-500 mt-1" />
                  <span className="text-gray-700">Protect personal and business information</span>
                </div>
                <div className="flex items-start space-x-3">
                  <Check className="w-5 h-5 text-green-500 mt-1" />
                  <span className="text-gray-700">Prevent targeted advertising and profiling</span>
                </div>
                <div className="flex items-start space-x-3">
                  <Check className="w-5 h-5 text-green-500 mt-1" />
                  <span className="text-gray-700">Avoid price discrimination and manipulation</span>
                </div>
                <div className="flex items-start space-x-3">
                  <Check className="w-5 h-5 text-green-500 mt-1" />
                  <span className="text-gray-700">Maintain freedom of expression and research</span>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="grid grid-cols-1 gap-6"
            >
              <div className="bg-white rounded-2xl shadow-lg border p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Personal Privacy</h3>
                <p className="text-gray-600">Keep your personal information, browsing habits, and online identity completely private.</p>
              </div>
              
              <div className="bg-white rounded-2xl shadow-lg border p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mb-4">
                  <Lock className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Business Security</h3>
                <p className="text-gray-600">Protect sensitive business data and competitive intelligence from corporate espionage.</p>
              </div>
              
              <div className="bg-white rounded-2xl shadow-lg border p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mb-4">
                  <UserX className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Anonymous Research</h3>
                <p className="text-gray-600">Conduct research and gather information without revealing your identity or intentions.</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container-custom text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Take Control of Your Privacy
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Don't let others profit from your data. Start browsing with complete privacy and anonymity today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/download"
                className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
              >
                Protect My Privacy
              </Link>
              <Link 
                href="/features"
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-gray-900 transition-all duration-300 inline-flex items-center space-x-2"
              >
                <span>View All Features</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}