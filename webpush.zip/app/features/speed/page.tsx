'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Zap, Clock, Gauge, TrendingUp, ArrowRight, Check } from 'lucide-react'
import Link from 'next/link'

export default function SpeedPage() {
  const speedFeatures = [
    {
      icon: Zap,
      title: 'Optimized Engine Performance',
      description: 'Our custom-built browser engine delivers 40% faster page loading compared to traditional browsers.',
      details: [
        'Multi-threaded processing',
        'Advanced memory management',
        'Optimized resource allocation',
        'Smart caching algorithms'
      ]
    },
    {
      icon: Clock,
      title: 'Instant Profile Switching',
      description: 'Switch between browser profiles in under 2 seconds without any performance degradation.',
      details: [
        'Profile pre-loading technology',
        'Seamless context switching',
        'Zero downtime transitions',
        'Background profile preparation'
      ]
    },
    {
      icon: Gauge,
      title: 'Accelerated Browsing',
      description: 'Experience blazing-fast browsing with our proprietary acceleration technology.',
      details: [
        'DNS prefetching',
        'Connection pooling',
        'Bandwidth optimization',
        'Predictive loading'
      ]
    },
    {
      icon: TrendingUp,
      title: 'Performance Monitoring',
      description: 'Real-time performance metrics and optimization suggestions for maximum efficiency.',
      details: [
        'Live performance dashboard',
        'Resource usage tracking',
        'Optimization recommendations',
        'Performance history reports'
      ]
    }
  ]

  const benchmarks = [
    { metric: 'Page Load Time', traditional: '3.2s', beast: '1.8s', improvement: '44%' },
    { metric: 'Profile Switch Time', traditional: '8.5s', beast: '1.9s', improvement: '78%' },
    { metric: 'Memory Usage', traditional: '1.2GB', beast: '0.7GB', improvement: '42%' },
    { metric: 'CPU Usage', traditional: '25%', beast: '15%', improvement: '40%' }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
              <Zap className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Lightning Fast Speed</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Experience unmatched performance with BeastBrowser's lightning-fast speed. Our optimized engine delivers superior browsing performance while maintaining complete anonymity and security.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Performance Comparison */}
      <section className="py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Performance <span className="gradient-text">Benchmarks</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              See how BeastBrowser outperforms traditional browsers in key metrics
            </p>
          </motion.div>

          <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-primary-orange to-primary-red text-white">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold">Metric</th>
                    <th className="px-6 py-4 text-center font-semibold">Traditional Browser</th>
                    <th className="px-6 py-4 text-center font-semibold">BeastBrowser</th>
                    <th className="px-6 py-4 text-center font-semibold">Improvement</th>
                  </tr>
                </thead>
                <tbody>
                  {benchmarks.map((benchmark, index) => (
                    <motion.tr
                      key={benchmark.metric}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1, duration: 0.5 }}
                      className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}
                    >
                      <td className="px-6 py-4 font-medium text-gray-900">{benchmark.metric}</td>
                      <td className="px-6 py-4 text-center text-gray-600">{benchmark.traditional}</td>
                      <td className="px-6 py-4 text-center font-semibold text-green-600">{benchmark.beast}</td>
                      <td className="px-6 py-4 text-center">
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                          +{benchmark.improvement}
                        </span>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Speed Features */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {speedFeatures.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300"
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-6 leading-relaxed">{feature.description}</p>
                
                <div className="space-y-3">
                  {feature.details.map((detail, detailIndex) => (
                    <div key={detailIndex} className="flex items-start space-x-2">
                      <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{detail}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container-custom text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Experience Lightning Speed Today
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Don't compromise on speed. Get the fastest anti-detection browser available.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/download"
                className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
              >
                Download Now
              </Link>
              <Link 
                href="/features"
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-gray-900 transition-all duration-300 inline-flex items-center space-x-2"
              >
                <span>View All Features</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}