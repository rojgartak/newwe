'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Tv, Shield, Eye, Smartphone, Monitor, ArrowRight, Check } from 'lucide-react'
import Link from 'next/link'

export default function TvAgentPage() {
  const tvFeatures = [
    {
      icon: Tv,
      title: 'Smart TV Emulation',
      description: 'Perfect emulation of popular Smart TV browsers including Samsung, LG, Sony, and Android TV.',
      details: [
        'Samsung Tizen TV browser',
        'LG webOS TV browser',
        'Sony Bravia TV browser',
        'Android TV browser',
        'Fire TV Silk browser'
      ]
    },
    {
      icon: Shield,
      title: 'Authentic TV Fingerprints',
      description: 'Generate authentic TV device fingerprints that bypass even the most sophisticated detection systems.',
      details: [
        'Real TV hardware signatures',
        'Authentic screen resolutions',
        'TV-specific user agents',
        'Device capability matching'
      ]
    },
    {
      icon: Eye,
      title: 'Streaming Platform Compatibility',
      description: 'Optimized for major streaming platforms and video services.',
      details: [
        'Netflix compatibility',
        'YouTube TV optimization',
        'Hulu TV interface',
        'Amazon Prime Video',
        'Disney+ smart TV mode'
      ]
    },
    {
      icon: Monitor,
      title: 'Large Screen Interface',
      description: 'Automatically adapt web interfaces for TV-optimized viewing experience.',
      details: [
        'TV-friendly navigation',
        'Large button interfaces',
        'Remote control simulation',
        '10-foot UI optimization'
      ]
    }
  ]

  const supportedTVs = [
    { brand: 'Samsung', models: 'Tizen OS 2.4+', icon: '📺' },
    { brand: 'LG', models: 'webOS 3.0+', icon: '📺' },
    { brand: 'Sony', models: 'Android TV 7.0+', icon: '📺' },
    { brand: 'TCL', models: 'Roku TV OS', icon: '📺' },
    { brand: 'Hisense', models: 'VIDAA U4+', icon: '📺' },
    { brand: 'Amazon', models: 'Fire TV OS', icon: '📺' }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary-red/5 rounded-full blur-3xl" />
        </div>
        
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
              <Tv className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">TV User Agent</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Emulate Smart TV browsers with authentic device fingerprints. Access TV-exclusive content and streaming services with our advanced TV user agent technology.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Supported TV Platforms */}
      <section className="py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Supported <span className="gradient-text">TV Platforms</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Compatible with all major Smart TV platforms and operating systems
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {supportedTVs.map((tv, index) => (
              <motion.div
                key={tv.brand}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 text-center hover:shadow-2xl transition-all duration-300"
              >
                <div className="text-4xl mb-4">{tv.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{tv.brand}</h3>
                <p className="text-gray-600 text-sm">{tv.models}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TV Features */}
      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {tvFeatures.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300"
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-xl flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-6 leading-relaxed">{feature.description}</p>
                
                <div className="space-y-3">
                  {feature.details.map((detail, detailIndex) => (
                    <div key={detailIndex} className="flex items-start space-x-2">
                      <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{detail}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Perfect for <span className="gradient-text">TV Applications</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl">🎬</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Streaming Services</h3>
              <p className="text-gray-600">Access TV-exclusive content and streaming platforms with authentic TV browser signatures.</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl">📊</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Market Research</h3>
              <p className="text-gray-600">Research TV-specific content and advertising without revealing your true device identity.</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8 text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl">🧪</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">App Testing</h3>
              <p className="text-gray-600">Test web applications and streaming apps on different TV platforms and screen sizes.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container-custom text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Access the TV Internet
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Experience the web from a Smart TV perspective with our authentic TV user agent technology.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/download"
                className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
              >
                Try TV Mode
              </Link>
              <Link 
                href="/features"
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-gray-900 transition-all duration-300 inline-flex items-center space-x-2"
              >
                <span>View All Features</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}