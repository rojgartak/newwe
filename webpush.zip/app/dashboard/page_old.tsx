'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Monitor, Globe, Shield, Clock, Copy as CopyIcon, Plus, Eye, Edit3, Trash2, Download, User, Zap, LogOut } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { getCurrentUser, signOut } from '@/lib/supabase-auth'
import PaymentModal from '@/components/PaymentModal'

const UserDashboard = () => {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [userEmail, setUserEmail] = useState('')
  const [userName, setUserName] = useState('')
  const [referralCode, setReferralCode] = useState('')
  const [subscriptionStatus, setSubscriptionStatus] = useState<any>(null)
  const [dailyProfilesCount, setDailyProfilesCount] = useState(0)
  const [profiles, setProfiles] = useState<any[]>([])
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userProfileLimits, setUserProfileLimits] = useState<any>(null)
  const [plan, setPlan] = useState('Monthly Premium')
  const [referralStats, setReferralStats] = useState({ total: 0, converted: 0, commission: 0 })
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState('Monthly Premium')
  const router = useRouter()

  useEffect(() => {
    const initUser = async () => {
      try {
        const currentUser = await getCurrentUser()
        if (currentUser) {
          setUser(currentUser)
          setIsAuthenticated(true)
          setUserEmail(currentUser.email || '')
          setUserName(currentUser.email || 'User')
          setLoading(false)
        } else {
          router.push('/login')
        }
      } catch (error) {
        console.error('Error getting current user:', error)
        router.push('/login')
      }
    }

    initUser()
  }, [router])

  const initUserProfileLimits = async () => {
    if (!user) return

    try {
      // For now, just set default values
      setUserProfileLimits({
        plan: 'monthly',
        totalProfilesCreated: 0,
        dailyProfiles: {}
      })
      setPlan('Monthly Premium')
    } catch (error) {
      console.error('Error initializing user profile limits:', error)
    }
  }

  const handleLogout = async () => {
    try {
      await signOut()
      router.push('/login')
    } catch (error) {
      console.error('Error signing out:', error)
    }
  }

  const handleCreateProfile = async () => {
    if (!user || !userProfileLimits) {
      alert('Please log in to create a profile!')
      return
    }

    try {
      // Update profile count (simplified for now)
      setUserProfileLimits((prev: any) => ({
        ...prev,
        totalProfilesCreated: (prev?.totalProfilesCreated || 0) + 1
      }))

      // Update daily count
      const today = new Date().toISOString().split('T')[0]
      setDailyProfilesCount(prev => prev + 1)

      // Actual profile creation logic would go here
      console.log('Creating profile...')
      alert('Profile created successfully!')
    } catch (error) {
      console.error('Error creating profile:', error)
      alert('Error creating profile. Please try again.')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  type Profile = {
    id: number
    name: string
    browser: string
    proxy: string
    sessions: number
    status: string
    lastUsed: string
  }

  const profilesData: Profile[] = []

  // Update stats to show actual data
  const stats = [
    {
      name: 'Active Profiles',
      value: userProfileLimits ? userProfileLimits.totalProfilesCreated.toString() : '0',
      icon: Monitor,
      color: 'from-blue-500 to-blue-600'
    },
    {
      name: 'Sessions Today',
      value: dailyProfilesCount.toString(),
      icon: Globe,
      color: 'from-green-500 to-green-600'
    },
    {
      name: 'Security Level',
      value: '100%',
      icon: Shield,
      color: 'from-primary-orange to-primary-red'
    },
    {
      name: 'Total Hours',
      value: '0h',
      icon: Clock,
      color: 'from-purple-500 to-purple-600'
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3">
              <img src="/Beast_B.png" alt="BeastBrowser" className="w-10 h-10 rounded-xl shadow-lg" />
              <div className="flex flex-col">
                <span className="text-lg font-bold font-poppins gradient-text">BeastBrowser</span>
                <span className="text-xs text-gray-500 font-medium -mt-1">Dashboard</span>
              </div>
            </Link>

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-primary-orange to-primary-red rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-sm">
                    {userName.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">{userName}</p>
                  <p className="text-xs text-gray-500">{userEmail}</p>
                </div>
              </div>

              <button 
                onClick={handleLogout}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 px-3 py-2 rounded-lg transition-colors"
              >
                <LogOut className="w-5 h-5" />
                <span className="text-sm font-medium">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {userName}! 👋
          </h1>
          <p className="text-gray-600">
            Manage your browser profiles and stay anonymous online.
          </p>
          
          {/* Plan Status */}
          <div className="mt-4 p-4 bg-gradient-to-r from-primary-orange/10 to-primary-red/10 rounded-lg border border-primary-orange/20">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                {false ? (
                  <>
                    <p className="font-medium text-gray-900">
                      Free Plan
                      {userProfileLimits.trialStart && (
                        <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-orange/10 text-primary-orange">
                          Trial Active
                        </span>
                      )}
                    </p>
                    {userProfileLimits.trialStart && (
                      <p className="text-sm text-gray-600 mt-1">
                        {(() => {
                          const trialStart = userProfileLimits.trialStart.toDate()
                          const daysPassed = Math.floor((new Date().getTime() - trialStart.getTime()) / (1000 * 60 * 60 * 24))
                          const daysLeft = Math.max(0, 7 - daysPassed)
                          return `Trial: ${daysLeft} days left | Today: ${dailyProfilesCount}/7 profiles`
                        })()}
                      </p>
                    )}
                  </>
                ) : (
                  <>
                    <p className="font-medium text-gray-900">
                      Premium ({userProfileLimits?.plan === 'monthly' ? 'Monthly' : 'Yearly'})
                      <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Active
                      </span>
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      Valid till: {userProfileLimits?.premiumExpiry?.toDate().toLocaleDateString()}
                    </p>
                  </>
                )}
              </div>
              {true && (
                <button
                  onClick={() => router.push('/pricing')}
                  className="mt-3 md:mt-0 px-4 py-2 bg-gradient-to-r from-primary-orange to-primary-red text-white text-sm font-medium rounded-lg hover:shadow-lg transition-all duration-300"
                >
                  Manage Plan
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-lg flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Referral Program */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="bg-white rounded-xl shadow-sm border border-gray-100 mb-8"
        >
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-semibold text-gray-900">Referral Program</h2>
            <p className="text-gray-600 mt-1 text-sm">Share your link and earn 30% commission when your referrals upgrade any plan.</p>
          </div>
          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <label className="text-sm text-gray-600">Your referral link</label>
              <div className="mt-2 flex">
                <input
                  readOnly
                  value={`${typeof window !== 'undefined' ? window.location.origin : ''}/signup?ref=${referralCode || '...'} `}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg text-sm"
                />
                <button
                  onClick={() => {
                    const link = `${window.location.origin}/signup?ref=${referralCode}`
                    navigator.clipboard.writeText(link)
                  }}
                  className="px-4 bg-gradient-to-r from-primary-orange to-primary-red text-white rounded-r-lg text-sm flex items-center gap-2"
                >
                  <CopyIcon className="w-4 h-4" /> Copy
                </button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-gray-50 rounded-lg p-3 text-center">
                <div className="text-xs text-gray-500">Total</div>
                <div className="text-lg font-semibold">{referralStats.total}</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 text-center">
                <div className="text-xs text-gray-500">Converted</div>
                <div className="text-lg font-semibold">{referralStats.converted}</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 text-center">
                <div className="text-xs text-gray-500">Commission</div>
                <div className="text-lg font-semibold">$ {referralStats.commission.toFixed(2)}</div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Browser Profiles */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="bg-white rounded-xl shadow-sm border border-gray-100 mb-8"
        >
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">Browser Profiles</h2>
              <button 
                onClick={handleCreateProfile}
                className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-primary-orange to-primary-red text-white font-medium rounded-lg hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Profile
              </button>
            </div>
          </div>

          <div className="divide-y divide-gray-100">
            {profiles.length === 0 ? (
              <div className="p-12 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Monitor className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No profiles yet</h3>
                <p className="text-gray-500 mb-6">Create your first browser profile to get started</p>
                <button 
                  onClick={handleCreateProfile}
                  className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-primary-orange to-primary-red text-white font-medium rounded-lg hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Profile
                </button>
              </div>
            ) : (
              profiles.map((profile) => (
                <div key={profile.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-primary-orange/10 to-primary-red/10 rounded-lg flex items-center justify-center">
                        <Monitor className="w-6 h-6 text-primary-orange" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-gray-900">{profile.name}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                          <span>Browser: {profile.browser}</span>
                          <span>Proxy: {profile.proxy}</span>
                          <span>Sessions: {profile.sessions}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                          profile.status === 'Active' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {profile.status}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">Last used: {profile.lastUsed}</p>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button className="p-2 text-gray-400 hover:text-primary-orange hover:bg-gray-100 rounded-lg transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {/* Download Browser */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-lg flex items-center justify-center">
                <Download className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Download Browser</h3>
                <p className="text-sm text-gray-600 mb-4">Get the latest version of BeastBrowser</p>
                <Link 
                  href="/download" 
                  className="inline-flex items-center text-primary-orange hover:text-primary-red font-medium text-sm transition-colors"
                >
                  Download Now →
                </Link>
              </div>
            </div>
          </div>

          {/* Account Settings */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Account Settings</h3>
                <p className="text-sm text-gray-600 mb-4">Manage your account and preferences</p>
                <Link 
                  href="/settings" 
                  className="inline-flex items-center text-primary-orange hover:text-primary-red font-medium text-sm transition-colors"
                >
                  Open Settings →
                </Link>
              </div>
            </div>
          </div>

          {/* Security Center */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Security Center</h3>
                <p className="text-sm text-gray-600 mb-4">Check your security status</p>
                <Link 
                  href="/security" 
                  className="inline-flex items-center text-primary-orange hover:text-primary-red font-medium text-sm transition-colors"
                >
                  View Security →
                </Link>
              </div>
            </div>
          </div>

          {/* Upgrade Plan */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary-orange to-primary-red rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Upgrade Plan</h3>
                <p className="text-sm text-gray-600 mb-4">Current plan: <span className="font-semibold">{plan}</span></p>
                <div className="flex items-center gap-2">
                        <button
                          onClick={() => setShowPaymentModal(true)}
                          className="px-3 py-2 bg-gradient-to-r from-primary-orange to-primary-red text-white rounded-lg text-sm"
                        >Upgrade Now</button>
                        <Link
                          href="/pricing"
                          className="px-3 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50"
                        >View Plans</Link>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
      
      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        planName={selectedPlan}
        userEmail={userEmail}
        userName={userName}
        onSuccess={() => {
          // Refresh page data
          window.location.reload()
        }}
      />
    </div>
  )
}

export default UserDashboard