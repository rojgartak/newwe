'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Monitor, 
  Shield, 
  User, 
  LogOut, 
  Plus,
  Edit3,
  Trash2,
  Eye,
  Copy as CopyIcon,
  CreditCard,
  Calendar,
  CheckCircle,
  XCircle,
  Globe,
  Clock
} from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'
import { signOut, checkSubscriptionStatus } from '@/lib/supabase-auth'
import { checkAdminAccess } from '@/lib/admin-auth'

function generateReferralCode(email: string) {
  const base = Math.abs(Array.from(email).reduce((acc, ch) => acc * 31 + ch.charCodeAt(0), 7))
  const stamp = Date.now() % 1_000_000
  return `BB${(base + stamp).toString(36).toUpperCase()}`
}

const UserDashboard = () => {
  const { user, loading } = useSupabaseAuth()
  const [userEmail, setUserEmail] = useState('')
  const [userName, setUserName] = useState('')
  const [referralCode, setReferralCode] = useState('')
  const [subscriptionStatus, setSubscriptionStatus] = useState<any>(null)
  const [dailyProfilesCount, setDailyProfilesCount] = useState(0)
  const [profiles, setProfiles] = useState<any[]>([])
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login')
    } else if (user) {
      checkUserAccess()
    }
  }, [user, loading, router])

  const checkUserAccess = async () => {
    if (!user) return

    // Check if user is admin
    const isAdmin = await checkAdminAccess(user)
    if (isAdmin) {
      // Redirect admin users to admin panel
      router.push('/admin')
      return
    }

    // Initialize regular user data
    initializeUserData()
  }

  const initializeUserData = async () => {
    if (!user) return

    setUserEmail(user.email || '')
    setUserName(user.email?.split('@')[0] || 'User')
    
    // Generate referral code
    const refCode = generateReferralCode(user.email || '')
    setReferralCode(refCode)
    
    // Check subscription status
    try {
      const status = await checkSubscriptionStatus(user.id)
      setSubscriptionStatus(status)
    } catch (error) {
      console.error('Error checking subscription:', error)
    }
    
    // No local profiles needed for simplified dashboard
  }

  const loadProfiles = () => {}

  const handleLogout = async () => {
    try {
      await signOut()
      router.push('/login')
    } catch (error) {
      console.error('Error signing out:', error)
    }
  }

  const handleCreateProfile = (type: 'single' | 'bulk') => {
    if (!user) return

    // Check subscription
    if (!subscriptionStatus?.hasActiveSubscription) {
      alert('Please upgrade your plan to create profiles!')
      router.push('/pricing')
      return
    }

    // Unlimited profiles

    // Create profile
    const newProfile = {
      id: Date.now().toString(),
      name: `Profile ${dailyProfilesCount + 1}`,
      created: new Date().toISOString(),
      fingerprint: generateFingerprint(),
      proxy: null
    }

    const today = new Date().toISOString().split('T')[0]
    const profilesKey = `profiles_${user.id}_${today}`
    const updatedProfiles = [...profiles, newProfile]
    
    localStorage.setItem(profilesKey, JSON.stringify(updatedProfiles))
    setProfiles(updatedProfiles)
    setDailyProfilesCount(updatedProfiles.length)
  }

  const generateFingerprint = () => {
    return {
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      screen: { width: 1920, height: 1080 },
      timezone: 'Asia/Kolkata',
      language: 'en-US'
    }
  }

  const copyReferralLink = () => {
    const referralLink = `${window.location.origin}/signup?ref=${referralCode}`
    navigator.clipboard.writeText(referralLink)
    alert('Referral link copied to clipboard!')
  }

  const deleteProfile = (profileId: string) => {
    if (!user) return
    
    const updatedProfiles = profiles.filter(p => p.id !== profileId)
    const today = new Date().toISOString().split('T')[0]
    const profilesKey = `profiles_${user.id}_${today}`
    
    localStorage.setItem(profilesKey, JSON.stringify(updatedProfiles))
    setProfiles(updatedProfiles)
    setDailyProfilesCount(updatedProfiles.length)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const dailyLimit = Infinity

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <img src="/Beast_B.png" alt="BeastBrowser" className="w-8 h-8 rounded-lg" />
            <span className="text-xl font-bold gradient-text">BeastBrowser</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <span className="text-gray-300">Welcome, {userName}</span>
            <button
              onClick={handleLogout}
              className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Subscription Status */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card p-6"
            >
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
                <CreditCard className="w-5 h-5 mr-2" />
                Subscription Status
              </h2>
              <div className="flex items-center space-x-4">
                {subscriptionStatus?.hasActiveSubscription ? (
                  <>
                    <CheckCircle className="w-6 h-6 text-green-500" />
                    <div>
                      <p className="text-green-400 font-medium">
                        ✅ Active - {subscriptionStatus.subscriptionPlan?.charAt(0).toUpperCase() + subscriptionStatus.subscriptionPlan?.slice(1)} Plan
                      </p>
                      <p className="text-gray-400 text-sm">Profiles: Unlimited</p>
                      {subscriptionStatus.daysRemaining && (
                        <p className={`text-sm font-medium ${
                          subscriptionStatus.daysRemaining <= 7 
                            ? 'text-yellow-400' 
                            : 'text-green-400'
                        }`}>
                          {subscriptionStatus.daysRemaining <= 7 
                            ? `⚠️ Expires in ${subscriptionStatus.daysRemaining} days` 
                            : `📅 ${subscriptionStatus.daysRemaining} days remaining`
                          }
                        </p>
                      )}
                    </div>
                  </>
                ) : (
                  <>
                    <XCircle className="w-6 h-6 text-red-500" />
                    <div>
                      <p className="text-red-400 font-medium">❌ No Active Subscription</p>
                      <p className="text-gray-400 text-sm">Upgrade to create unlimited profiles</p>
                      <p className="text-yellow-400 text-sm">
                        🔒 Premium features locked
                      </p>
                    </div>
                  </>
                )}
              </div>
              <div className="mt-4 flex gap-3">
                {!subscriptionStatus?.hasActiveSubscription ? (
                  <Link
                    href="/pricing"
                    className="bg-gradient-to-r from-primary-orange to-primary-red text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all"
                  >
                    Upgrade Now
                  </Link>
                ) : (
                  <>
                    <Link
                      href="/download"
                      className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all flex items-center gap-2"
                    >
                      <Monitor className="w-4 h-4" />
                      Download BeastBrowser
                    </Link>
                    <div className="text-sm text-gray-400 flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      Expires: {subscriptionStatus.expiresAt ? new Date(subscriptionStatus.expiresAt).toLocaleDateString() : 'N/A'}
                    </div>
                  </>
                )}
              </div>
            </motion.div>

            {/* BeastBrowser Web App Access */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="glass-card p-6"
            >
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
                <Globe className="w-5 h-5 mr-2" />
                BeastBrowser Web App
              </h2>
              <p className="text-gray-300 mb-4">
                Access BeastBrowser directly in your browser - no download required!
              </p>
              
              {subscriptionStatus?.hasActiveSubscription ? (
                <div className="space-y-3">
                  <a
                    href="/beastbrowser"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-3 rounded-lg text-center font-semibold hover:shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <Globe className="w-5 h-5" />
                    🚀 Launch Web App
                  </a>
                  <p className="text-xs text-gray-400 text-center">
                    Opens in new tab • All features included • No installation needed
                  </p>
                  <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
                    <p className="text-blue-400 text-xs flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      Full BeastBrowser experience in your browser
                    </p>
                  </div>
                </div>
              ) : (
                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                  <p className="text-yellow-400 text-sm flex items-center gap-2 mb-3">
                    <XCircle className="w-4 h-4" />
                    Premium subscription required to access web app
                  </p>
                  <Link
                    href="/pricing"
                    className="block w-full bg-gradient-to-r from-primary-orange to-primary-red text-white px-6 py-2 rounded-lg text-center font-semibold hover:shadow-lg transition-all"
                  >
                    Upgrade to Access Web App
                  </Link>
                </div>
              )}
            </motion.div>

            {/* Download Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card p-6"
            >
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
                <Monitor className="w-5 h-5 mr-2" />
                Download BeastBrowser
              </h2>
              <p className="text-gray-300 mb-4">Get the latest version of BeastBrowser for your OS.</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Link href="/download#windows" className="bg-white/5 hover:bg-white/10 text-white px-6 py-3 rounded-lg text-center transition-all">Windows</Link>
                <Link href="/download#mac" className="bg-white/5 hover:bg-white/10 text-white px-6 py-3 rounded-lg text-center transition-all">macOS</Link>
                <Link href="/download#linux" className="bg-white/5 hover:bg-white/10 text-white px-6 py-3 rounded-lg text-center transition-all">Linux</Link>
              </div>
            </motion.div>

            {/* Account Details */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-6"
            >
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
                <User className="w-5 h-5 mr-2" />
                Account Details
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-gray-400">Email</p>
                  <p className="text-white font-medium">{userEmail}</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-gray-400">Plan</p>
                  <p className="text-white font-medium">{subscriptionStatus?.hasActiveSubscription ? `${subscriptionStatus.subscriptionPlan} Premium` : 'Free'}</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-gray-400">Subscription</p>
                  <p className="text-white font-medium">{subscriptionStatus?.hasActiveSubscription ? 'Active' : 'Inactive'}</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-gray-400">Expiry</p>
                  <p className="text-white font-medium">{subscriptionStatus?.expiresAt ? new Date(subscriptionStatus.expiresAt).toLocaleDateString() : 'N/A'}</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* User Info */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card p-6"
            >
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                <User className="w-5 h-5 mr-2" />
                Account Info
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-gray-400 text-sm">Email</p>
                  <p className="text-white">{userEmail}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Plan</p>
                  <p className="text-white">
                    {subscriptionStatus?.hasActiveSubscription 
                      ? `${subscriptionStatus.subscriptionPlan} Premium` 
                      : 'Free Trial'
                    }
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Referral Program */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card p-6"
            >
              <h3 className="text-lg font-semibold text-white mb-4">
                Referral Program (30% Commission)
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-gray-400 text-sm mb-2">Your Referral Code</p>
                  <div className="flex items-center space-x-2">
                    <code className="bg-white/10 text-primary-orange px-3 py-1 rounded text-sm flex-1">
                      {referralCode}
                    </code>
                    <button
                      onClick={copyReferralLink}
                      className="p-2 text-gray-400 hover:text-white transition-colors"
                    >
                      <CopyIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <p className="text-gray-400 text-xs">
                  Share your referral link and earn 30% commission on every successful signup!
                </p>
              </div>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-6"
            >
              <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <Link
                  href="/pricing"
                  className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors p-2 rounded hover:bg-white/5"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Upgrade Plan</span>
                </Link>
                <Link
                  href="/support"
                  className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors p-2 rounded hover:bg-white/5"
                >
                  <Shield className="w-4 h-4" />
                  <span>Support</span>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default UserDashboard
