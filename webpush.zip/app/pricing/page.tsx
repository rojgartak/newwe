import Navigation from '@/components/Navigation'
import PricingSection from '@/components/PricingSection'
import Footer from '@/components/Footer'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Pricing - BeastBrowser | Choose Your Anti-Detection Plan',
  description: 'Choose the perfect BeastBrowser plan for your needs. Start with our free trial or upgrade to premium for unlimited browser profiles and advanced features.',
  keywords: 'BeastBrowser pricing, anti-detection browser plans, browser automation pricing, fingerprint protection plans'
}

export default function PricingPage() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <div className="pt-20">
        <PricingSection />
      </div>
      <Footer />
    </main>
  )
}