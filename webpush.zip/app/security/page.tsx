'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Shield, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  MapPin,
  ArrowLeft,
  Lock,
  Eye,
  Key,
  Smartphone,
  Wifi
} from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

const SecurityPage = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userEmail, setUserEmail] = useState('')
  const [userName, setUserName] = useState('')
  const router = useRouter()

  useEffect(() => {
    const authenticated = localStorage.getItem('isAuthenticated')
    const email = localStorage.getItem('userEmail')
    const name = localStorage.getItem('userName')
    
    if (!authenticated) {
      router.push('/login')
    } else {
      setIsAuthenticated(true)
      setUserEmail(email || '')
      setUserName(name || email || 'User')
    }
  }, [router])

  // Mock data for demonstration
  const securityScore = 85
  const loginHistory = [
    {
      id: 1,
      timestamp: '2024-01-22 14:30',
      location: 'New York, US',
      device: 'Chrome on Windows',
      ip: '192.168.1.1',
      status: 'success'
    },
    {
      id: 2,
      timestamp: '2024-01-22 09:15',
      location: 'New York, US',
      device: 'Chrome on Windows',
      ip: '192.168.1.1',
      status: 'success'
    },
    {
      id: 3,
      timestamp: '2024-01-21 18:45',
      location: 'California, US',
      device: 'Safari on iPhone',
      ip: '10.0.0.1',
      status: 'failed'
    }
  ]

  const securityChecks = [
    {
      name: 'Strong Password',
      status: 'good',
      description: 'Your password meets security requirements',
      action: null
    },
    {
      name: 'Email Verified',
      status: 'good',
      description: 'Your email address has been verified',
      action: null
    },
    {
      name: 'Two-Factor Authentication',
      status: 'warning',
      description: 'Enable 2FA for enhanced security',
      action: 'Enable 2FA'
    },
    {
      name: 'Recent Login Activity',
      status: 'good',
      description: 'No suspicious login attempts detected',
      action: null
    }
  ]

  const securityTips = [
    {
      icon: Lock,
      title: 'Use Strong Passwords',
      description: 'Create unique passwords with a mix of letters, numbers, and symbols',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: Smartphone,
      title: 'Enable Two-Factor Authentication',
      description: 'Add an extra layer of security to your account',
      color: 'from-green-500 to-green-600'
    },
    {
      icon: Eye,
      title: 'Monitor Account Activity',
      description: 'Regularly check your login history for suspicious activity',
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: Wifi,
      title: 'Secure Your Connection',
      description: 'Always use HTTPS and avoid public Wi-Fi for sensitive activities',
      color: 'from-orange-500 to-red-500'
    }
  ]

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-orange border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link 
                href="/dashboard"
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Dashboard</span>
              </Link>
            </div>
            <Link href="/" className="flex items-center space-x-3">
              <img src="/Beast_B.png" alt="BeastBrowser" className="w-8 h-8 rounded-lg shadow-md" />
              <span className="text-lg font-bold font-poppins gradient-text">BeastBrowser</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Security Center</h1>
            <p className="text-gray-600">Monitor your account security and protect your data</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Security Score */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary-orange to-primary-red rounded-lg flex items-center justify-center">
                    <Shield className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-xl font-semibold text-gray-900">Security Score</h2>
                </div>

                <div className="text-center">
                  <div className="relative w-32 h-32 mx-auto mb-6">
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
                      <path
                        className="text-gray-200"
                        stroke="currentColor"
                        strokeWidth="2"
                        fill="transparent"
                        d="M18,2.0845 a 15.9155,15.9155 0 0,1 0,31.831 a 15.9155,15.9155 0 0,1 0,-31.831"
                      />
                      <path
                        className="text-primary-orange"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeDasharray={`${securityScore}, 100`}
                        strokeLinecap="round"
                        fill="transparent"
                        d="M18,2.0845 a 15.9155,15.9155 0 0,1 0,31.831 a 15.9155,15.9155 0 0,1 0,-31.831"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-gray-900">{securityScore}</div>
                        <div className="text-sm text-gray-500">out of 100</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    securityScore >= 80 ? 'bg-green-100 text-green-800' :
                    securityScore >= 60 ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {securityScore >= 80 ? 'Excellent Security' :
                     securityScore >= 60 ? 'Good Security' :
                     'Needs Improvement'}
                  </div>
                </div>
              </div>

              {/* Security Tips */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mt-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Security Tips</h3>
                <div className="space-y-4">
                  {securityTips.map((tip, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className={`w-8 h-8 bg-gradient-to-br ${tip.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                        <tip.icon className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">{tip.title}</h4>
                        <p className="text-xs text-gray-600 mt-1">{tip.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 space-y-6">
              {/* Security Checks */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Security Checklist</h2>
                <div className="space-y-4">
                  {securityChecks.map((check, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-100 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          check.status === 'good' 
                            ? 'bg-green-100 text-green-600' 
                            : 'bg-yellow-100 text-yellow-600'
                        }`}>
                          {check.status === 'good' ? 
                            <CheckCircle className="w-4 h-4" /> : 
                            <AlertTriangle className="w-4 h-4" />
                          }
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">{check.name}</h3>
                          <p className="text-sm text-gray-600">{check.description}</p>
                        </div>
                      </div>
                      {check.action && (
                        <button className="px-3 py-1 bg-primary-orange text-white rounded-lg text-sm hover:bg-primary-red transition-colors">
                          {check.action}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Login History */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                    <Clock className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-xl font-semibold text-gray-900">Recent Login Activity</h2>
                </div>

                <div className="overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-100">
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Time</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Location</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Device</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loginHistory.map((login) => (
                        <tr key={login.id} className="border-b border-gray-50 hover:bg-gray-50">
                          <td className="py-3 px-4 text-sm text-gray-900">{login.timestamp}</td>
                          <td className="py-3 px-4 text-sm text-gray-600">
                            <div className="flex items-center space-x-2">
                              <MapPin className="w-4 h-4 text-gray-400" />
                              <span>{login.location}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-sm text-gray-600">{login.device}</td>
                          <td className="py-3 px-4">
                            <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                              login.status === 'success' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {login.status === 'success' ? 'Success' : 'Failed'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

export default SecurityPage