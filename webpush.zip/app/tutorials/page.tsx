'use client'

import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'
import { motion } from 'framer-motion'
import { Play, Clock, User, Star } from 'lucide-react'
import Link from 'next/link'

export default function TutorialsPage() {
  const tutorials = [
    {
      title: 'Getting Started with BeastBrowser',
      description: 'Complete beginner guide to installing and setting up your first browser profile.',
      duration: '5 min',
      level: 'Beginner',
      thumbnail: '🚀'
    },
    {
      title: 'Advanced Profile Management',
      description: 'Learn how to create, organize, and manage multiple browser profiles efficiently.',
      duration: '8 min',
      level: 'Intermediate',
      thumbnail: '👥'
    },
    {
      title: 'Fingerprint Protection Deep Dive',
      description: 'Understanding how BeastBrowser protects your identity and prevents detection.',
      duration: '12 min',
      level: 'Advanced',
      thumbnail: '🔒'
    },
    {
      title: 'Proxy Integration Guide',
      description: 'Step-by-step guide to setting up and managing proxy connections.',
      duration: '6 min',
      level: 'Intermediate',
      thumbnail: '🌐'
    },
    {
      title: 'Team Collaboration Features',
      description: 'Learn how to share profiles and collaborate with team members effectively.',
      duration: '10 min',
      level: 'Intermediate',
      thumbnail: '🤝'
    },
    {
      title: 'Automation and API Usage',
      description: 'Automate profile creation and management using BeastBrowser API.',
      duration: '15 min',
      level: 'Advanced',
      thumbnail: '⚡'
    }
  ]

  return (
    <main className="min-h-screen">
      <Navigation />
      
      <section className="pt-32 pb-20 bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-primary-orange to-primary-red rounded-2xl flex items-center justify-center mx-auto mb-8">
              <Play className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold font-poppins mb-6">
              <span className="gradient-text">Video Tutorials</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Learn BeastBrowser with our comprehensive video tutorials. From beginner basics to advanced techniques.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {tutorials.map((tutorial, index) => (
              <motion.div
                key={tutorial.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden hover:shadow-2xl transition-all duration-300 group cursor-pointer"
              >
                <div className="relative bg-gradient-to-br from-gray-100 to-gray-200 h-48 flex items-center justify-center">
                  <span className="text-6xl">{tutorial.thumbnail}</span>
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center">
                      <Play className="w-6 h-6 text-gray-900 ml-1" />
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-3 group-hover:text-primary-orange transition-colors duration-200">
                    {tutorial.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                    {tutorial.description}
                  </p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{tutorial.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{tutorial.level}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
              Learning <span className="gradient-text">Paths</span>
            </h2>
            <p className="text-xl text-gray-600">
              Structured learning paths to help you master BeastBrowser step by step
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mb-6">
                <Star className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Beginner Path</h3>
              <p className="text-gray-600 mb-4">Perfect for users new to anti-detection browsing.</p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• Getting Started Tutorial</li>
                <li>• Basic Profile Setup</li>
                <li>• Privacy Fundamentals</li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mb-6">
                <Star className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Professional Path</h3>
              <p className="text-gray-600 mb-4">For business users and professionals.</p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• Advanced Profile Management</li>
                <li>• Team Collaboration</li>
                <li>• Proxy Integration</li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="bg-white rounded-2xl shadow-lg border p-8"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mb-6">
                <Star className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Developer Path</h3>
              <p className="text-gray-600 mb-4">For developers and technical users.</p>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• API Integration</li>
                <li>• Automation Scripts</li>
                <li>• Advanced Techniques</li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-900 text-white">
        <div className="container-custom text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Start Learning Today
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Master BeastBrowser with our comprehensive video tutorials and become an expert in anti-detection browsing.
            </p>
            <Link 
              href="/download"
              className="px-8 py-4 bg-gradient-to-r from-primary-orange to-primary-red text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
            >
              Download & Start Learning
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}