const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();

const db = admin.firestore();

// Function to check for expired premium plans and downgrade users
exports.checkExpiries = functions.pubsub.schedule('every 24 hours from 00:00').onRun(async (context) => {
  try {
    console.log('Checking for expired premium plans...');
    
    const now = admin.firestore.Timestamp.now();
    const usersRef = db.collection('userProfileLimits');
    const snapshot = await usersRef.get();
    
    let downgradeCount = 0;
    
    for (const doc of snapshot.docs) {
      const userData = doc.data();
      
      // Check if user has a premium plan and an expiry date
      if (userData.plan !== 'free' && userData.premiumExpiry) {
        // Check if the plan has expired
        if (userData.premiumExpiry < now) {
          // Downgrade the user to free plan
          await doc.ref.update({
            plan: 'free',
            premiumExpiry: null,
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          });
          
          console.log(`Downgraded user ${userData.email} from ${userData.plan} to free plan`);
          downgradeCount++;
        }
      }
    }
    
    console.log(`Completed checking expiries. Downgraded ${downgradeCount} users.`);
    return null;
  } catch (error) {
    console.error('Error checking premium expiries:', error);
    return null;
  }
});

// Function to handle payment success and upgrade user
exports.handlePaymentSuccess = functions.https.onRequest(async (req, res) => {
  try {
    if (req.method !== 'POST') {
      res.status(405).send('Method Not Allowed');
      return;
    }
    
    const { email, planType } = req.body;
    
    if (!email || !planType) {
      res.status(400).send('Missing required fields: email and planType');
      return;
    }
    
    // Find user by email
    const usersRef = db.collection('userProfileLimits');
    const userSnapshot = await usersRef.where('email', '==', email).limit(1).get();
    
    if (userSnapshot.empty) {
      res.status(404).send('User not found');
      return;
    }
    
    const userDoc = userSnapshot.docs[0];
    const userData = userDoc.data();
    
    // Calculate expiry date
    const expiry = new Date();
    if (planType === 'monthly') {
      expiry.setMonth(expiry.getMonth() + 1);
    } else if (planType === 'yearly') {
      expiry.setFullYear(expiry.getFullYear() + 1);
    } else {
      res.status(400).send('Invalid plan type');
      return;
    }
    
    // Upgrade user
    await userDoc.ref.update({
      plan: planType,
      premiumExpiry: admin.firestore.Timestamp.fromDate(expiry),
      trialStart: null, // End trial
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    console.log(`Upgraded user ${email} to ${planType} plan`);
    
    res.status(200).send({ success: true, message: 'User upgraded successfully' });
  } catch (error) {
    console.error('Error handling payment success:', error);
    res.status(500).send({ success: false, error: error.message });
  }
});