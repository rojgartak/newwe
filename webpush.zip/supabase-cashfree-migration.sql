-- Migration to add Cashfree support to existing database
-- Run this in Supabase SQL Editor to update your existing tables

-- Step 1: Drop existing CHECK constraints
ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_payment_gateway_check;
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_payment_gateway_check;
ALTER TABLE webhook_logs DROP CONSTRAINT IF EXISTS webhook_logs_gateway_check;

-- Step 2: Add new CHECK constraints with Cashfree included
ALTER TABLE subscriptions 
ADD CONSTRAINT subscriptions_payment_gateway_check 
CHECK (payment_gateway IN ('cashfree', 'phonepe', 'nowpayments'));

ALTER TABLE payments 
ADD CONSTRAINT payments_payment_gateway_check 
CHECK (payment_gateway IN ('cashfree', 'phonepe', 'nowpayments'));

ALTER TABLE webhook_logs 
ADD CONSTRAINT webhook_logs_gateway_check 
CHECK (gateway IN ('cashfree', 'phonepe', 'nowpayments'));

-- Verify the changes
SELECT 
    tablename, 
    constraintname, 
    constrainttype, 
    constraintdef 
FROM pg_constraint c
JOIN pg_class t ON c.conrelid = t.oid
JOIN pg_namespace n ON t.relnamespace = n.oid
WHERE n.nspname = 'public' 
AND t.relname IN ('subscriptions', 'payments', 'webhook_logs')
AND c.contype = 'c'
ORDER BY t.relname;
