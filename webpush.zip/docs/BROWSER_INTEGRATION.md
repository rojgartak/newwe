# Beast Browser - Browser Integration API Documentation

## 🎯 Overview

Complete API system for integrating Beast Browser desktop application with the web dashboard. This allows the browser to authenticate users, check plan status, sync settings, and track usage.

## 🔧 API Endpoints

### 🔐 Authentication API

#### `POST /api/browser/auth`
**Description**: Authenticate browser user and get access token

**Request Body**:
```json
{
  "email": "user@example.com",
  "password": "user_password"
}
```

**Success Response**:
```json
{
  "success": true,
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "name": "User Name",
    "plan": "Monthly Premium",
    "planActivatedAt": "2024-01-01T00:00:00.000Z",
    "company": "Company Name",
    "avatar": "avatar_url",
    "joinedAt": "2024-01-01T00:00:00.000Z"
  },
  "token": "jwt_access_token_here",
  "session": {
    "id": "session_id",
    "createdAt": "2024-01-01T00:00:00.000Z",
    "expiresAt": "2024-01-31T00:00:00.000Z"
  }
}
```

#### `GET /api/browser/auth`
**Description**: Verify existing browser token

**Headers**:
```
Authorization: Bearer jwt_token_here
```

**Success Response**:
```json
{
  "success": true,
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "name": "User Name",
    "plan": "Monthly Premium",
    "planActivatedAt": "2024-01-01T00:00:00.000Z"
  },
  "valid": true
}
```

### 📋 Plan Verification API

#### `GET /api/browser/plan?email=user@example.com`
**Description**: Check user's plan status and permissions

**Query Parameters**:
- `email` (string): User's email address

**Alternative**: Use Authorization header with token

**Success Response**:
```json
{
  "success": true,
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "name": "User Name",
    "plan": "Monthly Premium",
    "isActive": true,
    "isPremium": true,
    "planActivatedAt": "2024-01-01T00:00:00.000Z",
    "planExpiresAt": "2024-02-01T00:00:00.000Z",
    "isExpired": false
  },
  "features": {
    "browsing": true,
    "bookmarks": true,
    "history": true,
    "basicSecurity": true,
    "adBlocker": true,
    "vpn": true,
    "customThemes": true,
    "advancedSecurity": true,
    "privateMode": true,
    "downloadManager": true,
    "syncAcrossDevices": true,
    "prioritySupport": true,
    "maxBookmarks": -1,
    "maxHistory": -1
  },
  "permissions": {
    "canAccessPremiumFeatures": true,
    "canDownloadFiles": true,
    "canUseAdvancedSettings": true,
    "canUseCustomThemes": true,
    "canUseAdBlocker": true,
    "canUseVPN": true,
    "maxBookmarks": -1,
    "maxHistory": -1
  }
}
```

#### `POST /api/browser/plan`
**Description**: Bulk plan verification for multiple users/tokens

**Request Body**:
```json
{
  "emails": ["user1@example.com", "user2@example.com"],
  "tokens": ["token1", "token2"]
}
```

### ⚙️ Configuration API

#### `GET /api/browser/config?email=user@example.com`
**Description**: Get browser configuration based on user plan

**Success Response**:
```json
{
  "success": true,
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "name": "User Name",
    "plan": "Monthly Premium",
    "isPremium": true,
    "isActive": true,
    "planExpiresAt": "2024-02-01T00:00:00.000Z"
  },
  "config": {
    "browser": {
      "name": "BeastBrowser",
      "version": "1.0.0",
      "userAgent": "BeastBrowser/1.0.0",
      "homePage": "https://beastbrowser.com",
      "searchEngine": "https://www.google.com/search?q="
    },
    "features": {
      "adBlocker": true,
      "vpnAccess": true,
      "customThemes": true,
      "downloadManager": true,
      "syncAcrossDevices": true,
      "prioritySupport": true,
      "advancedSecurity": true,
      "privateVault": true
    },
    "limits": {
      "maxBookmarks": -1,
      "maxHistory": -1,
      "maxDownloads": -1,
      "maxTabs": -1,
      "maxPasswords": -1
    },
    "ads": {
      "showAds": false,
      "showUpgradePrompts": false,
      "adFrequency": "none",
      "promoteUpgrade": false
    },
    "premium": {
      "vpnServers": [
        {
          "country": "US",
          "city": "New York",
          "server": "us-ny-01.beastbrowser.com"
        }
      ],
      "adBlockerLists": [
        "EasyList",
        "EasyPrivacy",
        "Malware Protection"
      ],
      "customThemes": [
        {
          "name": "Dark Pro",
          "file": "dark-pro.css"
        }
      ]
    }
  },
  "lastUpdated": "2024-01-01T00:00:00.000Z"
}
```

### 📊 Usage Tracking API

#### `POST /api/browser/usage`
**Description**: Track browser usage and activities

**Request Body**:
```json
{
  "email": "user@example.com",
  "action": "page_load",
  "data": {
    "url": "https://example.com",
    "loadTime": 1200,
    "userAgent": "BeastBrowser/1.0.0"
  },
  "timestamp": "2024-01-01T00:00:00.000Z",
  "sessionId": "session_123"
}
```

**Alternative**: Use Authorization header with token instead of email

**Success Response**:
```json
{
  "success": true,
  "message": "Usage tracked successfully",
  "record": {
    "id": "record_id",
    "action": "page_load",
    "timestamp": "2024-01-01T00:00:00.000Z"
  }
}
```

#### `GET /api/browser/usage?email=user@example.com&days=30`
**Description**: Get usage statistics for user

**Query Parameters**:
- `email` (string): User's email
- `action` (string, optional): Filter by specific action
- `days` (number, optional): Number of days to include (default: 30)

**Success Response**:
```json
{
  "success": true,
  "user": {
    "email": "user@example.com",
    "name": "User Name",
    "plan": "Monthly Premium"
  },
  "period": {
    "days": 30,
    "from": "2023-12-02T00:00:00.000Z",
    "to": "2024-01-01T00:00:00.000Z"
  },
  "stats": {
    "totalActions": 1250,
    "uniqueDays": 28,
    "averagePerDay": 45,
    "topActions": {
      "page_load": 450,
      "new_tab": 320,
      "search_query": 180
    },
    "featureUsage": {
      "browsing": 450,
      "bookmarks": 80,
      "downloads": 25,
      "settings": 12,
      "search": 180,
      "tabs": 320
    }
  },
  "recentActivity": [
    {
      "action": "page_load",
      "timestamp": "2024-01-01T00:00:00.000Z",
      "data": { "url": "https://example.com" }
    }
  ]
}
```

### 🔄 Session Management API

#### `GET /api/browser/session?email=user@example.com`
**Description**: Get session information

**Query Parameters**:
- `email` (string): Get all sessions for user
- `token` (string): Get specific session by token

**Success Response**:
```json
{
  "success": true,
  "email": "user@example.com",
  "totalSessions": 3,
  "sessions": [
    {
      "id": "session_1",
      "createdAt": "2024-01-01T00:00:00.000Z",
      "lastActivity": "2024-01-01T10:00:00.000Z",
      "deviceType": "browser",
      "userAgent": "BeastBrowser/1.0.0",
      "ipAddress": "192.168.1.100",
      "isActive": true
    }
  ]
}
```

#### `POST /api/browser/session`
**Description**: Manage sessions (refresh, heartbeat, sync)

**Request Body**:
```json
{
  "action": "heartbeat",
  "token": "session_token"
}
```

**Actions Available**:
- `refresh`: Update session with new data
- `heartbeat`: Simple keep-alive ping
- `sync`: Sync session with latest user data

#### `DELETE /api/browser/session`
**Description**: Delete session(s)

**Request Body**:
```json
{
  "token": "session_token"
}
```
OR
```json
{
  "email": "user@example.com",
  "all": true
}
```

## 🚀 Integration Examples

### 1. Browser Startup Authentication

```javascript
// Browser startup - authenticate user
async function authenticateUser(email, password) {
  try {
    const response = await fetch('https://yourdomain.com/api/browser/auth', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password })
    });
    
    const result = await response.json();
    
    if (result.success) {
      // Store token for future requests
      localStorage.setItem('authToken', result.token);
      localStorage.setItem('userPlan', result.user.plan);
      
      console.log('User authenticated:', result.user);
      return result;
    } else {
      console.error('Authentication failed:', result.error);
      return null;
    }
  } catch (error) {
    console.error('Auth error:', error);
    return null;
  }
}
```

### 2. Check Plan and Configure Browser

```javascript
// Get user configuration and set up browser
async function configureBrowser() {
  const token = localStorage.getItem('authToken');
  
  try {
    const response = await fetch('https://yourdomain.com/api/browser/config', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    const result = await response.json();
    
    if (result.success) {
      const config = result.config;
      
      // Configure browser based on plan
      if (config.features.adBlocker) {
        enableAdBlocker(config.premium.adBlockerLists);
      }
      
      if (config.features.vpnAccess) {
        setupVPNServers(config.premium.vpnServers);
      }
      
      if (config.features.customThemes) {
        loadCustomThemes(config.premium.customThemes);
      }
      
      // Set limits
      setBrowserLimits(config.limits);
      
      // Configure ads
      if (config.ads.showAds) {
        showUpgradePrompts();
      }
      
      console.log('Browser configured for plan:', result.user.plan);
      return config;
    }
  } catch (error) {
    console.error('Config error:', error);
  }
}
```

### 3. Track Browser Usage

```javascript
// Track user actions
async function trackUsage(action, data = {}) {
  const token = localStorage.getItem('authToken');
  
  try {
    await fetch('https://yourdomain.com/api/browser/usage', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: action,
        data: data,
        timestamp: new Date().toISOString(),
        sessionId: getSessionId()
      })
    });
  } catch (error) {
    console.error('Usage tracking error:', error);
  }
}

// Usage examples
trackUsage('page_load', { url: 'https://example.com', loadTime: 1200 });
trackUsage('new_tab');
trackUsage('add_bookmark', { url: 'https://example.com', title: 'Example' });
trackUsage('use_vpn', { server: 'us-ny-01.beastbrowser.com' });
```

### 4. Session Heartbeat

```javascript
// Keep session alive
async function sendHeartbeat() {
  const token = localStorage.getItem('authToken');
  
  try {
    await fetch('https://yourdomain.com/api/browser/session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: 'heartbeat',
        token: token
      })
    });
  } catch (error) {
    console.error('Heartbeat error:', error);
  }
}

// Send heartbeat every 5 minutes
setInterval(sendHeartbeat, 5 * 60 * 1000);
```

### 5. Verify Plan Status

```javascript
// Check if user can access premium features
async function canUseFeature(featureName) {
  const token = localStorage.getItem('authToken');
  
  try {
    const response = await fetch('https://yourdomain.com/api/browser/plan', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    const result = await response.json();
    
    if (result.success) {
      return result.permissions[`canUse${featureName}`] || false;
    }
    
    return false;
  } catch (error) {
    console.error('Plan check error:', error);
    return false;
  }
}

// Usage
if (await canUseFeature('VPN')) {
  showVPNOption();
}

if (await canUseFeature('AdBlocker')) {
  enableAdBlocker();
}
```

## 📝 Browser Action Types

Use these predefined action types for consistent tracking:

```javascript
const BROWSER_ACTIONS = {
  // Authentication
  BROWSER_LOGIN: 'browser_login',
  BROWSER_LOGOUT: 'browser_logout',
  
  // Navigation
  PAGE_LOAD: 'page_load',
  NEW_TAB: 'new_tab',
  CLOSE_TAB: 'close_tab',
  SWITCH_TAB: 'switch_tab',
  
  // Bookmarks
  ADD_BOOKMARK: 'add_bookmark',
  REMOVE_BOOKMARK: 'remove_bookmark',
  ORGANIZE_BOOKMARKS: 'organize_bookmarks',
  
  // Downloads
  START_DOWNLOAD: 'start_download',
  COMPLETE_DOWNLOAD: 'complete_download',
  CANCEL_DOWNLOAD: 'cancel_download',
  
  // Search
  SEARCH_QUERY: 'search_query',
  SEARCH_SUGGESTION: 'search_suggestion',
  
  // Settings
  CHANGE_THEME: 'change_theme',
  UPDATE_SETTINGS: 'update_settings',
  ENABLE_FEATURE: 'enable_feature',
  DISABLE_FEATURE: 'disable_feature',
  
  // Premium Features
  USE_VPN: 'use_vpn',
  BLOCK_AD: 'block_ad',
  USE_CUSTOM_THEME: 'use_custom_theme',
  SYNC_DATA: 'sync_data',
  
  // Errors
  PAGE_ERROR: 'page_error',
  BROWSER_CRASH: 'browser_crash',
  FEATURE_ERROR: 'feature_error'
};
```

## 🔒 Security Considerations

1. **Token Storage**: Store tokens securely in browser's secure storage
2. **HTTPS Only**: All API calls must use HTTPS
3. **Token Expiry**: Handle token expiration gracefully
4. **Rate Limiting**: Implement reasonable rate limits for API calls
5. **Data Validation**: Always validate data before sending to APIs

## 🎯 Error Handling

All APIs return consistent error responses:

```json
{
  "success": false,
  "error": "Error message here"
}
```

Common HTTP status codes:
- `400`: Bad Request (missing parameters)
- `401`: Unauthorized (invalid/expired token)
- `404`: Not Found (user/session not found)
- `500`: Internal Server Error

## 🚀 Ready for Integration!

Your browser can now:
- ✅ Authenticate users with web dashboard credentials
- ✅ Check plan status and permissions
- ✅ Get configuration based on plan
- ✅ Track usage and sync with dashboard
- ✅ Manage sessions properly
- ✅ Handle premium vs free features

The browser is now fully connected to your web dashboard!