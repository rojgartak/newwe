# Razorpay Integration Setup Guide

## 🚨 Important Security Warning

**NEVER commit live API keys to version control!** The example keys shown in documentation are real LIVE keys and should be regenerated immediately if accidentally exposed.

## Prerequisites

1. **Razorpay Account**: Sign up at [https://razorpay.com](https://razorpay.com)
2. **Email Verification**: Verify your email address
3. **Business Verification**: Complete KYC for live transactions
4. **Node.js**: Ensure you have Node.js installed

## Step 1: Get API Keys

### For Development (Test Mode)
1. Go to [Razorpay Dashboard](https://dashboard.razorpay.com)
2. Navigate to **Settings > API Keys**
3. Generate **Test Keys** (starts with `rzp_test_`)
4. Download and securely store both Key ID and Secret

### For Production (Live Mode)
1. Complete business verification in Razorpay dashboard
2. Generate **Live Keys** (starts with `rzp_live_`)
3. **NEVER share these keys publicly!**

## Step 2: Environment Configuration

Create a `.env.local` file (copy from `.env.example`):

```bash
# Test Mode (Development)
RAZORPAY_KEY_ID=rzp_test_YOUR_TEST_KEY_ID
RAZORPAY_KEY_SECRET=your_test_secret_key

# Live Mode (Production) - KEEP SECURE!
# RAZORPAY_KEY_ID=rzp_live_YOUR_LIVE_KEY_ID
# RAZORPAY_KEY_SECRET=your_live_secret_key

# Webhook Secret
RAZORPAY_WEBHOOK_SECRET=your_webhook_secret
```

## Step 3: Webhook Setup (Production)

1. Go to **Settings > Webhooks** in Razorpay dashboard
2. Add webhook URL: `https://yourdomain.com/api/payments/razorpay/webhook`
3. Select events:
   - `payment.captured`
   - `payment.failed`
   - `order.paid`
4. Generate and save webhook secret to environment variables

## Step 4: Testing

### Test Mode
1. Use test keys in `.env.local`
2. Use test card numbers:
   - **Success**: `4111 1111 1111 1111`
   - **Failure**: `4000 0000 0000 0002`
   - **CVV**: Any 3 digits
   - **Expiry**: Any future date

### Demo Mode (No Keys)
- If no `RAZORPAY_KEY_SECRET` is provided, the system runs in demo mode
- Payments are simulated and complete after 2 seconds
- No actual payment processing occurs

## Step 5: Production Deployment

### Pre-deployment Checklist
- [ ] Live Razorpay keys are configured
- [ ] Webhook URL is set up and tested
- [ ] SSL certificate is valid
- [ ] Domain is verified in Razorpay dashboard
- [ ] Test small amounts first

### Going Live
1. Switch to live keys in environment variables
2. Update webhook URL to production domain
3. Test with small amounts
4. Monitor dashboard for transactions

## API Endpoints

### Create Order
```
POST /api/payments/razorpay/create-order
```

### Verify Payment
```
POST /api/payments/razorpay/verify
```

### Webhook Handler
```
POST /api/payments/razorpay/webhook
```

## Security Best Practices

1. **Environment Variables**: Never hardcode keys in source code
2. **HTTPS Only**: Always use HTTPS in production
3. **Webhook Verification**: Always verify webhook signatures
4. **Key Rotation**: Regularly rotate API keys
5. **Monitoring**: Monitor for suspicious transactions

## Troubleshooting

### Common Issues

**Error**: "Payment gateway not available"
- **Solution**: Ensure Razorpay script is loaded properly

**Error**: "Invalid signature"
- **Solution**: Check webhook secret and signature verification

**Error**: "Failed to create payment order"
- **Solution**: Verify API keys and check Razorpay dashboard for errors

### Debug Mode
Enable debug logging by checking browser console and server logs for detailed error information.

## Support

- **Razorpay Docs**: [https://razorpay.com/docs](https://razorpay.com/docs)
- **API Reference**: [https://razorpay.com/docs/api](https://razorpay.com/docs/api)
- **Support**: [https://razorpay.com/support](https://razorpay.com/support)

## Test Card Numbers

| Purpose | Card Number | CVV | Expiry |
|---------|-------------|-----|--------|
| Success | 4111 1111 1111 1111 | Any | Future |
| Failure | 4000 0000 0000 0002 | Any | Future |
| Insufficient Funds | 4000 0000 0000 0069 | Any | Future |
| Expired Card | 4000 0000 0000 0069 | Any | Past |

---

**Note**: Always test thoroughly before going live with real payments!