# Beast Browser - API Key Setup & Usage Guide

## 🎯 Overview

Browser API key system for secure communication between Beast Browser desktop application and web dashboard.

## 🔑 Current API Key

**Default API Key**: `beast-browser-api-key-2024`

This is the API key your browser needs to authenticate with the web dashboard APIs.

## 📋 Environment Setup

### 1. Create `.env.local` File

Create or update your `.env.local` file with:

```bash
# Browser Integration API
BROWSER_API_KEY=beast-browser-api-key-2024
JWT_SECRET=beast-browser-jwt-secret-key-2024
BROWSER_API_RATE_LIMIT=100
```

### 2. Restart Next.js Server

After updating environment variables:

```bash
npm run dev
# or
yarn dev
```

## 🚀 Browser Integration Usage

### 1. Authentication Request

```javascript
// Browser authentication with API key
const response = await fetch('https://yourdomain.com/api/browser/auth', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-API-Key': 'beast-browser-api-key-2024',  // Required API key
    'User-Agent': 'BeastBrowser/1.0.0'
  },
  body: JSON.stringify({
    email: 'user@example.com',
    password: 'user_password'
  })
});

const result = await response.json();
if (result.success) {
  console.log('Authenticated:', result.user);
  localStorage.setItem('authToken', result.token);
}
```

### 2. Plan Verification

```javascript
// Check user plan with API key
const response = await fetch('https://yourdomain.com/api/browser/plan?email=user@example.com', {
  headers: {
    'X-API-Key': 'beast-browser-api-key-2024',
    'Authorization': `Bearer ${authToken}`
  }
});

const result = await response.json();
if (result.success) {
  console.log('User plan:', result.user.plan);
  console.log('Premium features:', result.features);
}
```

### 3. Usage Tracking

```javascript
// Track browser usage with API key
await fetch('https://yourdomain.com/api/browser/usage', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-API-Key': 'beast-browser-api-key-2024',
    'Authorization': `Bearer ${authToken}`
  },
  body: JSON.stringify({
    action: 'page_load',
    data: { url: 'https://example.com' }
  })
});
```

### 4. Configuration Fetch

```javascript
// Get browser configuration with API key
const response = await fetch('https://yourdomain.com/api/browser/config', {
  headers: {
    'X-API-Key': 'beast-browser-api-key-2024',
    'Authorization': `Bearer ${authToken}`
  }
});

const result = await response.json();
if (result.success) {
  const config = result.config;
  
  // Configure browser based on response
  if (config.features.adBlocker) {
    enableAdBlocker();
  }
  
  if (config.features.vpnAccess) {
    setupVPN(config.premium.vpnServers);
  }
}
```

## 🔧 Admin API Key Management

### Get Current API Key Information

```bash
curl -X GET "https://yourdomain.com/api/browser/apikey" \
  -H "Authorization: Basic YWRtaW46QWhtaWhlcmU3ODYk"
```

Response:
```json
{
  "success": true,
  "apiKey": "beast-browser-api-key-2024",
  "keyInfo": {
    "prefix": "beast-browser-",
    "length": 45,
    "rateLimit": 100,
    "tokenExpiry": "30d"
  },
  "usage": {
    "description": "Use this API key in browser integration",
    "headerName": "x-api-key or x-browser-api-key",
    "example": "X-API-Key: beast-browser-api-key-2024"
  }
}
```

### Generate New API Key

```bash
curl -X POST "https://yourdomain.com/api/browser/apikey" \
  -H "Authorization: Basic YWRtaW46QWhtaWhlcmU3ODYk" \
  -H "Content-Type: application/json"
```

Response:
```json
{
  "success": true,
  "message": "New API key generated",
  "apiKey": "beast-browser-Kj8sL9mN2oP3qR4sT5uV6wX7yZ8aB9c",
  "previousKey": "beast-browser-api-key-2024",
  "instructions": [
    "Update your .env.local file with the new API key:",
    "BROWSER_API_KEY=beast-browser-Kj8sL9mN2oP3qR4sT5uV6wX7yZ8aB9c",
    "Restart your Next.js server",
    "Update browser integration to use new API key",
    "Test browser authentication"
  ],
  "warning": "Save this key securely. It will not be shown again."
}
```

## 🔒 Security Features

### API Key Validation
- Required for all browser API endpoints
- Validated on every request
- Rate limiting per IP address

### Rate Limiting
- Default: 100 requests per minute per IP
- Configurable via `BROWSER_API_RATE_LIMIT`
- Automatic cleanup of expired limits

### Token Security
- 30-day expiry for browser tokens
- Browser-specific token validation
- Secure token generation

## 📝 Browser Implementation Example

### Complete Browser Integration Class

```javascript
class BeastBrowserAPI {
  constructor(apiKey, baseUrl = 'https://yourdomain.com') {
    this.apiKey = apiKey;
    this.baseUrl = baseUrl;
    this.authToken = localStorage.getItem('authToken');
  }

  // Generic API request with API key
  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'X-API-Key': this.apiKey,
      'User-Agent': 'BeastBrowser/1.0.0',
      ...options.headers
    };

    if (this.authToken) {
      headers['Authorization'] = `Bearer ${this.authToken}`;
    }

    const response = await fetch(url, {
      ...options,
      headers
    });

    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error || 'API request failed');
    }

    return result;
  }

  // Authenticate user
  async authenticate(email, password) {
    const result = await this.request('/api/browser/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    this.authToken = result.token;
    localStorage.setItem('authToken', result.token);
    return result;
  }

  // Verify current token
  async verifyToken() {
    return await this.request('/api/browser/auth');
  }

  // Get user plan
  async getUserPlan() {
    return await this.request('/api/browser/plan');
  }

  // Get browser configuration
  async getConfig() {
    return await this.request('/api/browser/config');
  }

  // Track usage
  async trackUsage(action, data = {}) {
    return await this.request('/api/browser/usage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, data })
    });
  }

  // Session heartbeat
  async sendHeartbeat() {
    return await this.request('/api/browser/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'heartbeat',
        token: this.authToken
      })
    });
  }
}

// Usage in browser
const beastAPI = new BeastBrowserAPI('beast-browser-api-key-2024');

// Authenticate
const auth = await beastAPI.authenticate('user@example.com', 'password');

// Get configuration
const config = await beastAPI.getConfig();

// Track usage
await beastAPI.trackUsage('page_load', { url: 'https://example.com' });

// Send heartbeat every 5 minutes
setInterval(() => beastAPI.sendHeartbeat(), 5 * 60 * 1000);
```

## ⚠️ Important Security Notes

1. **Keep API Key Secret**: Never expose API key in client-side code that users can see
2. **Use HTTPS**: All API calls must use HTTPS in production
3. **Rotate Keys**: Regularly generate new API keys for security
4. **Monitor Usage**: Watch for suspicious API usage patterns
5. **Rate Limiting**: Respect rate limits to avoid being blocked

## 🧪 Testing API Key

Test your API key with curl:

```bash
# Test authentication
curl -X POST "https://yourdomain.com/api/browser/auth" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: beast-browser-api-key-2024" \
  -d '{"email":"test@example.com","password":"password"}'

# Test plan check
curl -X GET "https://yourdomain.com/api/browser/plan?email=test@example.com" \
  -H "X-API-Key: beast-browser-api-key-2024"
```

## 🔄 API Key Rotation Process

1. Generate new API key via admin endpoint
2. Update `.env.local` with new key
3. Restart Next.js server
4. Update browser application with new key
5. Test all browser functionality
6. Deactivate old key (if database-backed)

## 📊 Monitoring & Analytics

The API key system provides:
- Request logging
- Rate limit monitoring  
- Authentication success/failure tracking
- Usage pattern analysis

## 🆘 Troubleshooting

### Common Issues

**Error: "Invalid or missing API key"**
- Check if API key is included in headers
- Verify API key matches server configuration
- Ensure header name is correct (`X-API-Key`)

**Error: "Rate limit exceeded"**
- Reduce request frequency
- Check if multiple browsers using same IP
- Contact admin to increase rate limit

**Error: "Admin authentication required"**
- Use proper admin credentials for API key management
- Check Basic Auth format: `Basic base64(username:password)`

---

## ✅ Ready to Use!

Your browser API key system is now configured and ready:
- ✅ Secure API key authentication
- ✅ Rate limiting protection
- ✅ Admin key management
- ✅ Browser integration examples
- ✅ Security best practices

Use the API key `beast-browser-api-key-2024` in your browser integration!