# Beast Browser - Production Payment Gateway Setup

## 🚀 Live Production Configuration

This guide will help you deploy Beast Browser with **LIVE** payment gateways (Razorpay + NOWPayments) for real transactions.

## ⚠️ IMPORTANT: Security First

**The API keys configured in this project are LIVE PRODUCTION keys:**
- Razorpay Live Key: `rzp_live_REzg8f7xyATYP1`  
- NOWPayments Live Key: `HFDTB8Q-5C8404Z-QY4M71K-YFXS71G`

These keys are from the documentation and should be **regenerated immediately** for security.

## 📋 Pre-Deployment Checklist

### 1. Razorpay Setup
- [ ] Create account at [razorpay.com](https://razorpay.com)
- [ ] Complete KYC verification
- [ ] Generate new LIVE API keys
- [ ] Set up webhook endpoint: `https://yourdomain.com/api/payments/razorpay/webhook`
- [ ] Configure webhook events: `payment.captured`, `payment.failed`, `order.paid`
- [ ] Test with small amounts first

### 2. NOWPayments Setup
- [ ] Create account at [nowpayments.io](https://nowpayments.io)
- [ ] Verify email and complete setup
- [ ] Generate LIVE API key
- [ ] Set up IPN webhook: `https://yourdomain.com/api/payments/nowpayments/webhook`
- [ ] Configure payout wallet
- [ ] Enable required cryptocurrencies

### 3. Environment Configuration

Create `.env.local` file:

```bash
# Application
NEXT_PUBLIC_APP_URL=https://yourdomain.com
NODE_ENV=production

# Razorpay (LIVE)
RAZORPAY_KEY_ID=your_new_live_key_id
RAZORPAY_KEY_SECRET=your_new_live_secret
RAZORPAY_WEBHOOK_SECRET=your_webhook_secret

# NOWPayments (LIVE)
NOWPAYMENTS_API_KEY=your_new_live_api_key
NOWPAYMENTS_IPN_SECRET=your_ipn_secret

# Email (for confirmations)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
EMAIL_FROM=noreply@beastbrowser.com

# Admin
ADMIN_EMAIL=admin@yourdomain.com
ADMIN_SESSION_SECRET=your-secure-session-secret
```

## 🔧 Current Configuration Status

### ✅ What's Ready
- **Live Keys Configured**: Both payment gateways use production keys
- **Demo Mode Removed**: No simulation, all payments are real
- **Webhook Handlers**: Proper IPN/webhook processing implemented
- **Error Handling**: Production-grade error management
- **Security**: HMAC signature verification for both gateways
- **Status Checking**: Real-time payment status verification
- **Success/Cancel Pages**: Complete user flow handling

### 🛠️ API Endpoints Active
- `POST /api/payments/razorpay/create-order` - Create Razorpay orders
- `POST /api/payments/razorpay/verify` - Verify Razorpay payments  
- `POST /api/payments/razorpay/webhook` - Handle Razorpay notifications
- `POST /api/payments/nowpayments/create-payment` - Create crypto payments
- `GET /api/payments/nowpayments/status` - Check crypto payment status
- `POST /api/payments/nowpayments/estimate` - Get crypto price estimates
- `POST /api/payments/nowpayments/webhook` - Handle crypto notifications

## 💳 Supported Payment Methods

### Razorpay (Cards/UPI)
- Credit/Debit Cards (Visa, MasterCard, RuPay)
- UPI (Google Pay, PhonePe, Paytm, etc.)
- Net Banking
- Wallets (Paytm, Mobikwik, etc.)
- EMI options

### NOWPayments (Cryptocurrency)
- Bitcoin (BTC)
- Ethereum (ETH)
- USDT (TRC20/ERC20)
- Litecoin (LTC)
- Bitcoin Cash (BCH)
- And 10+ other cryptocurrencies

## 🚀 Deployment Steps

### 1. Deploy to Production
```bash
npm run build
npm run start
```

### 2. Configure Domain
- Point your domain to the deployment
- Ensure HTTPS is enabled (required for payments)
- Update `NEXT_PUBLIC_APP_URL` in environment

### 3. Set Up Webhooks
- **Razorpay**: `https://yourdomain.com/api/payments/razorpay/webhook`
- **NOWPayments**: `https://yourdomain.com/api/payments/nowpayments/webhook`

### 4. Test Live Payments
- Start with small amounts ($1-5)
- Test both card and crypto payments
- Verify webhook delivery
- Check success/cancel page flows

## 🔒 Security Measures Implemented

- ✅ API key validation
- ✅ HMAC signature verification
- ✅ Webhook authentication
- ✅ HTTPS enforcement
- ✅ Input sanitization
- ✅ Error logging without exposing keys

## 📊 Monitoring & Analytics

### Payment Tracking
- All payments logged to localStorage (upgrade to DB for production)
- Status updates via webhooks
- Transaction history in dashboard

### Error Monitoring
- Console logging for debugging
- Webhook delivery confirmation
- Payment failure tracking

## 🆘 Troubleshooting

### Common Issues

**Razorpay Payments Failing**
- Check if live keys are correct
- Verify webhook URL is accessible
- Ensure domain is HTTPS enabled

**Crypto Payments Not Processing**
- Verify NOWPayments API key
- Check IPN webhook configuration
- Confirm cryptocurrency is enabled

**Webhook Not Receiving**
- Test webhook URL manually
- Check server logs
- Verify signature secrets

### Support Contacts
- **Razorpay**: [support@razorpay.com](mailto:support@razorpay.com)
- **NOWPayments**: [support@nowpayments.io](mailto:support@nowpayments.io)

## 🎯 Post-Launch Tasks

1. **Monitor First Week**: Watch for payment failures, webhook issues
2. **User Feedback**: Collect payment experience feedback
3. **Performance Check**: Monitor API response times
4. **Security Audit**: Regular security reviews
5. **Backup Setup**: Implement payment data backups

---

## 🎉 You're Ready to Go Live!

Your Beast Browser payment system is now configured for production with:
- ✅ Live Razorpay integration
- ✅ Live NOWPayments crypto support  
- ✅ Webhook processing
- ✅ Success/failure handling
- ✅ Security measures

**Remember to regenerate all API keys for maximum security!**