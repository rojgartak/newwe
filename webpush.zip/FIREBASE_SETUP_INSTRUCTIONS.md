# BeastBrowser Firebase & Stripe Integration Setup

This document provides step-by-step instructions for setting up Firebase and Stripe integrations in your BeastBrowser project.

## 🔥 Firebase Setup

### 1. Create a Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project"
3. Enter project name (e.g., "beastbrowser-production")
4. Choose whether to enable Google Analytics (recommended)
5. Create the project

### 2. Enable Authentication

1. In your Firebase project, go to "Authentication" → "Sign-in method"
2. Enable "Email/Password" authentication
3. Optionally enable other providers (Google, Facebook, etc.)

### 3. Create Firestore Database

1. Go to "Firestore Database" → "Create database"
2. Choose "Start in production mode" for production or "test mode" for development
3. Select a location closest to your users
4. Create the database

### 4. Set up Firebase Configuration

1. Go to "Project settings" → "General" → "Your apps"
2. Click "Add app" → Web app
3. Enter app name (e.g., "BeastBrowser Web")
4. Copy the Firebase configuration object
5. Update your `.env.local` file with the values:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key_here
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID=your_measurement_id
```

### 5. Configure Security Rules

In Firestore, update your security rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Admin can read all users
    match /users/{document=**} {
      allow read: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    
    // Coupons - admin only for write, authenticated users for read
    match /coupons/{document=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    
    // Deposits - users can create their own, admin can read/update all
    match /deposits/{document=**} {
      allow create: if request.auth != null;
      allow read, update: if request.auth != null && 
        (resource.data.userEmail == request.auth.token.email ||
         (exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
          get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin'));
    }
    
    // Referrals - users can read their own, admin can read/write all
    match /referrals/{document=**} {
      allow create: if request.auth != null;
      allow read: if request.auth != null && 
        (resource.data.referrerId == request.auth.uid || 
         resource.data.refereeId == request.auth.uid ||
         (exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
          get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin'));
      allow update: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
  }
}
```

## 💳 Stripe Setup

### 1. Create a Stripe Account

1. Go to [Stripe Dashboard](https://dashboard.stripe.com/)
2. Sign up or log in to your account
3. Activate your account by providing business details

### 2. Get API Keys

1. In Stripe Dashboard, go to "Developers" → "API Keys"
2. Copy your Publishable key and Secret key
3. For webhooks, you'll get a webhook secret later

### 3. Create Products and Prices

1. Go to "Products" in Stripe Dashboard
2. Create two products:
   - **Monthly Premium** ($19.99/month)
   - **Yearly Premium** ($199/year)
3. For each product, create a recurring price
4. Copy the Price IDs

### 4. Set up Webhooks

1. Go to "Developers" → "Webhooks"
2. Click "Add endpoint"
3. Enter your webhook URL: `https://yourdomain.com/api/stripe-webhook`
4. Select events to listen to:
   - `checkout.session.completed`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
   - `customer.subscription.deleted`
5. Copy the webhook signing secret

### 5. Update Environment Variables

Add these to your `.env.local`:

```env
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_your_publishable_key
STRIPE_SECRET_KEY=sk_live_your_secret_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
NEXT_PUBLIC_STRIPE_MONTHLY_PRICE_ID=price_1234567890abcdef
NEXT_PUBLIC_STRIPE_YEARLY_PRICE_ID=price_0987654321fedcba
```

## 🚀 Deployment Checklist

### Firebase
- [ ] Project created and configured
- [ ] Authentication enabled
- [ ] Firestore database created
- [ ] Security rules updated
- [ ] Environment variables set

### Stripe
- [ ] Account activated
- [ ] Products and prices created
- [ ] Webhook endpoint configured
- [ ] Environment variables set
- [ ] Test payments working

### Application
- [ ] Dependencies installed (`npm install`)
- [ ] Environment variables configured
- [ ] Firebase services connected
- [ ] Stripe integration tested
- [ ] Admin panel accessible
- [ ] Coupon system working
- [ ] Referral tracking functional

## 🧪 Testing

### Test Firebase Connection
1. Try signing up a new user
2. Check if user appears in Firestore
3. Test login functionality
4. Verify admin panel access

### Test Stripe Integration
1. Use Stripe test cards (4242 4242 4242 4242)
2. Complete a test purchase
3. Check webhook events in Stripe Dashboard
4. Verify user plan update in Firebase

### Test Referral System
1. Create a user account
2. Get referral link from profile
3. Sign up new user with referral link
4. Check referral tracking in admin panel

## 🔧 Troubleshooting

### Common Firebase Issues
- **Permission denied**: Check Firestore security rules
- **Project not found**: Verify project ID in environment variables
- **Auth errors**: Ensure authentication is enabled

### Common Stripe Issues
- **Invalid API key**: Check if using correct key for environment
- **Webhook errors**: Verify webhook URL and signing secret
- **Payment failures**: Check if using test cards in test mode

### Admin Access
Default admin credentials:
- Email: `admin@beastbrowser.com`
- Password: `Ahmihere786$`

**⚠️ Important**: Change these credentials in production!

## 📝 Additional Notes

1. **Security**: Always use environment variables for sensitive data
2. **Testing**: Use Stripe test mode during development
3. **Monitoring**: Set up logging for Firebase and Stripe events
4. **Backup**: Regularly backup your Firestore data
5. **Updates**: Keep Firebase and Stripe libraries updated

## 🆘 Support

If you encounter issues:
1. Check the console for error messages
2. Verify all environment variables are set correctly
3. Test Firebase and Stripe connections separately
4. Review security rules and permissions

For additional help, contact the development team or create an issue in the project repository.