// Common browser actions that can be tracked:
export const BROWSER_ACTIONS = {
  // Authentication
  BROWSER_LOGIN: 'browser_login',
  BROWSER_LOGOUT: 'browser_logout',

  // Navigation
  PAGE_LOAD: 'page_load',
  NEW_TAB: 'new_tab',
  CLOSE_TAB: 'close_tab',
  SWITCH_TAB: 'switch_tab',

  // Bookmarks
  ADD_BOOKMARK: 'add_bookmark',
  REMOVE_BOOKMARK: 'remove_bookmark',
  ORGANIZE_BOOKMARKS: 'organize_bookmarks',

  // Downloads
  START_DOWNLOAD: 'start_download',
  COMPLETE_DOWNLOAD: 'complete_download',
  CANCEL_DOWNLOAD: 'cancel_download',

  // Search
  SEARCH_QUERY: 'search_query',
  SEARCH_SUGGESTION: 'search_suggestion',

  // Settings
  CHANGE_THEME: 'change_theme',
  UPDATE_SETTINGS: 'update_settings',
  ENABLE_FEATURE: 'enable_feature',
  DISABLE_FEATURE: 'disable_feature',

  // Premium Features
  USE_VPN: 'use_vpn',
  BLOCK_AD: 'block_ad',
  USE_CUSTOM_THEME: 'use_custom_theme',
  SYNC_DATA: 'sync_data',

  // Errors
  PAGE_ERROR: 'page_error',
  BROWSER_CRASH: 'browser_crash',
  FEATURE_ERROR: 'feature_error'
}
