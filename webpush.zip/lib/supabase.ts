import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Server-side client with service role key (only for server-side usage)
export const createSupabaseAdmin = () => {
  if (typeof window !== 'undefined') {
    throw new Error('supabaseAdmin should only be used on the server side')
  }
  
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  
  console.log('Supabase URL:', url)
  console.log('Service Role Key exists:', !!key)
  console.log('Service Role Key length:', key?.length)
  
  if (!url || !key) {
    throw new Error(`Missing Supabase credentials: URL=${!!url}, Key=${!!key}`)
  }
  
  return createClient(url, key)
}

// Database types
export interface User {
  id: string
  email: string
  created_at: string
  subscription_status: 'active' | 'inactive' | 'expired'
  subscription_plan?: 'monthly' | 'yearly'
  subscription_expires_at?: string
  profiles_created: number
  last_login?: string
}

export interface Subscription {
  id: string
  user_id: string
  plan_type: 'monthly' | 'yearly'
  status: 'active' | 'inactive' | 'expired'
  created_at: string
  expires_at: string
  payment_gateway: 'cashfree' | 'phonepe' | 'nowpayments'
  amount: number
  currency: string
}

export interface Payment {
  id: string
  user_id: string
  subscription_id?: string
  amount: number
  currency: string
  status: 'pending' | 'completed' | 'failed'
  payment_gateway: 'cashfree' | 'phonepe' | 'nowpayments'
  gateway_payment_id?: string
  created_at: string
}

export interface ProfileCreation {
  id: string
  user_id: string
  profile_name: string
  created_at: string
  browser_fingerprint?: any
  proxy_settings?: any
}

export interface Coupon {
  id: string
  code: string
  discount_percentage: number
  max_uses: number
  current_uses: number
  expires_at: string
  is_active: boolean
  created_at: string
}