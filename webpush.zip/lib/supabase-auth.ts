import { supabase, createSupabaseAdmin, User } from './supabase'

// Authentication functions
export async function signUp(email: string, password: string) {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    })

    if (error) throw error

    // Create user record in our users table
    if (data.user) {
      await syncUserWithSupabase(data.user.id, email, 'create')
    }

    return { user: data.user, error: null }
  } catch (error: any) {
    return { user: null, error: error.message }
  }
}

export async function signIn(email: string, password: string) {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) throw error

    // Update last login
    if (data.user) {
      await syncUserWithSupabase(data.user.id, email, 'login')
    }

    return { user: data.user, error: null }
  } catch (error: any) {
    return { user: null, error: error.message }
  }
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  return { error }
}

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser()
  return user
}

// Sync user with our database
export async function syncUserWithSupabase(userId: string, email: string, action: 'create' | 'login') {
  try {
    // Use API route for server-side operations
    const response = await fetch('/api/auth/sync-user', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId,
        email,
        action
      })
    })

    if (!response.ok) {
      throw new Error('Failed to sync user')
    }

    return await response.json()
  } catch (error) {
    console.error('Error syncing user:', error)
  }
}

// Check subscription status
export async function checkSubscriptionStatus(userId: string) {
  try {
    // Use API route for server-side operations
    const response = await fetch('/api/auth/check-subscription', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId })
    })

    if (!response.ok) {
      throw new Error('Failed to check subscription')
    }

    return await response.json()
  } catch (error) {
    console.error('Error checking subscription:', error)
    return {
      hasActiveSubscription: false,
      subscriptionPlan: null,
      expiresAt: null,
      message: 'Error checking subscription'
    }
  }
}

// Validate profile creation
export async function validateProfileCreation(userId: string) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/app_5dffd32dcf_validate_subscription`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({ userId })
    })

    if (!response.ok) {
      throw new Error('Failed to validate subscription')
    }

    return await response.json()
  } catch (error) {
    console.error('Error validating profile creation:', error)
    return {
      hasActiveSubscription: false,
      canCreate: false,
      dailyLimit: 0,
      message: 'Error validating subscription'
    }
  }
}

// Create payment
export async function createPhonePePayment(userId: string, planType: string, userEmail: string, amount: number) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/app_5dffd32dcf_phonepe_payment`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        userId,
        planType,
        userEmail,
        amount,
        currency: 'INR'
      })
    })

    if (!response.ok) {
      throw new Error('Failed to create payment')
    }

    return await response.json()
  } catch (error) {
    console.error('Error creating payment:', error)
    return { success: false, error: error instanceof Error ? error.message : String(error) }
  }
}