import { loadStripe, Stripe } from '@stripe/stripe-js'

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
let stripePromise: Promise<Stripe | null>

export const getStripe = () => {
  if (!stripePromise) {
    stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)
  }
  return stripePromise
}

// Price IDs for each plan (you'll get these from Stripe dashboard)
export const STRIPE_PRICE_IDS = {
  'Monthly Premium': process.env.NEXT_PUBLIC_STRIPE_MONTHLY_PRICE_ID || 'price_monthly_premium',
  'Yearly Premium': process.env.NEXT_PUBLIC_STRIPE_YEARLY_PRICE_ID || 'price_yearly_premium'
}

// Server-side Stripe instance (for API routes)
import StripeSDK from 'stripe'

export const stripe = new StripeSDK(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2025-08-27.basil'
})