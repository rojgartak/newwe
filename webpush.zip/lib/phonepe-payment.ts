import crypto from 'crypto'

// PhonePe Configuration
export const PHONEPE_CONFIG = {
  merchantId: process.env.PHONEPE_MERCHANT_ID || 'M23B2P3826HIX',
  saltKey: process.env.PHONEPE_SALT_KEY || 'd75e3df0-791b-48e0-bf6e-89f0161170fb',
  saltIndex: process.env.PHONEPE_SALT_INDEX || '1',
  baseUrl: process.env.PHONEPE_BASE_URL || 'https://api-preprod.phonepe.com/apis/pg-sandbox',
  redirectUrl: `${process.env.NEXT_PUBLIC_APP_URL}/payment/success`,
  callbackUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/phonepe`,
  mode: process.env.NEXT_PUBLIC_PHONEPE_MODE || 'production'
}

// Plan pricing configuration
export const PLAN_PRICES = {
  'Monthly Premium': {
    amount: 100, // ₹1 in paisa
    currency: 'INR'
  },
  'Yearly Premium': {
    amount: 100, // ₹1 in paisa
    currency: 'INR'
  }
}

export interface PhonePePaymentRequest {
  merchantTransactionId: string
  amount: number
  merchantUserId: string
  redirectUrl: string
  redirectMode: string
  callbackUrl: string
  mobileNumber?: string
  paymentInstrument: {
    type: string
  }
}

// Generate PhonePe payment request
export function createPhonePePaymentRequest(
  userId: string,
  planType: 'Monthly Premium' | 'Yearly Premium',
  userEmail: string,
  mobileNumber?: string,
  overrideAmountPaise?: number
): PhonePePaymentRequest {
  const planPrice = PLAN_PRICES[planType]
  const merchantTransactionId = `BB_${userId}_${planType.replace(' ', '_')}_${Date.now()}`
  
  return {
    merchantTransactionId,
    amount: typeof overrideAmountPaise === 'number' && overrideAmountPaise > 0 ? overrideAmountPaise : planPrice.amount,
    merchantUserId: userId,
    redirectUrl: PHONEPE_CONFIG.redirectUrl,
    redirectMode: 'POST',
    callbackUrl: PHONEPE_CONFIG.callbackUrl,
    mobileNumber,
    paymentInstrument: {
      type: 'PAY_PAGE'
    }
  }
}

// Generate PhonePe checksum
export function generatePhonePeChecksum(payload: string, endpoint: string): string {
  const string = payload + endpoint + PHONEPE_CONFIG.saltKey
  const sha256 = crypto.createHash('sha256').update(string).digest('hex')
  return sha256 + '###' + PHONEPE_CONFIG.saltIndex
}

// Create PhonePe payment
export async function initiatePhonePePayment(
  userId: string,
  planType: 'Monthly Premium' | 'Yearly Premium',
  userEmail: string,
  mobileNumber?: string,
  amountPaiseOverride?: number
) {
  try {
    const paymentRequest = createPhonePePaymentRequest(
      userId,
      planType,
      userEmail,
      mobileNumber,
      amountPaiseOverride
    )
    
    const payload = {
      merchantId: PHONEPE_CONFIG.merchantId,
      merchantTransactionId: paymentRequest.merchantTransactionId,
      merchantUserId: paymentRequest.merchantUserId,
      amount: paymentRequest.amount,
      redirectUrl: paymentRequest.redirectUrl,
      redirectMode: paymentRequest.redirectMode,
      callbackUrl: paymentRequest.callbackUrl,
      paymentInstrument: paymentRequest.paymentInstrument
    }

    const base64Payload = Buffer.from(JSON.stringify(payload)).toString('base64')
    const checksum = generatePhonePeChecksum(base64Payload, '/pg/v1/pay')

    const response = await fetch(`${PHONEPE_CONFIG.baseUrl}/pg/v1/pay`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-VERIFY': checksum
      },
      body: JSON.stringify({
        request: base64Payload
      })
    })

    const responseText = await response.text()
    console.log('[PhonePe PAY_PAGE] Response status:', response.status)
    console.log('[PhonePe PAY_PAGE] Response:', responseText)
    
    // Try to parse as JSON
    let result: any
    try {
      result = JSON.parse(responseText)
    } catch (e) {
      // Response is not JSON (e.g., "R006")
      console.error('[PhonePe PAY_PAGE] Non-JSON response:', responseText)
      
      // Map known error codes
      const errorMap: Record<string, string> = {
        'R006': 'Invalid merchant credentials or salt key',
        'R001': 'Transaction declined',
        'R002': 'Insufficient funds',
        'R003': 'Payment method not available',
        'R004': 'Transaction timeout',
        'R005': 'Invalid payment details'
      }
      
      const errorCode = responseText.trim()
      const errorMessage = errorMap[errorCode] || `PhonePe Error: ${errorCode}`
      throw new Error(`${errorMessage} (Code: ${errorCode})`)
    }
    
    if (result.success) {
      return {
        success: true,
        paymentUrl: result.data.instrumentResponse.redirectInfo.url,
        merchantTransactionId: paymentRequest.merchantTransactionId
      }
    } else {
      const errorCode = result.code || 'UNKNOWN'
      const errorMessage = result.message || 'Payment initiation failed'
      throw new Error(`${errorMessage} (Code: ${errorCode})`)
    }

  } catch (error) {
    console.error('PhonePe payment initiation error:', error)
    throw error
  }
}

// Verify PhonePe payment status
export async function verifyPhonePePayment(merchantTransactionId: string) {
  try {
    const endpoint = `/pg/v1/status/${PHONEPE_CONFIG.merchantId}/${merchantTransactionId}`
    const checksum = generatePhonePeChecksum('', endpoint)

    const response = await fetch(`${PHONEPE_CONFIG.baseUrl}${endpoint}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'X-VERIFY': checksum,
        'X-MERCHANT-ID': PHONEPE_CONFIG.merchantId
      }
    })

    const responseText = await response.text()
    
    // Try to parse as JSON
    let result: any
    try {
      result = JSON.parse(responseText)
    } catch (e) {
      console.error('[PhonePe] Status verification non-JSON response:', responseText)
      throw new Error(`Invalid response from PhonePe: ${responseText}`)
    }
    
    return result

  } catch (error) {
    console.error('PhonePe payment verification error:', error)
    throw error
  }
}

// Validate PhonePe webhook signature
export function validatePhonePeWebhook(payload: string, signature: string): boolean {
  try {
    const expectedSignature = crypto
      .createHash('sha256')
      .update(payload + PHONEPE_CONFIG.saltKey)
      .digest('hex') + '###' + PHONEPE_CONFIG.saltIndex

    return signature === expectedSignature
  } catch (error) {
    console.error('Webhook signature validation error:', error)
    return false
  }
}
