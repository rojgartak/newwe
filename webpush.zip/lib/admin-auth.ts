import { supabase } from './supabase'

// Admin email addresses
const ADMIN_EMAILS = [
  'beastbrowser2@beastbrowser.com',
  'admin@beastbrowser.com'
]

export async function isAdminUser(email: string): Promise<boolean> {
  return ADMIN_EMAILS.includes(email.toLowerCase())
}

export async function checkAdminAccess(user: any): Promise<boolean> {
  if (!user || !user.email) return false
  return await isAdminUser(user.email)
}

export async function adminSignIn(email: string, password: string) {
  try {
    // First check if email is admin
    if (!await isAdminUser(email)) {
      throw new Error('Access denied. Admin privileges required.')
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) throw error

    return { user: data.user, error: null }
  } catch (error: any) {
    return { user: null, error: error.message }
  }
}
