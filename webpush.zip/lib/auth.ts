import crypto from 'crypto'
import { cookies } from 'next/headers'

export const COOKIE_NAME = 'admin_session'

function base64url(input: Buffer | string) {
  const b = (input instanceof Buffer ? input : Buffer.from(input))
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
  return b
}

function getSecret() {
  const secret = process.env.ADMIN_SESSION_SECRET || process.env.NEXTAUTH_SECRET || ''
  if (!secret) {
    // For local dev fallback. In production, always set ADMIN_SESSION_SECRET.
    return 'dev-secret-change-me'
  }
  return secret
}

export function signToken(payload: Record<string, any>) {
  const header = { alg: 'HS256', typ: 'JWT' }
  const headerB64 = base64url(JSON.stringify(header))
  const payloadB64 = base64url(JSON.stringify(payload))
  const data = `${headerB64}.${payloadB64}`
  const signature = crypto
    .createHmac('sha256', getSecret())
    .update(data)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
  return `${data}.${signature}`
}

export function verifyToken(token?: string): { valid: boolean; payload?: any } {
  if (!token) return { valid: false }
  const parts = token.split('.')
  if (parts.length !== 3) return { valid: false }
  const [headerB64, payloadB64, signature] = parts
  const data = `${headerB64}.${payloadB64}`
  const expected = crypto
    .createHmac('sha256', getSecret())
    .update(data)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
  if (expected !== signature) return { valid: false }
  try {
    const payload = JSON.parse(Buffer.from(payloadB64.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'))
    if (payload.exp && Date.now() / 1000 > payload.exp) {
      return { valid: false }
    }
    return { valid: true, payload }
  } catch {
    return { valid: false }
  }
}

export function setSessionCookie(email: string) {
  const now = Math.floor(Date.now() / 1000)
  const exp = now + 60 * 60 * 24 // 24 hours
  const token = signToken({ sub: 'admin', email, iat: now, exp })
  cookies().set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24,
  })
}

export function clearSessionCookie() {
  cookies().set(COOKIE_NAME, '', {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 0,
  })
}
