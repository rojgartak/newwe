import crypto from 'crypto'

// NOWPayments API configuration
const NOWPAYMENTS_API_URL = 'https://api.nowpayments.io/v1'

// Always use production API
const API_BASE_URL = NOWPAYMENTS_API_URL

export interface NOWPaymentsPayment {
  payment_id: string
  payment_status: string
  pay_address: string
  price_amount: number
  price_currency: string
  pay_amount: number
  pay_currency: string
  order_id: string
  order_description: string
  purchase_id?: string
  invoice_url?: string
  payment_url?: string
  created_at: string
  updated_at: string
}

export interface CreatePaymentRequest {
  price_amount: number
  price_currency: string
  pay_currency: string
  order_id: string
  order_description: string
  ipn_callback_url: string
  success_url: string
  cancel_url: string
}

export class NOWPaymentsAPI {
  private apiKey: string
  private ipnSecret: string

  constructor() {
    this.apiKey = process.env.NOWPAYMENTS_API_KEY!
    this.ipnSecret = process.env.NOWPAYMENTS_IPN_SECRET!

    if (!this.apiKey || !this.ipnSecret) {
      throw new Error('NOWPayments API key and IPN secret are required')
    }
  }

  private async makeRequest(endpoint: string, method: 'GET' | 'POST' = 'GET', data?: any) {
    const url = `${API_BASE_URL}${endpoint}`
    
    // NOWPayments uses 'x-api-key' header for authentication
    const headers: Record<string, string> = {
      'x-api-key': this.apiKey.trim(), // Trim any whitespace
      'Content-Type': 'application/json'
    }

    console.log('NOWPayments API Request:', {
      url,
      method,
      apiKeyLength: this.apiKey.length,
      apiKeyPreview: this.apiKey.substring(0, 10) + '***', // Show first 10 chars for debugging
      body: data
    })

    const config: RequestInit = {
      method,
      headers
    }

    if (data && method === 'POST') {
      config.body = JSON.stringify(data)
    }

    const response = await fetch(url, config)
    
    if (!response.ok) {
      const errorText = await response.text()
      console.error('NOWPayments API Error Response:', {
        status: response.status,
        statusText: response.statusText,
        body: errorText,
        apiKeyUsed: this.apiKey.substring(0, 10) + '***'
      })
      throw new Error(`NOWPayments API error: ${response.status} - ${errorText}`)
    }

    return await response.json()
  }

  // Get available currencies
  async getAvailableCurrencies() {
    return await this.makeRequest('/currencies')
  }

  // Get minimum payment amount for a currency
  async getMinimumPaymentAmount(currency_from: string, currency_to: string) {
    return await this.makeRequest(`/min-amount?currency_from=${currency_from}&currency_to=${currency_to}`)
  }

  // Create a payment
  async createPayment(paymentData: CreatePaymentRequest): Promise<NOWPaymentsPayment> {
    return await this.makeRequest('/payment', 'POST', paymentData)
  }

  // Create an invoice (recommended for hosted payment page)
  async createInvoice(invoiceData: CreatePaymentRequest): Promise<any> {
    return await this.makeRequest('/invoice', 'POST', invoiceData)
  }

  // Get payment status
  async getPaymentStatus(paymentId: string): Promise<NOWPaymentsPayment> {
    return await this.makeRequest(`/payment/${paymentId}`)
  }

  // Verify IPN signature
  verifyIPNSignature(payload: string, signature: string): boolean {
    const hmac = crypto.createHmac('sha512', this.ipnSecret)
    hmac.update(payload)
    const expectedSignature = hmac.digest('hex')
    
    return crypto.timingSafeEqual(
      Buffer.from(signature, 'hex'),
      Buffer.from(expectedSignature, 'hex')
    )
  }

  // Convert INR to USD (approximate rate for crypto payments)
  convertINRToUSD(inrAmount: number): number {
    // Using approximate exchange rate (1 USD = 83 INR)
    // In production, you should use a real-time exchange rate API
    return Math.round((inrAmount / 83) * 100) / 100
  }

  // Get popular crypto currencies for payments
  getPopularCryptoCurrencies() {
    return [
      { code: 'btc', name: 'Bitcoin', icon: '₿' },
      { code: 'eth', name: 'Ethereum', icon: 'Ξ' },
      { code: 'usdt', name: 'Tether USDT', icon: '₮' },
      { code: 'usdc', name: 'USD Coin', icon: '$' },
      { code: 'ltc', name: 'Litecoin', icon: 'Ł' },
      { code: 'trx', name: 'TRON', icon: 'T' }
    ]
  }
}

// Helper function to generate order ID
export function generateOrderId(userId: string, planType: string): string {
  const timestamp = Date.now()
  return `BB_${userId.substring(0, 8)}_${planType}_${timestamp}`
}

// Helper function to create payment description
export function createPaymentDescription(planType: string, userEmail: string): string {
  return `BeastBrowser ${planType} Plan - ${userEmail}`
}

export const nowPayments = new NOWPaymentsAPI()
