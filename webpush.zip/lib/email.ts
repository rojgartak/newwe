import nodemailer from 'nodemailer'

// SMTP Configuration
export const emailConfig = {
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true', // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER || '', // Your email address
    pass: process.env.SMTP_PASS || '', // Your email password or app password
  },
  tls: {
    rejectUnauthorized: process.env.SMTP_TLS_REJECT_UNAUTHORIZED !== 'false'
  },
  logger: process.env.NODE_ENV === 'development',
  debug: process.env.NODE_ENV === 'development'
}

// Create transporter
export const createTransporter = () => {
  return nodemailer.createTransport(emailConfig)
}

// Email templates
export const emailTemplates = {
  welcome: (userName: string) => ({
    subject: 'Welcome to BeastBrowser! 🎉',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
        <div style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Welcome to BeastBrowser!</h1>
        </div>
        
        <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          <h2 style="color: #1f2937; margin-bottom: 20px;">Hi ${userName},</h2>
          
          <p style="color: #4b5563; line-height: 1.6; margin-bottom: 20px;">
            Thank you for joining BeastBrowser! You now have access to the most advanced anti-detection browsing technology.
          </p>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #1f2937; margin-top: 0;">🚀 What's Next?</h3>
            <ul style="color: #4b5563; line-height: 1.6;">
              <li>Download the BeastBrowser application</li>
              <li>Create your first browser profile</li>
              <li>Start browsing anonymously and securely</li>
              <li>Explore our advanced anti-detection features</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL}/download" style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              Download BeastBrowser
            </a>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; text-align: center; margin-top: 30px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
            Need help? Contact us at <a href="mailto:support@beastbrowser.com" style="color: #ff6b35;">support@beastbrowser.com</a> or 
            <a href="https://wa.me/917991985013" style="color: #25d366;">WhatsApp: +91 79919 85013</a>
          </p>
        </div>
      </div>
    `
  }),

  purchaseConfirmation: (userName: string, planName: string, amount: number) => ({
    subject: `Purchase Confirmation - ${planName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
        <div style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Purchase Confirmation</h1>
        </div>
        
        <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          <h2 style="color: #1f2937; margin-bottom: 20px;">Hi ${userName},</h2>
          
          <p style="color: #4b5563; line-height: 1.6; margin-bottom: 20px;">
            Thank you for your purchase! Your payment is being processed and we'll activate your plan shortly.
          </p>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #1f2937; margin-top: 0;">📋 Purchase Details</h3>
            <table style="width: 100%; color: #4b5563;">
              <tr>
                <td style="padding: 5px 0;"><strong>Plan:</strong></td>
                <td style="text-align: right;">${planName}</td>
              </tr>
              <tr>
                <td style="padding: 5px 0;"><strong>Amount:</strong></td>
                <td style="text-align: right;">$${amount.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px 0;"><strong>Status:</strong></td>
                <td style="text-align: right; color: #f59e0b;">Pending Verification</td>
              </tr>
            </table>
          </div>
          
          <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; border-radius: 0 4px 4px 0;">
            <p style="margin: 0; color: #92400e;">
              <strong>⏳ Next Steps:</strong> Our team is verifying your payment. You'll receive another email once your plan is activated (usually within 2 hours).
            </p>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; text-align: center; margin-top: 30px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
            Questions? Contact us at <a href="mailto:support@beastbrowser.com" style="color: #ff6b35;">support@beastbrowser.com</a> or 
            <a href="https://wa.me/917991985013" style="color: #25d366;">WhatsApp: +91 79919 85013</a>
          </p>
        </div>
      </div>
    `
  }),

  planActivated: (userName: string, planName: string) => ({
    subject: `🎉 Your ${planName} is Now Active!`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Plan Activated! 🎉</h1>
        </div>
        
        <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          <h2 style="color: #1f2937; margin-bottom: 20px;">Hi ${userName},</h2>
          
          <p style="color: #4b5563; line-height: 1.6; margin-bottom: 20px;">
            Great news! Your <strong>${planName}</strong> has been activated and you now have full access to all premium features.
          </p>
          
          <div style="background: #ecfdf5; border-left: 4px solid #10b981; padding: 15px; margin: 20px 0; border-radius: 0 4px 4px 0;">
            <p style="margin: 0; color: #047857;">
              <strong>✅ Your plan is now active!</strong> You can start using all premium features immediately.
            </p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              Go to Dashboard
            </a>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; text-align: center; margin-top: 30px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
            Need help? Contact us at <a href="mailto:support@beastbrowser.com" style="color: #ff6b35;">support@beastbrowser.com</a> or 
            <a href="https://wa.me/917991985013" style="color: #25d366;">WhatsApp: +91 79919 85013</a>
          </p>
        </div>
      </div>
    `
  }),

  contactForm: (formData: any) => ({
    subject: `New Contact Form Submission - ${formData.name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
        <div style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">New Contact Form Submission</h1>
        </div>
        
        <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          <h2 style="color: #1f2937; margin-bottom: 20px;">Contact Details:</h2>
          
          <table style="width: 100%; color: #4b5563; line-height: 1.6;">
            <tr>
              <td style="padding: 8px 0; font-weight: bold; width: 120px;">Name:</td>
              <td style="padding: 8px 0;">${formData.name}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; font-weight: bold;">Email:</td>
              <td style="padding: 8px 0;">${formData.email}</td>
            </tr>
            ${formData.company ? `
            <tr>
              <td style="padding: 8px 0; font-weight: bold;">Company:</td>
              <td style="padding: 8px 0;">${formData.company}</td>
            </tr>
            ` : ''}
            ${formData.demo ? `
            <tr>
              <td style="padding: 8px 0; font-weight: bold;">Demo Requested:</td>
              <td style="padding: 8px 0; color: #059669;">Yes</td>
            </tr>
            ` : ''}
          </table>
          
          <div style="margin-top: 20px;">
            <h3 style="color: #1f2937; margin-bottom: 10px;">Message:</h3>
            <div style="background: #f3f4f6; padding: 15px; border-radius: 6px; color: #4b5563;">
              ${formData.message.replace(/\n/g, '<br>')}
            </div>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; text-align: center; margin-top: 30px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
            Received at ${new Date().toLocaleString()}
          </p>
        </div>
      </div>
    `
  })
}

// Send email function
export const sendEmail = async (to: string, template: any) => {
  try {
    const transporter = createTransporter()
    
    const mailOptions = {
      from: `"BeastBrowser" <${process.env.SMTP_USER}>`,
      to: to,
      subject: template.subject,
      html: template.html,
    }

    const result = await transporter.sendMail(mailOptions)
    console.log('Email sent successfully:', result.messageId)
    return { success: true, messageId: result.messageId }
  } catch (error) {
    console.error('Error sending email:', error)
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' }
  }
}

// Helper functions
export const sendWelcomeEmail = async (email: string, userName: string) => {
  return await sendEmail(email, emailTemplates.welcome(userName))
}

export const sendPurchaseConfirmation = async (email: string, userName: string, planName: string, amount: number) => {
  return await sendEmail(email, emailTemplates.purchaseConfirmation(userName, planName, amount))
}

export const sendPlanActivatedEmail = async (email: string, userName: string, planName: string) => {
  return await sendEmail(email, emailTemplates.planActivated(userName, planName))
}

export const sendContactFormEmail = async (adminEmail: string, formData: any) => {
  return await sendEmail(adminEmail, emailTemplates.contactForm(formData))
}