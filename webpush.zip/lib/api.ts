export const API_BASE = process.env.NEXT_PUBLIC_API_BASE || ''

export function apiFetch(path: string, init?: RequestInit) {
  const base = API_BASE.replace(/\/$/, '')
  const full = base ? `${base}${path}` : path
  return fetch(full, init)
}