// PhonePe Autopay (OAuth-based Subscription) Integration

export const PHONEPE_AUTOPAY_CONFIG = {
  clientId: process.env.PHONEPE_CLIENT_ID || '',
  clientVersion: process.env.PHONEPE_CLIENT_VERSION || '1',
  clientSecret: process.env.PHONEPE_CLIENT_SECRET || '',
  merchantId: process.env.PHONEPE_MERCHANT_ID || '',
  baseUrl: process.env.PHONEPE_BASE_URL || 'https://api.phonepe.com/apis/hermes',
  mode: process.env.NEXT_PUBLIC_PHONEPE_MODE || 'production'
}

// Plan pricing in paise (₹1 = 100 paise)
export const AUTOPAY_PLAN_PRICES = {
  'Monthly Premium': {
    amount: 255000, // ₹2,550
    maxAmount: 300000, // ₹3,000 max
    frequency: 'MONTHLY' as const
  },
  'Yearly Premium': {
    amount: 2116500, // ₹21,165
    maxAmount: 2500000, // ₹25,000 max
    frequency: 'YEARLY' as const
  }
}

interface TokenResponse {
  access_token: string
  expires_at: number
  token_type: string
}

// Step 1: Get OAuth Access Token
export async function getPhonePeToken(): Promise<string> {
  try {
    const formData = new URLSearchParams()
    formData.append('client_id', PHONEPE_AUTOPAY_CONFIG.clientId)
    formData.append('client_version', PHONEPE_AUTOPAY_CONFIG.clientVersion)
    formData.append('client_secret', PHONEPE_AUTOPAY_CONFIG.clientSecret)
    formData.append('grant_type', 'client_credentials')

    console.log('Requesting PhonePe OAuth token...')
    
    const response = await fetch(`${PHONEPE_AUTOPAY_CONFIG.baseUrl}/v1/oauth/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: formData.toString()
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Token request failed: ${response.status} - ${errorText}`)
    }

    const data: TokenResponse = await response.json()
    console.log('PhonePe token obtained successfully')
    return data.access_token

  } catch (error) {
    console.error('PhonePe token generation error:', error)
    throw error
  }
}

// Step 2: Setup Subscription (Mandate Creation)
export async function setupPhonePeSubscription(
  planType: 'Monthly Premium' | 'Yearly Premium',
  userEmail: string,
  userId: string
) {
  try {
    const token = await getPhonePeToken()
    const plan = AUTOPAY_PLAN_PRICES[planType]
    
    const merchantOrderId = `ORDER_${userId.substring(0, 8)}_${Date.now()}`
    const merchantSubscriptionId = `SUBS_${userId.substring(0, 8)}_${Date.now()}`
    
    const payload = {
      merchantOrderId,
      amount: plan.amount,
      expireAt: Date.now() + (10 * 60 * 1000), // 10 minutes
      paymentFlow: {
        type: 'SUBSCRIPTION_SETUP',
        merchantSubscriptionId,
        authWorkflowType: 'TRANSACTION',
        amountType: 'FIXED',
        maxAmount: plan.maxAmount,
        frequency: plan.frequency,
        expireAt: Date.now() + (365 * 24 * 60 * 60 * 1000 * 30), // 30 years
        paymentMode: {
          type: 'UPI_INTENT',
          targetApp: 'com.phonepe.app'
        }
      },
      deviceContext: {
        deviceOS: 'ANDROID'
      },
      metaInfo: {
        udf1: userEmail,
        udf2: planType
      }
    }

    console.log('Setting up PhonePe subscription...', merchantSubscriptionId)

    const response = await fetch(`${PHONEPE_AUTOPAY_CONFIG.baseUrl}/subscriptions/v2/setup`, {
      method: 'POST',
      headers: {
        'Authorization': `O-Bearer ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(payload)
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Subscription setup failed: ${response.status} - ${errorText}`)
    }

    const result = await response.json()
    
    return {
      success: true,
      orderId: result.orderId,
      subscriptionId: merchantSubscriptionId,
      intentUrl: result.intentUrl,
      state: result.state,
      merchantOrderId
    }

  } catch (error) {
    console.error('PhonePe subscription setup error:', error)
    throw error
  }
}

// Step 3: Notify for Redemption (Recurring Payment)
export async function notifyPhonePeRedemption(
  subscriptionId: string,
  amount: number
) {
  try {
    const token = await getPhonePeToken()
    const merchantOrderId = `REDEEM_${Date.now()}`
    
    const payload = {
      merchantOrderId,
      amount,
      expireAt: Date.now() + (48 * 60 * 60 * 1000), // 48 hours
      paymentFlow: {
        type: 'SUBSCRIPTION_REDEMPTION',
        merchantSubscriptionId: subscriptionId,
        redemptionRetryStrategy: 'STANDARD',
        autoDebit: false
      }
    }

    const response = await fetch(`${PHONEPE_AUTOPAY_CONFIG.baseUrl}/subscriptions/v2/notify`, {
      method: 'POST',
      headers: {
        'Authorization': `O-Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    })

    const result = await response.json()
    return { success: true, orderId: result.orderId, merchantOrderId }

  } catch (error) {
    console.error('PhonePe notify error:', error)
    throw error
  }
}

// Step 4: Execute Redemption
export async function executePhonePeRedemption(merchantOrderId: string) {
  try {
    const token = await getPhonePeToken()
    
    const payload = { merchantOrderId }

    const response = await fetch(`${PHONEPE_AUTOPAY_CONFIG.baseUrl}/subscriptions/v2/redeem`, {
      method: 'POST',
      headers: {
        'Authorization': `O-Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    })

    const result = await response.json()
    return result

  } catch (error) {
    console.error('PhonePe execute error:', error)
    throw error
  }
}

// Check Subscription Status
export async function checkPhonePeSubscriptionStatus(subscriptionId: string) {
  try {
    const token = await getPhonePeToken()

    const response = await fetch(
      `${PHONEPE_AUTOPAY_CONFIG.baseUrl}/subscriptions/v2/${subscriptionId}/status`,
      {
        method: 'GET',
        headers: {
          'Authorization': `O-Bearer ${token}`,
          'Accept': 'application/json'
        }
      }
    )

    const result = await response.json()
    return result

  } catch (error) {
    console.error('PhonePe status check error:', error)
    throw error
  }
}

// Cancel Subscription
export async function cancelPhonePeSubscription(subscriptionId: string) {
  try {
    const token = await getPhonePeToken()

    const response = await fetch(
      `${PHONEPE_AUTOPAY_CONFIG.baseUrl}/subscriptions/v2/${subscriptionId}/cancel`,
      {
        method: 'POST',
        headers: {
          'Authorization': `O-Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    )

    const result = await response.json()
    return result

  } catch (error) {
    console.error('PhonePe cancel error:', error)
    throw error
  }
}
