// Payment Gateway Configuration
export const PAYMENT_CONFIG = {
  nowPayments: {
    apiKey: process.env.NOWPAYMENTS_API_KEY || 'HFDTB8Q-5C8404Z-QY4M71K-YFXS71G',
    sandboxMode: false,
    baseUrl: 'https://api.nowpayments.io/v1',
    ipnSecret: process.env.NOWPAYMENTS_IPN_SECRET || 'bkunUu0IbHHaKW0DbZjFIcUw/WXFtNzn',
    currencies: [
      'USDTTRC20', 'USDTERC20', 'BTC', 'ETH', 'LTC', 'BCH', 
      'XRP', 'ADA', 'DOT', 'USDC', 'DAI', 'BUSD'
    ],
    callbackUrls: {
      success: `${process.env.NEXT_PUBLIC_APP_URL}/payment/success`,
      cancel: `${process.env.NEXT_PUBLIC_APP_URL}/payment/cancel`,
    }
  }
}

// Plan pricing configuration
export const PLAN_PRICES = {
  'Monthly Premium': {
    usd: 30.00,
    inr: 2550
  },
  'Yearly Premium': {
    usd: 249,
    inr: 21165
  }
}

// Payment method types
export type PaymentMethod = 'phonepe' | 'crypto'

export interface PaymentData {
  planName: string
  amount: number
  originalAmount?: number
  discountAmount?: number
  couponCode?: string | null
  currency: string
  userEmail: string
  userName: string
  userPhone?: string
  method: PaymentMethod
}

// PhonePe payment creation
export async function createPhonePePayment(data: PaymentData) {
  try {
    const response = await fetch('/api/payments/phonepe/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    return await response.json()
  } catch (error) {
    console.error('PhonePe payment creation failed:', error)
    throw error
  }
}

// NOWPayments payment creation
export async function createCryptoPayment(data: PaymentData) {
  try {
    const response = await fetch('/api/payments/nowpayments/create-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    return await response.json()
  } catch (error) {
    console.error('Crypto payment creation failed:', error)
    throw error
  }
}

// Payment verification
export async function verifyPayment(paymentId: string, method: PaymentMethod) {
  try {
    const endpoint = '/api/payments/nowpayments/verify'
    
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentId })
    })
    return await response.json()
  } catch (error) {
    console.error('Payment verification failed:', error)
    throw error
  }
}

// Format currency for display
export function formatCurrency(amount: number, currency: string = 'USD'): string {
  if (currency === 'INR') {
    return `₹${amount.toLocaleString('en-IN')}`
  }
  return `$${amount.toFixed(2)}`
}

// Get payment method display name
export function getPaymentMethodName(method: PaymentMethod): string {
  switch (method) {
    case 'phonepe':
      return 'UPI/Card/NetBanking'
    case 'crypto':
      return 'Cryptocurrency'
    default:
      return method
  }
}