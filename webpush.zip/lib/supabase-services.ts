import { supabase, createSupabaseAdmin, User, Subscription, Payment, ProfileCreation, Coupon } from './supabase'

const supabaseAdmin = createSupabaseAdmin()

// User Management Services
export const userService = {
  // Get user by ID
  async getUser(userId: string): Promise<User | null> {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single()
    
    if (error) {
      console.error('Error fetching user:', error)
      return null
    }
    return data
  },

  // Create new user
  async createUser(userData: Partial<User>): Promise<User | null> {
    const { data, error } = await supabaseAdmin
      .from('users')
      .insert(userData)
      .select()
      .single()
    
    if (error) {
      console.error('Error creating user:', error)
      return null
    }
    return data
  },

  // Update user subscription status
  async updateSubscriptionStatus(userId: string, status: string, expiresAt?: string): Promise<boolean> {
    const updateData: any = { subscription_status: status }
    if (expiresAt) updateData.subscription_expires_at = expiresAt

    const { error } = await supabaseAdmin
      .from('users')
      .update(updateData)
      .eq('id', userId)
    
    if (error) {
      console.error('Error updating subscription status:', error)
      return false
    }
    return true
  },

  // Increment profile count
  async incrementProfileCount(userId: string): Promise<boolean> {
    const { error } = await supabaseAdmin
      .rpc('increment_profile_count', { user_id: userId })
    
    if (error) {
      console.error('Error incrementing profile count:', error)
      return false
    }
    return true
  }
}

// Subscription Management Services
export const subscriptionService = {
  // Get active subscription for user
  async getActiveSubscription(userId: string): Promise<Subscription | null> {
    const { data, error } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('user_id', userId)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(1)
      .single()
    
    if (error) {
      console.error('Error fetching subscription:', error)
      return null
    }
    return data
  },

  // Create new subscription
  async createSubscription(subscriptionData: Partial<Subscription>): Promise<Subscription | null> {
    const { data, error } = await supabaseAdmin
      .from('subscriptions')
      .insert(subscriptionData)
      .select()
      .single()
    
    if (error) {
      console.error('Error creating subscription:', error)
      return null
    }
    return data
  },

  // Check if subscription is expired and update status
  async checkAndUpdateExpiredSubscriptions(): Promise<void> {
    const { error } = await supabaseAdmin
      .from('subscriptions')
      .update({ status: 'expired' })
      .lt('expires_at', new Date().toISOString())
      .eq('status', 'active')
    
    if (error) {
      console.error('Error updating expired subscriptions:', error)
    }
  }
}

// Payment Management Services
export const paymentService = {
  // Create payment record
  async createPayment(paymentData: Partial<Payment>): Promise<Payment | null> {
    const { data, error } = await supabaseAdmin
      .from('payments')
      .insert(paymentData)
      .select()
      .single()
    
    if (error) {
      console.error('Error creating payment:', error)
      return null
    }
    return data
  },

  // Update payment status
  async updatePaymentStatus(paymentId: string, status: string, gatewayPaymentId?: string): Promise<boolean> {
    const updateData: any = { status }
    if (gatewayPaymentId) updateData.gateway_payment_id = gatewayPaymentId

    const { error } = await supabaseAdmin
      .from('payments')
      .update(updateData)
      .eq('id', paymentId)
    
    if (error) {
      console.error('Error updating payment status:', error)
      return false
    }
    return true
  },

  // Get payment by gateway ID
  async getPaymentByGatewayId(gatewayPaymentId: string): Promise<Payment | null> {
    const { data, error } = await supabase
      .from('payments')
      .select('*')
      .eq('gateway_payment_id', gatewayPaymentId)
      .single()
    
    if (error) {
      console.error('Error fetching payment:', error)
      return null
    }
    return data
  }
}

// Profile Management Services
export const profileService = {
  // Create profile record
  async createProfile(profileData: Partial<ProfileCreation>): Promise<ProfileCreation | null> {
    const { data, error } = await supabaseAdmin
      .from('profile_creations')
      .insert(profileData)
      .select()
      .single()
    
    if (error) {
      console.error('Error creating profile:', error)
      return null
    }
    return data
  },

  // Get user profiles
  async getUserProfiles(userId: string): Promise<ProfileCreation[]> {
    const { data, error } = await supabase
      .from('profile_creations')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
    
    if (error) {
      console.error('Error fetching profiles:', error)
      return []
    }
    return data || []
  },

  // Get profiles count for today
  async getTodayProfilesCount(userId: string): Promise<number> {
    const today = new Date().toISOString().split('T')[0]
    
    const { count, error } = await supabase
      .from('profile_creations')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .gte('created_at', `${today}T00:00:00.000Z`)
      .lt('created_at', `${today}T23:59:59.999Z`)
    
    if (error) {
      console.error('Error counting today profiles:', error)
      return 0
    }
    return count || 0
  }
}

// Coupon Management Services
export const couponService = {
  // Validate coupon
  async validateCoupon(code: string): Promise<Coupon | null> {
    const { data, error } = await supabase
      .from('coupons')
      .select('*')
      .eq('code', code.toUpperCase())
      .eq('is_active', true)
      .gt('expires_at', new Date().toISOString())
      .single()
    
    if (error) {
      console.error('Error validating coupon:', error)
      return null
    }

    // Check if coupon has reached max uses
    if (data && data.current_uses >= data.max_uses) {
      return null
    }

    return data
  },

  // Use coupon (increment usage count)
  async useCoupon(couponId: string): Promise<boolean> {
    const { error } = await supabaseAdmin
      .rpc('increment_coupon_usage', { coupon_id: couponId })
    
    if (error) {
      console.error('Error using coupon:', error)
      return false
    }
    return true
  }
}

// Webhook Logging Service
export const webhookService = {
  // Log webhook event
  async logWebhook(gateway: string, eventType: string, payload: any, status: string): Promise<void> {
    const { error } = await supabaseAdmin
      .from('webhook_logs')
      .insert({
        gateway,
        event_type: eventType,
        payload,
        status,
        created_at: new Date().toISOString()
      })
    
    if (error) {
      console.error('Error logging webhook:', error)
    }
  }
}
