import { NextRequest, NextResponse } from 'next/server'

// Browser API configuration
export const BROWSER_API_CONFIG = {
  apiKey: process.env.BROWSER_API_KEY || 'beast-browser-api-key-2024',
  jwtSecret: process.env.JWT_SECRET || 'beast-browser-jwt-secret-key-2024',
  rateLimit: parseInt(process.env.BROWSER_API_RATE_LIMIT || '100'),
  tokenExpiry: '30d'
}

// Validate browser API key
export function validateBrowserApiKey(request: NextRequest): boolean {
  const apiKey = request.headers.get('x-api-key') || request.headers.get('x-browser-api-key')
  
  if (!apiKey) {
    console.warn('Browser API: Missing API key')
    return false
  }

  if (apiKey !== BROWSER_API_CONFIG.apiKey) {
    console.warn('Browser API: Invalid API key')
    return false
  }

  return true
}

// Create browser API error response
export function createBrowserApiError(error: string, status: number = 401) {
  return NextResponse.json(
    { 
      success: false, 
      error: error,
      code: 'BROWSER_API_ERROR'
    },
    { status }
  )
}

// Validate browser API request
export function validateBrowserApiRequest(request: NextRequest): NextResponse | null {
  // Check API key
  if (!validateBrowserApiKey(request)) {
    return createBrowserApiError('Invalid or missing API key', 401)
  }

  // Check user agent (optional)
  const userAgent = request.headers.get('user-agent') || ''
  if (!userAgent.includes('BeastBrowser') && !userAgent.includes('Mozilla')) {
    console.warn('Browser API: Suspicious user agent:', userAgent)
    // Don't block, just log for monitoring
  }

  // Check rate limiting (basic implementation)
  const clientIP = request.headers.get('x-forwarded-for') || 'unknown'
  if (!checkRateLimit(clientIP)) {
    return createBrowserApiError('Rate limit exceeded', 429)
  }

  return null // Valid request
}

// Simple rate limiting (in production, use Redis or similar)
const rateLimitStore = new Map<string, { count: number, resetTime: number }>()

function checkRateLimit(clientIP: string): boolean {
  const now = Date.now()
  const windowSize = 60 * 1000 // 1 minute
  const limit = BROWSER_API_CONFIG.rateLimit

  const current = rateLimitStore.get(clientIP)
  
  if (!current || now > current.resetTime) {
    // First request or window expired
    rateLimitStore.set(clientIP, { count: 1, resetTime: now + windowSize })
    return true
  }

  if (current.count >= limit) {
    return false // Rate limit exceeded
  }

  current.count++
  rateLimitStore.set(clientIP, current)
  return true
}

// Clean up old rate limit entries (call periodically)
export function cleanupRateLimit() {
  const now = Date.now()
  for (const [ip, data] of Array.from(rateLimitStore.entries())) {
    if (now > data.resetTime) {
      rateLimitStore.delete(ip)
    }
  }
}

// Set up cleanup interval
if (typeof window === 'undefined') {
  setInterval(cleanupRateLimit, 5 * 60 * 1000) // Clean every 5 minutes
}

// Generate secure browser API key
export function generateBrowserApiKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
  let result = 'beast-browser-'

  for (let i = 0; i < 32; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }

  return result
}

// Verify browser token (simplified JWT verification)
export function verifyBrowserToken(token: string): any {
  try {
    // In production, use proper JWT library
    const parts = token.split('.')
    if (parts.length !== 3) {
      return null
    }

    const payload = JSON.parse(atob(parts[1]))
    
    // Check expiration
    if (payload.exp && Date.now() >= payload.exp * 1000) {
      return null
    }

    // Check if it's a browser token
    if (!payload.browserAuth) {
      return null
    }

    return payload
  } catch (error) {
    console.error('Token verification error:', error)
    return null
  }
}

// Browser API response helpers
export const BrowserApiResponse = {
  success: (data: any) => NextResponse.json({ success: true, ...data }),
  error: (error: string, status: number = 400) => createBrowserApiError(error, status),
  unauthorized: (error: string = 'Unauthorized') => createBrowserApiError(error, 401),
  forbidden: (error: string = 'Forbidden') => createBrowserApiError(error, 403),
  notFound: (error: string = 'Not found') => createBrowserApiError(error, 404),
  rateLimit: (error: string = 'Rate limit exceeded') => createBrowserApiError(error, 429),
  serverError: (error: string = 'Internal server error') => createBrowserApiError(error, 500)
}