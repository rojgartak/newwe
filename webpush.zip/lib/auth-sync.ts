// Firebase to Supabase sync utility
import { User } from './supabase'

export async function syncUserWithSupabase(user: User, action: 'create' | 'login') {
  try {
    const response = await fetch('/api/auth/supabase-sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId: user.id,
        email: user.email,
        action: action
      })
    })

    const result = await response.json()
    
    if (!response.ok) {
      console.error('Supabase sync failed:', result.error)
      return false
    }

    console.log('User synced with Supabase:', result.user)
    return true

  } catch (error) {
    console.error('Error syncing with Supabase:', error)
    return false
  }
}

export async function checkUserSubscription(userId: string) {
  try {
    const response = await fetch(`/api/user/subscription?userId=${userId}`)
    const result = await response.json()
    
    if (!response.ok) {
      console.error('Subscription check failed:', result.error)
      return null
    }

    return result

  } catch (error) {
    console.error('Error checking subscription:', error)
    return null
  }
}
