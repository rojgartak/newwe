// PhonePe Standard Checkout Integration (Official)

export const PHONEPE_CONFIG = {
  clientId: process.env.PHONEPE_CLIENT_ID || 'SU2510091201043004659155',
  clientVersion: process.env.PHONEPE_CLIENT_VERSION || '1',
  clientSecret: process.env.PHONEPE_CLIENT_SECRET || 'd75e3df0-791b-48e0-bf6e-89f0161170fb',
  merchantId: process.env.PHONEPE_MERCHANT_ID || 'M23B2P3826HIX',
  // Production URLs as per PhonePe docs
  authUrl: process.env.PHONEPE_AUTH_URL || 'https://api.phonepe.com/apis/identity-manager',
  apiUrl: process.env.PHONEPE_API_URL || 'https://api.phonepe.com/apis/pg',
  mode: process.env.NEXT_PUBLIC_PHONEPE_MODE || 'production'
}

// Plan pricing in paise (₹1 = 100 paise) - ONLY FOR FALLBACK
export const PHONEPE_PLAN_PRICES = {
  'Monthly Premium': {
    amount: 100000, // ₹1,000 fallback (should never be used)
    currency: 'INR'
  },
  'Yearly Premium': {
    amount: 500000, // ₹5,000 fallback (should never be used)
    currency: 'INR'
  }
}

interface TokenResponse {
  access_token: string
  expires_at: number
  token_type: string
}

interface PaymentResponse {
  orderId: string
  state: string
  expireAt: number
  redirectUrl: string
}

// Step 1: Generate Authorization Token
export async function getPhonePeAuthToken(): Promise<string> {
  try {
    const formData = new URLSearchParams()
    formData.append('client_id', PHONEPE_CONFIG.clientId)
    formData.append('client_version', PHONEPE_CONFIG.clientVersion)
    formData.append('client_secret', PHONEPE_CONFIG.clientSecret)
    formData.append('grant_type', 'client_credentials')

    console.log('Requesting PhonePe OAuth token...')
    console.log('Auth URL:', `${PHONEPE_CONFIG.authUrl}/v1/oauth/token`)
    
    const response = await fetch(`${PHONEPE_CONFIG.authUrl}/v1/oauth/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: formData.toString()
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('[PhonePe] Token request failed:', response.status, errorText)
      
      // Try to parse as JSON, fallback to plain text
      let errorMessage = errorText
      try {
        const errorJson = JSON.parse(errorText)
        errorMessage = errorJson.message || errorJson.error || errorText
      } catch (e) {
        // errorText is already plain text, use as-is
      }
      
      throw new Error(`Token request failed: ${response.status} - ${errorMessage}`)
    }

    const data: TokenResponse = await response.json()
    console.log('PhonePe token obtained successfully')
    return data.access_token

  } catch (error) {
    console.error('PhonePe token generation error:', error)
    throw error
  }
}

// Step 2: Create Payment Request
export async function createPhonePePayment(
  planType: 'Monthly Premium' | 'Yearly Premium',
  userEmail: string,
  userId: string,
  finalAmount: number, // MANDATORY - no fallback to plan amount
  couponCode?: string
) {
  try {
    const token = await getPhonePeAuthToken()
    const plan = PHONEPE_PLAN_PRICES[planType]
    
    const merchantOrderId = `BB_${userId.substring(0, 8)}_${Date.now()}`
    
    // CRITICAL: Handle special cases
    if (!finalAmount || finalAmount < 0) {
      throw new Error('Valid final amount is required! Plan amount should not be used.')
    }
    
    // Special case: 100% discount (₹0) - set minimum amount ₹1
    if (finalAmount === 0) {
      console.log('🎉 100% DISCOUNT APPLIED! Setting minimum amount ₹1')
      finalAmount = 100 // ₹1 in paise
    }
    
    const paymentAmount = finalAmount
    
    console.log('=== PAYMENT AMOUNT DEBUG ===')
    console.log('Plan Type:', planType)
    console.log('Final Amount Passed (paise):', finalAmount)
    console.log('Payment Amount Used (paise):', paymentAmount)
    console.log('Payment Amount (₹):', paymentAmount / 100)
    console.log('Coupon Applied:', couponCode || 'None')
    
    const payload = {
      merchantOrderId,
      amount: paymentAmount, // Always use the correct amount
      expireAfter: 1200, // 20 minutes
      deviceContext: {
        deviceOS: 'WEB',
        platform: 'WEB'
      },
      metaInfo: {
        udf1: userEmail,
        udf2: planType,
        udf3: userId,
        udf4: 'BeastBrowser',
        udf5: couponCode || 'no-coupon'
      },
      paymentFlow: {
        type: 'PG_CHECKOUT',
        message: `Payment for ${planType}${couponCode ? ` (Coupon: ${couponCode})` : ''}`,
        merchantUrls: {
          redirectUrl: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3002'}/success?session_id=payment_success`
        }
      }
      ,
      // Force-show critical instruments so UPI ID and QR are visible
      paymentModeConfig: {
        enabledPaymentModes: [
          { type: 'UPI_INTENT' },
          { type: 'UPI_COLLECT' },
          { type: 'UPI_QR' },
          { type: 'NET_BANKING' },
          { type: 'CARD', cardTypes: ['DEBIT_CARD', 'CREDIT_CARD'] }
        ]
      }
    }

    console.log('Creating PhonePe payment...', merchantOrderId)
    console.log('Payment Amount (paise):', paymentAmount)
    console.log('Payment Amount (₹):', paymentAmount / 100)
    console.log('Coupon Code:', couponCode)
    console.log('API URL:', `${PHONEPE_CONFIG.apiUrl}/checkout/v2/pay`)
    console.log('Full Payload:', JSON.stringify(payload, null, 2))

  const response = await fetch(`${PHONEPE_CONFIG.apiUrl}/checkout/v2/pay`, {
      method: 'POST',
      headers: {
        'Authorization': `O-Bearer ${token}`,
      'Content-Type': 'application/json',
      // Needed for partner integrations; harmless for direct merchant
      'X-MERCHANT-ID': PHONEPE_CONFIG.merchantId,
      // Some merchants require this header
      'X-PARTNER-ID': PHONEPE_CONFIG.merchantId
      },
      body: JSON.stringify(payload)
    })

    const responseText = await response.text()
    
    if (!response.ok) {
      console.error('[PhonePe] Payment creation failed:', response.status, responseText)
      
      // Try to parse error as JSON, fallback to plain text
      let errorCode = 'UNKNOWN_ERROR'
      let errorMessage = responseText
      
      try {
        const errorJson = JSON.parse(responseText)
        errorCode = errorJson.code || errorJson.errorCode || errorCode
        errorMessage = errorJson.message || errorJson.error || responseText
      } catch (e) {
        // Response is plain text (e.g., "R006")
        errorCode = responseText.trim()
        
        // Map known PhonePe error codes to user-friendly messages
        const errorMap: Record<string, string> = {
          'R006': 'Invalid merchant credentials or signature. Please contact support.',
          'R001': 'Transaction declined by user.',
          'R002': 'Insufficient funds.',
          'R003': 'Payment method not available.',
          'R004': 'Transaction timeout.',
          'R005': 'Invalid payment details.'
        }
        
        errorMessage = errorMap[errorCode] || `PhonePe Error: ${errorCode}`
      }
      
      throw new Error(`Payment creation failed (${errorCode}): ${errorMessage}`)
    }

    // Parse successful response
    let result: PaymentResponse
    try {
      result = JSON.parse(responseText)
    } catch (e) {
      console.error('[PhonePe] Invalid JSON response:', responseText)
      throw new Error('Invalid response from PhonePe API')
    }
    
    return {
      success: true,
      orderId: result.orderId,
      merchantOrderId,
      redirectUrl: result.redirectUrl,
      state: result.state,
      expireAt: result.expireAt
    }

  } catch (error) {
    console.error('PhonePe payment creation error:', error)
    throw error
  }
}

// Step 3: Check Payment Status
export async function checkPhonePePaymentStatus(merchantOrderId: string) {
  try {
    const token = await getPhonePeAuthToken()

    const response = await fetch(
      `${PHONEPE_CONFIG.apiUrl}/checkout/v2/order/${merchantOrderId}/status?details=false`,
      {
        method: 'GET',
        headers: {
          'Authorization': `O-Bearer ${token}`,
          'Content-Type': 'application/json',
          // For partner integrations
          'X-MERCHANT-ID': PHONEPE_CONFIG.merchantId
        }
      }
    )

    const responseText = await response.text()
    
    if (!response.ok) {
      console.error('[PhonePe] Status check failed:', response.status, responseText)
      
      let errorMessage = responseText
      try {
        const errorJson = JSON.parse(responseText)
        errorMessage = errorJson.message || errorJson.error || responseText
      } catch (e) {
        // Plain text error
      }
      
      throw new Error(`Status check failed: ${response.status} - ${errorMessage}`)
    }

    let result
    try {
      result = JSON.parse(responseText)
    } catch (e) {
      console.error('[PhonePe] Invalid JSON response:', responseText)
      throw new Error('Invalid response from PhonePe API')
    }
    return result

  } catch (error) {
    console.error('PhonePe status check error:', error)
    throw error
  }
}

// Validate PhonePe webhook (SHA256 hash verification)
export function validatePhonePeWebhook(
  payload: string, 
  authHeader: string, 
  webhookUsername: string, 
  webhookPassword: string
): boolean {
  try {
    const crypto = require('crypto')
    const expectedHash = crypto
      .createHash('sha256')
      .update(`${webhookUsername}:${webhookPassword}`)
      .digest('hex')

    // Extract hash from Authorization header
    const receivedHash = authHeader.replace('SHA256 ', '')
    
    return expectedHash === receivedHash

  } catch (error) {
    console.error('Webhook validation error:', error)
    return false
  }
}
