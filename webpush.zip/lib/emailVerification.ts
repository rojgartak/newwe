import { sendEmail } from './email'

// Generate random 6-digit code
export const generateVerificationCode = (): string => {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// In-memory store (persist across dev hot-reloads using globalThis).
// In production, replace with a real datastore (Redis/DB) because serverless
// functions don't share memory between invocations.
export type VerificationEntry = { code: string; expires: number; attempts: number; createdAt: number }

const getStore = (): Map<string, VerificationEntry> => {
  const g = globalThis as any
  if (!g.__verificationCodes) {
    g.__verificationCodes = new Map<string, VerificationEntry>()
  }
  return g.__verificationCodes as Map<string, VerificationEntry>
}

const verificationCodes = getStore()

// Send verification email
export const sendVerificationEmail = async (email: string): Promise<{ success: boolean, error?: string }> => {
  try {
    const code = generateVerificationCode()
    const now = Date.now()
    const expires = now + (10 * 60 * 1000) // 10 minutes
    
    // Store code with expiration and attempt tracking
    verificationCodes.set(email.toLowerCase(), {
      code,
      expires,
      attempts: 0,
      createdAt: now,
    })

    const template = {
      subject: 'Verify Your Email - BeastBrowser',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
          <div style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
            <h1 style="color: white; margin: 0; font-size: 28px;">Email Verification</h1>
          </div>
          
          <div style="background: white; padding: 40px 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div style="text-align: center;">
              <h2 style="color: #1f2937; margin-bottom: 20px;">Verify Your Email Address</h2>
              
              <p style="color: #4b5563; line-height: 1.6; margin-bottom: 30px; font-size: 16px;">
                Please enter the verification code below to confirm your email address:
              </p>
              
              <div style="background: #f8f9fa; border: 2px dashed #dee2e6; border-radius: 8px; padding: 30px; margin: 30px 0;">
                <p style="color: #6c757d; font-size: 14px; margin-bottom: 10px;">Your verification code is:</p>
                <div style="font-size: 36px; font-weight: bold; color: #ff6b35; font-family: 'Courier New', monospace; letter-spacing: 8px;">
                  ${code}
                </div>
              </div>
              
              <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 0 4px 4px 0; text-align: left;">
                <p style="margin: 0; color: #856404; font-size: 14px;">
                  <strong>⏰ Important:</strong> This code will expire in <strong>10 minutes</strong>. If you didn't request this verification, please ignore this email.
                </p>
              </div>
              
              <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 30px 0; text-align: left;">
                <h3 style="color: #1f2937; margin-top: 0; font-size: 16px;">🔐 Security Tips:</h3>
                <ul style="color: #4b5563; line-height: 1.6; font-size: 14px; margin: 0; padding-left: 20px;">
                  <li>Never share this code with anyone</li>
                  <li>BeastBrowser staff will never ask for this code</li>
                  <li>Enter this code only on the BeastBrowser website</li>
                  <li>If you suspect fraud, contact us immediately</li>
                </ul>
              </div>
            </div>
            
            <p style="color: #6b7280; font-size: 12px; text-align: center; margin-top: 40px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
              Need help? Contact us at <a href="mailto:beastbrowser2@beastbrowser.com" style="color: #ff6b35;">beastbrowser2@beastbrowser.com</a> or 
              <a href="https://wa.me/917991985013" style="color: #25d366;">WhatsApp: +91 79919 85013</a>
            </p>
          </div>
        </div>
      `
    }

    const result = await sendEmail(email, template)
    
    if (result.success) {
      console.log(`Verification code sent to ${email}: ${code}`)
      return { success: true }
    } else {
      return { success: false, error: result.error }
    }
  } catch (error) {
    console.error('Error sending verification email:', error)
    return { success: false, error: 'Failed to send verification email' }
  }
}

// Verify code
export const verifyCode = (email: string, inputCode: string): { 
  success: boolean, 
  error?: string, 
  remainingAttempts?: number 
} => {
  const normalizedEmail = email.toLowerCase()
  const stored = verificationCodes.get(normalizedEmail)

  if (!stored) {
    return { success: false, error: 'No verification code found. Please request a new code.' }
  }

  // Check if code expired
  if (Date.now() > stored.expires) {
    verificationCodes.delete(normalizedEmail)
    return { success: false, error: 'Verification code has expired. Please request a new code.' }
  }

  // Check attempts limit (max 5 attempts)
  if (stored.attempts >= 5) {
    verificationCodes.delete(normalizedEmail)
    return { success: false, error: 'Too many failed attempts. Please request a new code.' }
  }

  // Increment attempts
  stored.attempts++

  // Check if code matches
  if (stored.code === inputCode.trim()) {
    verificationCodes.delete(normalizedEmail) // Clean up after successful verification
    return { success: true }
  } else {
    const remainingAttempts = 5 - stored.attempts
    return { 
      success: false, 
      error: `Invalid code. ${remainingAttempts} attempts remaining.`,
      remainingAttempts 
    }
  }
}

// Resend verification code
export const resendVerificationCode = async (email: string): Promise<{ success: boolean, error?: string }> => {
  const normalizedEmail = email.toLowerCase()
  
  // Check if there's a recent code (prevent spam)
  const stored = verificationCodes.get(normalizedEmail)
  if (stored && (Date.now() - stored.createdAt) < 60 * 1000) {
    return { success: false, error: 'Please wait 1 minute before requesting a new code.' }
  }

  // Send new code
  return await sendVerificationEmail(email)
}

// Clean up expired codes (should be run periodically)
export const cleanupExpiredCodes = () => {
  const now = Date.now()
  const emailsToDelete: string[] = []
  
  verificationCodes.forEach((data, email) => {
    if (now > data.expires) {
      emailsToDelete.push(email)
    }
  })
  
  emailsToDelete.forEach(email => {
    verificationCodes.delete(email)
  })
}

// Get verification status (for debugging)
export const getVerificationStatus = (email: string) => {
  const stored = verificationCodes.get(email.toLowerCase())
  if (!stored) return null
  
  return {
    hasCode: true,
    expires: new Date(stored.expires).toISOString(),
    attempts: stored.attempts,
    isExpired: Date.now() > stored.expires
  }
}
