// Firebase has been removed and replaced with Supabase
// This file is kept for compatibility but Firebase functionality is no longer used

export const auth = null
export const db = null
export const storage = null

export default null
