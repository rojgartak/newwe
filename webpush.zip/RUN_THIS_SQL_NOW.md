# 🚨 URGENT: Run This SQL in Supabase NOW!

## ❌ Problem
Free plan activate ho raha hai but **validate nahi ho raha** kyunki Supabase me tables nahi hain.

## ✅ Solution (5 Minutes)

### **Step 1: Open Supabase Dashboard**
1. Go to: https://supabase.com/dashboard
2. Login karo
3. Apna project select karo: **ckbudoabovcrxywdtbqh**

### **Step 2: Open SQL Editor**
1. Left sidebar me **SQL Editor** pe click karo
2. Click **"New query"**

### **Step 3: Copy This SQL**
```sql
-- Free Plan Profile Tracking Schema
-- This tracks daily profile creation for free plan users

-- Table to track user's free plan activation
CREATE TABLE IF NOT EXISTS free_plan_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    activated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id)
);

-- Table to track daily profile creation (not needed for unlimited but keeping for future)
CREATE TABLE IF NOT EXISTS daily_profile_limits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    profiles_created INTEGER DEFAULT 0,
    max_profiles INTEGER DEFAULT -1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, date)
);

-- Table to store actual profiles created by free users (not used - profiles stored locally)
CREATE TABLE IF NOT EXISTS free_plan_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    profile_name TEXT NOT NULL,
    profile_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_free_plan_users_user_id ON free_plan_users(user_id);
CREATE INDEX IF NOT EXISTS idx_free_plan_users_expires_at ON free_plan_users(expires_at);
CREATE INDEX IF NOT EXISTS idx_daily_profile_limits_user_date ON daily_profile_limits(user_id, date);
CREATE INDEX IF NOT EXISTS idx_free_plan_profiles_user_id ON free_plan_profiles(user_id);

-- Enable Row Level Security
ALTER TABLE free_plan_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_profile_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE free_plan_profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies for free_plan_users
DROP POLICY IF EXISTS "Users can view their own free plan" ON free_plan_users;
CREATE POLICY "Users can view their own free plan"
    ON free_plan_users FOR SELECT
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert their own free plan" ON free_plan_users;
CREATE POLICY "Users can insert their own free plan"
    ON free_plan_users FOR INSERT
    WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Service role can manage all free plans" ON free_plan_users;
CREATE POLICY "Service role can manage all free plans"
    ON free_plan_users FOR ALL
    USING (true);

-- RLS Policies for daily_profile_limits
DROP POLICY IF EXISTS "Users can view their own daily limits" ON daily_profile_limits;
CREATE POLICY "Users can view their own daily limits"
    ON daily_profile_limits FOR SELECT
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update their own daily limits" ON daily_profile_limits;
CREATE POLICY "Users can update their own daily limits"
    ON daily_profile_limits FOR UPDATE
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Service role can manage all daily limits" ON daily_profile_limits;
CREATE POLICY "Service role can manage all daily limits"
    ON daily_profile_limits FOR ALL
    USING (true);

-- RLS Policies for free_plan_profiles
DROP POLICY IF EXISTS "Users can view their own profiles" ON free_plan_profiles;
CREATE POLICY "Users can view their own profiles"
    ON free_plan_profiles FOR SELECT
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert their own profiles" ON free_plan_profiles;
CREATE POLICY "Users can insert their own profiles"
    ON free_plan_profiles FOR INSERT
    WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can delete their own profiles" ON free_plan_profiles;
CREATE POLICY "Users can delete their own profiles"
    ON free_plan_profiles FOR DELETE
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Service role can manage all profiles" ON free_plan_profiles;
CREATE POLICY "Service role can manage all profiles"
    ON free_plan_profiles FOR ALL
    USING (true);

-- Grant permissions
GRANT ALL ON free_plan_users TO authenticated;
GRANT ALL ON daily_profile_limits TO authenticated;
GRANT ALL ON free_plan_profiles TO authenticated;
GRANT ALL ON free_plan_users TO service_role;
GRANT ALL ON daily_profile_limits TO service_role;
GRANT ALL ON free_plan_profiles TO service_role;

-- Comments
COMMENT ON TABLE free_plan_users IS 'Tracks users who have activated the 7-day free plan';
COMMENT ON TABLE daily_profile_limits IS 'Tracks daily profile creation limits (unlimited for free plan now)';
COMMENT ON TABLE free_plan_profiles IS 'Stores profiles created by free plan users (NOT USED - profiles stored locally)';
```

### **Step 4: Run the SQL**
1. Paste the SQL in editor
2. Click **"Run"** button (ya press `Ctrl + Enter`)
3. Wait 2-3 seconds
4. Success message aana chahiye ✅

### **Step 5: Verify Tables Created**
1. Left sidebar me **Table Editor** pe click karo
2. Check karo ye tables create hui:
   - ✅ `free_plan_users`
   - ✅ `daily_profile_limits`
   - ✅ `free_plan_profiles`

---

## 🧪 Test After SQL Run

### **Test 1: Activate Free Plan**
1. Website: http://localhost:3001
2. Login karo
3. Click "Start Free Trial"
4. Should show success ✅

### **Test 2: Check Supabase**
1. Supabase Dashboard
2. Table Editor > `free_plan_users`
3. Tumhara user_id hona chahiye with:
   - `is_active` = true
   - `expires_at` = 7 days from now

### **Test 3: Check in Software**
1. Software: http://localhost:5173
2. Login with same account
3. Browser console (F12) check karo:
   ```
   🔍 Checking user subscription for: abc-123...
   ✅ Active free plan found
   ```

---

## 🔍 If SQL Fails

### **Error: "uuid_generate_v4 does not exist"**
**Fix:** Enable UUID extension first:
```sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
```

### **Error: "permission denied"**
**Fix:** Make sure you're using **service_role** key in API, not anon key

### **Error: "relation already exists"**
**Fix:** Tables already created! Skip to verification step

---

## ✅ After SQL Runs Successfully

Ab ye sab kaam karega:
1. ✅ Free plan activate hoga
2. ✅ Supabase me save hoga
3. ✅ Software me detect hoga
4. ✅ Unlimited manual profiles
5. ✅ Bulk creation blocked
6. ✅ Automation blocked

---

## 🎯 Quick Checklist

- [ ] Supabase dashboard khola
- [ ] SQL Editor me SQL paste kiya
- [ ] SQL run kiya (Ctrl+Enter)
- [ ] Success message aaya
- [ ] Tables verify kiye
- [ ] Free plan activate kiya website pe
- [ ] Supabase me entry check ki
- [ ] Software me login kiya
- [ ] Plan detect hua

---

**Abhi SQL run karo! 2 minutes me sab kaam karne lagega!** 🚀
